<?php

namespace Mirri\Lkod\Entities;

use EasyRdf\Graph;
use Mirri\Lkod\Codelists\ContactPointCodelist;
use Mirri\Lkod\Codelists\DefaultCodelists;
use Mirri\Lkod\Entity;
use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\KnownUris;
use Mirri\Lkod\Properties\CheckboxProperty;
use Mirri\Lkod\Properties\LiteralStringLanguageDependentProperty;
use Mirri\Lkod\Properties\MultiSelectProperty;
use Mirri\Lkod\Properties\MultiUriProperty;
use Mirri\Lkod\Properties\SelectProperty;
use Mirri\Lkod\Properties\UriProperty;
use Mirri\Lkod\Settings;
use Mirri\Lkod\Validators\NotEmptyStringValidator;

class DataService extends Entity {
	public const TYPE = 'dcat_data_service';

	private LiteralStringLanguageDependentProperty $name;

	private UriProperty $endpointUrl;

	private CheckboxProperty $isHvd;

	private MultiSelectProperty $hvdCategories;

	private MultiUriProperty $legislation;

	private SelectProperty $contactPoint;

	private UriProperty $documentation;

	private UriProperty $conformsTo;

	private UriProperty $endpointDescription;

	public function __construct(Settings $settings) {
		parent::__construct($settings, self::TYPE);

		$this->name = new LiteralStringLanguageDependentProperty($this, 'name', 'Meno/názov', true);
		$this->name->addDefaultLanguageValidator(new NotEmptyStringValidator());
		$this->addProperty($this->name);

		$this->endpointUrl = new UriProperty($this, 'endpoint_url', 'URL prístupového bodu', true);
		$this->endpointUrl->addValidator(new NotEmptyStringValidator());
        $this->endpointUrl->setHint('Zadajte URL prístupového bodu. Napr. https://mirri.gov.sk/openapi/faktury');
		$this->addProperty($this->endpointUrl);

		$this->isHvd = new CheckboxProperty($this, 'is_hvd', 'Sprístupňuje dáta pre HVD datasety');
		$this->addProperty($this->isHvd);

		$this->hvdCategories = new MultiSelectProperty($this, 'hvd_categories', 'Kategória HVD', false, DefaultCodelists::getHvdCategoryCodelist());
		$this->addProperty($this->hvdCategories);

		$this->legislation = new MultiUriProperty($this, 'applicable_legislation', 'Právny predpis');
		$this->addProperty($this->legislation);

		$this->contactPoint = new SelectProperty($this, 'contact_point', 'Kontaktný bod', false, new ContactPointCodelist());
		$this->contactPoint->setEmptyValue('- nie je vybraný -');
		$this->addProperty($this->contactPoint);

		$this->documentation = new UriProperty($this, 'documentation', 'Odkaz na dokumentáciu');
        $this->documentation->setHint('Zadajte URL dokumentácie dátovej služby. Dokumentácia by mala obsahovať najmä podmienky, príklady a možnosti použitia dátovej služby.');
		$this->addProperty($this->documentation);

		$this->conformsTo = new UriProperty($this, 'conforms_to', 'Odkaz na špecifikáciu');
        $this->conformsTo->setHint('Zadajte URL špecifikácie ktorou sa dátová služba riadi. Takou špecifikáciou je napríklad SPARQL, napr. https://www.w3.org/TR/sparql11-protocol');
		$this->addProperty($this->conformsTo);

		$this->endpointDescription = new UriProperty($this, 'endpoint_description', 'Popis prístupového bodu');
        $this->endpointDescription->setHint('Zadajte URL popisu prístupového bodu dátovej služby.');
		$this->addProperty($this->endpointDescription);

        $this->addCustomMetadataProperties();
	}

	public function renderFormState(array $values, IFormNamespace $ns, array $errors = [], array $commands = [], bool $showErrors = true): void {
		if ($showErrors) {
			$this->renderErrors($errors);
		}
		?>

		<div>
			<?php $this->renderProperty($this->name, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->endpointUrl, $values, $ns, $errors); ?>
			<div class="hvd-parent">
				<?php $this->renderProperty($this->isHvd, $values, $ns, $errors); ?>
			</div>

			<div class="hvd-elements" style="display: none;">
				<?php $this->renderProperty($this->hvdCategories, $values, $ns, $errors); ?>
			</div>

			<?php $this->renderProperty($this->legislation, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->contactPoint, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->documentation, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->conformsTo, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->endpointDescription, $values, $ns, $errors); ?>
		</div>

		<script>
            jQuery(document).ready(function($) {
				const toggleHvdControls = () => {
					const isHvd = $('.hvd-parent input[type="checkbox"]').prop("checked");
					$('.hvd-elements').toggle(isHvd);
				}
                $('.hvd-parent input[type="checkbox"]').click(toggleHvdControls);
				toggleHvdControls();
            });
		</script>

        <?php $this->renderCustomProperties($values, $ns, $errors); ?>

		<?php
	}

    public function validateValues(array $data): array {
        Dataset::modifyLegislationValuesForHvd($data, (bool)$this->isHvd->extractValue($data), $this->legislation);
        return parent::validateValues($data);
    }

    protected function onPostUpdated(int $post_id): void {
		$names = $this->name->getPostValue($post_id);
		$key = $this->getSettings()->getDefaultLanguage()->getCode();
		if (isset($names[$key])) {
			$name = $names[$key];
			/** @noinspection UnusedFunctionResultInspection */
			wp_update_post([ 'ID' => $post_id, 'post_title' => $name], false, false);
		}
	}

	public function customValidation(array $values): array {
		$errors = parent::customValidation($values);

		$notEmptyValidator = new NotEmptyStringValidator();
		if (!empty($values[$this->isHvd->getName()])) {
            $propertyErrors = $notEmptyValidator->validate($this->hvdCategories->extractValue($values));
            if (!empty($propertyErrors)) {
                $errors[$this->hvdCategories->getName()] = $propertyErrors;
            }

            $propertyErrors = $notEmptyValidator->validate($this->legislation->extractValue($values));
            if (!empty($propertyErrors)) {
                $errors[$this->legislation->getName()] = $propertyErrors;
            }

            $propertyErrors = $notEmptyValidator->validate($this->contactPoint->extractValue($values));
            if (!empty($propertyErrors)) {
                $errors[$this->contactPoint->getName()] = $propertyErrors;
            }

            $propertyErrors = $notEmptyValidator->validate($this->documentation->extractValue($values));
            if (!empty($propertyErrors)) {
                $errors[$this->documentation->getName()] = $propertyErrors;
            }

            $propertyErrors = $notEmptyValidator->validate($this->conformsTo->extractValue($values));
            if (!empty($propertyErrors)) {
                $errors[$this->conformsTo->getName()] = $propertyErrors;
            }
		}

		return $errors;
	}

	public function addTriples(int $postId, Graph $g): ?string {
		$iri = $this->getSettings()->getDataServiceUrl($postId);

		$g->addType($iri, KnownUris::DcatDataServiceClass);
        $this->name->addPostTriples($postId, $g, $iri, KnownUris::DctTitle);
        $this->endpointUrl->addPostTriples($postId, $g, $iri, KnownUris::DcatEndpointUrl);
        $this->hvdCategories->addPostTriples($postId, $g, $iri, KnownUris::DcatApHvdCategory);
        $this->legislation->addPostTriples($postId, $g, $iri, KnownUris::DcatApApplicableLegislation);

        $contactPointId = (int)$this->contactPoint->getPostValue($postId);
        if ($contactPointId > 0) {
            $contactPointIri = (new ContactPoint( $this->getSettings()))->addTriples($contactPointId, $g);
            $g->addResource($iri, KnownUris::DcatContactPoint, $contactPointIri);
        }

        $this->documentation->addPostTriples($postId, $g, $iri, KnownUris::FoafPage);
        $this->conformsTo->addPostTriples($postId, $g, $iri, KnownUris::DctConformsTo);
        $this->endpointDescription->addPostTriples($postId, $g, $iri, KnownUris::DcatEndpointDescription);

        return $iri;
	}

    public function getEndpointUrl(int $postId): mixed {
        return $this->endpointUrl->getPostValue($postId);
    }
}