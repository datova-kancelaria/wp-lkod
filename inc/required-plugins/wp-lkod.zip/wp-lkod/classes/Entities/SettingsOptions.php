<?php

namespace Mirri\Lkod\Entities;

use EasyRdf\Graph;
use Mirri\Lkod\Codelists\ContactPointCodelist;
use Mirri\Lkod\Codelists\DefaultCodelists;
use Mirri\Lkod\Codelists\SearchableCodelist;
use Mirri\Lkod\Codelists\StaticCodelist;
use Mirri\Lkod\Entity;
use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\KnownUris;
use Mirri\Lkod\Properties\AutocompleteProperty;
use Mirri\Lkod\Properties\CheckboxProperty;
use Mirri\Lkod\Properties\CustomMetadataProperty;
use Mirri\Lkod\Properties\LiteralStringLanguageDependentProperty;
use Mirri\Lkod\Properties\LiteralTextareaLanguageDependentProperty;
use Mirri\Lkod\Properties\MultiCheckboxProperty;
use Mirri\Lkod\Properties\PublishersProperty;
use Mirri\Lkod\Properties\SelectProperty;
use Mirri\Lkod\Properties\UriProperty;
use Mirri\Lkod\Settings;
use Mirri\Lkod\Validators\NotEmptyStringValidator;

class SettingsOptions extends Entity {
	public const TYPE = 'lkod-settings';

	public const DefaultLicenseSettingName = 'default_license';

	public const DefaultPersonalDataSettingName = 'default_personal_data';

    public const DefaultSpatialSettingName = 'default_spatial';

    public const PublishersSettingName = 'publishers';

    public const CustomMetadataSettingName = 'custom_metadata';

	public const CatalogExportEnabledSettingName = 'catalog_export_enabled';

	public const EnabledLanguagesSettingName = 'enabled_languages';

	private PublishersProperty $publishers;

	private MultiCheckboxProperty $enabledLanguages;

	private LiteralStringLanguageDependentProperty $catalogName;

	private LiteralTextareaLanguageDependentProperty $catalogDescription;

	private CheckboxProperty $catalogExportEnabled;

    private AutocompleteProperty $spatial;

	private SelectProperty $defaultLicense;

	private SelectProperty $defaultPersonalData;

	private SelectProperty $contactPoint;

	private CustomMetadataProperty $customMetadata;

	public function __construct(Settings $settings) {
		parent::__construct($settings, self::TYPE);

		$this->publishers = new PublishersProperty($this, self::PublishersSettingName, 'Poskytovatelia dát');
        $this->publishers->setHint('Zadajte IRI poskytovateľa v tvare https://data.gov.sk/id/legal-subject/xxxxxxxx kde xxxxxxxx je IČO poskytovateľa. V prípade ak poskytovateľ nemá IČO, zadajte IČO nadradeného poskytovateľa (napr. v prípade Mestskej polície zadajte IČO mesta). Ak chcete vymazať poskytovateľa alebo zmeniť IRI poskytovateľa, musíte najprv vymazať jeho datasety alebo ich priradiť inému poskytovateľovi.');
		$this->addProperty($this->publishers);

		$allLanguages = [];
		foreach (Settings\Language::getAvailableLanguages() as $language) {
			$allLanguages[$language->getCode()] = $language->getLabel();
		}
		$this->enabledLanguages = new MultiCheckboxProperty($this, self::EnabledLanguagesSettingName, 'Podporované jazyky', false, new StaticCodelist($allLanguages));
        $this->enabledLanguages->setHint('Určuje aké jazykové verzie údajov budú zobrazené pre vyplnenie (napr. názov datasetu, popis datasetu). Tieto údaje sa budú zobrazovať na portáli data.slovensko.sk (angličtina) a na európskom portáli otvorených dát data.europa.eu.');
		$this->addProperty($this->enabledLanguages);

		$this->catalogName = new LiteralStringLanguageDependentProperty($this, 'catalog_name', 'Názov lokálneho katalógu', true);
        $this->catalogName->addDefaultLanguageValidator(new NotEmptyStringValidator());
        $this->catalogName->setHint('napr. Lokálny katalóg otvorených dát mesta Levoča');
		$this->addProperty($this->catalogName);

		$this->catalogDescription = new LiteralTextareaLanguageDependentProperty($this, 'catalog_description', 'Popis lokálneho katalógu', true);
        $this->catalogDescription->addDefaultLanguageValidator(new NotEmptyStringValidator());
        $this->catalogDescription->setHint('napr. Obsahuje všetky datasety, ktoré zverejňuje mesto Levoča');
		$this->addProperty($this->catalogDescription);

		$this->catalogExportEnabled = new CheckboxProperty($this, self::CatalogExportEnabledSettingName, 'Prístupový bod katalógu je verejne dostupný');
		$this->catalogExportEnabled->setHint('Adresa prístupového bodu lokálneho katalógu: ' . $settings->getCatalogUrl());
        $this->catalogExportEnabled->setHint('Je potrebné označiť, ak chcete aby sa lokálny katalóg harvestoval na data.slovensko.sk. Následne je potrebné zaregistrovať lokálny katalóg na data.slovensko.sk. Viac informácií nájdete v ###LINK###návode###END_LINK###.');
		$this->addProperty($this->catalogExportEnabled);

		$this->contactPoint = new SelectProperty($this, 'contact_point', 'Kontaktný bod', false, new ContactPointCodelist());
		$this->contactPoint->setEmptyValue('- nie je vybraný -');
		$this->addProperty($this->contactPoint);

        $this->spatial = new AutocompleteProperty($this, self::DefaultSpatialSettingName, 'Prednastavený územný prvok z registra adries', false, new SearchableCodelist(DefaultCodelists::getSpatialCodelist()));
        $this->spatial->setHint('Začnite písať a vyberte z ponúkaných hodnôt (obec, okres, kraj alebo Slovenská republika).');
        $this->addProperty($this->spatial);

		$this->defaultLicense = new SelectProperty($this, self::DefaultLicenseSettingName, 'Prednastavený typ licencie pre distribúcie', false, DefaultCodelists::getLicenseCodelist());
        $this->defaultLicense->setHint('Odporúčané licencie sú Creative Commons CC0 1.0 Univerzálne a Creative Commons Attribution 4.0 Medzinárodný.');
		$this->addProperty($this->defaultLicense);

		$this->defaultPersonalData = new SelectProperty($this, self::DefaultPersonalDataSettingName, 'Prednastavený typ výskytu osobných údajov', false, DefaultCodelists::getPersonalDataCodelist());
		$this->addProperty($this->defaultPersonalData);

		$this->customMetadata = new CustomMetadataProperty($this, self::CustomMetadataSettingName, 'Vlastné metaúdaje', false);
		$this->addProperty($this->customMetadata);
	}

	public function getRawOptions(): array {
		$data = [];
		foreach ($this->getProperties() as $property) {
			$data[$property->getName()] = $property->getSettingValue();
		}
		return $data;
	}

	public function getCatalogGraph(): Graph {
		$g = new Graph();
		$settings = $this->getSettings();
		$iri = $settings->getCatalogUrl();
		$options = $this->getRawOptions();

		$g->addType($iri, KnownUris::DcatCatalogClass);
		$this->catalogName->addTriples($this->catalogName->extractValue($options), $g, $iri, KnownUris::DctTitle);
		$this->catalogDescription->addTriples($this->catalogDescription->extractValue($options), $g, $iri, KnownUris::DctDescription);
		$g->addResource($iri, KnownUris::DcatEndpointUrl, $iri);
		$g->addResource($iri, KnownUris::FoafHomePage, site_url());

        $publisher = $this->getSettings()->getDefaultPublisher();
        if ($publisher !== null) {
            $g->addResource($iri, KnownUris::DctPublisher, $publisher->getIri());
        }

		$contactPointId = (int)$this->contactPoint->extractValue($options);
		if ($contactPointId > 0) {
			$contactPointIri = (new ContactPoint($settings))->addTriples($contactPointId, $g);
			$g->addResource($iri, KnownUris::DcatContactPoint, $contactPointIri);
		}

		foreach (get_posts([ 'post_type' => Dataset::TYPE, 'numberposts' => -1, 'post_status' => 'publish']) as $post) {
			$g->addResource($iri, KnownUris::DcatDataset, $settings->getDatasetUrl($post->ID));
		}

		return $g;
	}

	public function renderFormState(array $values, IFormNamespace $ns, array $errors = [], array $commands = [], bool $showErrors = true): void {
		?>

		<?php if ($showErrors): ?>
			<?php $this->renderErrors($errors);?>
		<?php endif; ?>

		<?php $this->renderProperty($this->publishers, $values, $ns, $errors); ?>

		<h2>Nastavenie jazykových verzií metaúdajov</h2>

		<?php $this->renderProperty($this->enabledLanguages, $values, $ns, $errors); ?>

		<h2>Nastavenia lokálneho katalógu</h2>

		<?php $this->renderProperty($this->catalogName, $values, $ns, $errors); ?>
		<?php $this->renderProperty($this->catalogDescription, $values, $ns, $errors); ?>
		<?php $this->renderProperty($this->contactPoint, $values, $ns, $errors); ?>
		<?php $this->renderProperty($this->catalogExportEnabled, $values, $ns, $errors); ?>

		<h2>Prednastavené hodnoty</h2>
		<?php $this->renderProperty($this->spatial, $values, $ns, $errors); ?>
		<?php $this->renderProperty($this->defaultLicense, $values, $ns, $errors); ?>
		<?php $this->renderProperty($this->defaultPersonalData, $values, $ns, $errors); ?>


		<?php $this->renderProperty($this->customMetadata, $values, $ns, $errors); ?>

		<?php
	}
}