<?php

namespace Mirri\Lkod\Entities;
use EasyRdf\Graph;
use Mirri\Lkod\Codelists\CategoryCodelist;
use Mirri\Lkod\Codelists\ContactPointCodelist;
use Mirri\Lkod\Codelists\DatasetSerieCodelist;
use Mirri\Lkod\Codelists\DefaultCodelists;
use Mirri\Lkod\Codelists\PublisherCodelist;
use Mirri\Lkod\Codelists\SearchableCodelist;
use Mirri\Lkod\Entity;
use Mirri\Lkod\Helpers;
use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\KnownUris;
use Mirri\Lkod\Properties\AutocompleteProperty;
use Mirri\Lkod\Properties\CheckboxProperty;
use Mirri\Lkod\Properties\DateProperty;
use Mirri\Lkod\Properties\DateTimeProperty;
use Mirri\Lkod\Properties\DecimalProperty;
use Mirri\Lkod\Properties\KeywordsProperty;
use Mirri\Lkod\Properties\LiteralStringLanguageDependentProperty;
use Mirri\Lkod\Properties\LiteralTextareaLanguageDependentProperty;
use Mirri\Lkod\Properties\MultiCheckboxProperty;
use Mirri\Lkod\Properties\MultiSelectProperty;
use Mirri\Lkod\Properties\MultiUriProperty;
use Mirri\Lkod\Properties\ObjectProperty;
use Mirri\Lkod\Properties\SelectProperty;
use Mirri\Lkod\Properties\TimeResolutionProperty;
use Mirri\Lkod\Properties\UriProperty;
use Mirri\Lkod\Property;
use Mirri\Lkod\Settings;
use Mirri\Lkod\Validators\EurovocThemeValidator;
use Mirri\Lkod\Validators\NotEmptyStringValidator;

class Dataset extends Entity {
	public const TYPE = 'dcat_dataset';

	private SelectProperty $publisher;

	private LiteralStringLanguageDependentProperty $title;

	private LiteralTextareaLanguageDependentProperty $description;

	private CheckboxProperty $isSerie;

	private SelectProperty $parentSerie;

	private MultiCheckboxProperty $type;

	private DateTimeProperty $issued;

	private DateTimeProperty $modified;

	private MultiSelectProperty $theme;

	private SelectProperty $periodicity;

	private KeywordsProperty $keywords;

	private AutocompleteProperty $spatial;

	private MultiUriProperty $spatialOptional;

	private DateProperty $dateFrom;

	private DateProperty $dateTo;

	private SelectProperty $contactPoint;

	private UriProperty $website;

	private UriProperty $documentation;

	private UriProperty $conformsTo;

	private MultiUriProperty $related;

	private MultiUriProperty $eurovoc;

	private TimeResolutionProperty $temporalResolution;

	private DecimalProperty $spatialResolution;

	private MultiUriProperty $legislation;

	private MultiSelectProperty $hvdCategories;

	private ObjectProperty $distributions;

	private Distribution $distributionEntity;

	public function __construct(Settings $settings) {
		parent::__construct($settings, self::TYPE);

		$this->publisher = new SelectProperty($this, 'publisher', 'Poskytovateľ dát', true, new PublisherCodelist($settings));
		$defaultPublisher = $settings->getDefaultPublisher();
		if ($defaultPublisher !== null) {
			$this->publisher->setDefaultValue($defaultPublisher->getIri());
		}
		$this->addProperty($this->publisher);

        $categories = new MultiCheckboxProperty($this, 'categories', 'Kategórie', true, new CategoryCodelist());
        $categories->addValidator(new NotEmptyStringValidator());
        $this->addProperty($categories);

		$this->title = new LiteralStringLanguageDependentProperty($this, 'title', 'Názov', true);
		$this->title->addDefaultLanguageValidator(new NotEmptyStringValidator());
		$this->addProperty($this->title);

		$this->description = new LiteralTextareaLanguageDependentProperty($this, 'description', 'Popis', true);
		$this->description->addDefaultLanguageValidator(new NotEmptyStringValidator());
		$this->addProperty($this->description);

		$this->isSerie = new CheckboxProperty($this, 'is_serie', 'Dataset je dátovou sériou');
        $this->isSerie->setHint('Dátová séria je dataset, ktorý zastrešuje súvisiace datasety a série.');
		$this->addProperty($this->isSerie);

		$this->parentSerie = new SelectProperty($this, 'in_serie', 'Nadradená séria', false, new DatasetSerieCodelist());
		$this->parentSerie->setEmptyValue('- dataset nie je súčasťou série -');
		$this->addProperty($this->parentSerie);

		$this->type = new MultiCheckboxProperty($this, 'type', 'Typ datasetu', false, DefaultCodelists::getDatasetTypeCodelist());
        $this->type->setHint("Do publikačného minima patria tieto datasety: ###https://slovak-egov.atlassian.net/wiki/spaces/opendata/pages/20055191/6.+Publika+n+minimum###https://slovak-egov.atlassian.net/wiki/spaces/opendata/pages/20055191/6.+Publika+n+minimum###END_LINK###.\n K HVD datasetom patria tieto datasety: ###https://slovak-egov.atlassian.net/wiki/spaces/opendata/pages/20056502/Zoznam+HVD+datasetov###https://slovak-egov.atlassian.net/wiki/spaces/opendata/pages/20056502/Zoznam+HVD+datasetov###END_LINK###.\n K najžiadanejším datasetom patria tieto datasety: ###https://slovak-egov.atlassian.net/wiki/spaces/opendata/pages/20054108/14.+Najviac+iadan+daje+vo+verejnej+spr+ve###https://slovak-egov.atlassian.net/wiki/spaces/opendata/pages/20054108/14.+Najviac+iadan+daje+vo+verejnej+spr+ve###END_LINK###");
		$this->addProperty($this->type);

		$this->issued = new DateTimeProperty($this, 'issued', 'Dátum publikácie');
		$this->issued->setDefaultValue('now');
		$this->addProperty($this->issued);

		$this->modified = new DateTimeProperty($this, 'modified', 'Dátum modifikácie');
		$this->modified->setDefaultValue('now');
		$this->modified->setDefaultValueShouldBeNow(true);
		$this->addProperty($this->modified);

		$this->theme = new MultiSelectProperty($this, 'theme', 'Téma', true, DefaultCodelists::getDatasetThemeCodelist());
		$this->theme->addValidator(new NotEmptyStringValidator());
		$this->addProperty($this->theme);

		$this->periodicity = new SelectProperty($this, 'periodicity', 'Periodicita aktualizácie', true, DefaultCodelists::getFrequencyCodelist());
		$this->periodicity->setEmptyValue('- nie je vybraná hodnota - ');
		$this->periodicity->addValidator(new NotEmptyStringValidator());
		$this->addProperty($this->periodicity);

		$this->keywords = new KeywordsProperty($this, 'keywords', 'Kľúčové slová', true);
		$this->keywords->addDefaultLanguageValidator(new NotEmptyStringValidator());
		$this->addProperty($this->keywords);

		$this->spatial = new AutocompleteProperty($this, 'spatial', 'Územný prvok z registra adries', true, new SearchableCodelist(DefaultCodelists::getSpatialCodelist()));
        $this->spatial->setHint('Začnite písať a vyberte z ponúkaných hodnôt (obec, okres, kraj alebo Slovenská republika).');
        $defaultSpatial = $settings->getDefaultSpatial();
        if ($defaultSpatial !== null) {
            $this->spatial->setDefaultValue($defaultSpatial);
        }
		$this->spatial->addValidator(new NotEmptyStringValidator());
		$this->addProperty($this->spatial);

		$this->spatialOptional = new MultiUriProperty($this, 'spatial_optional', 'Súvisiace geografické územie');
        $this->spatialOptional->setHint('Slúži na detailnejšie určenie polohy, napr. názov vrchu, rieky, ... Použite hodnotu z ###https://www.geonames.org/search.html###číselníka Geonames###END_LINK###.');
		$this->addProperty($this->spatialOptional);

		$this->dateFrom = new DateProperty($this, 'date_from', 'Časové pokrytie - dátum od');
		$this->addProperty($this->dateFrom);

		$this->dateTo = new DateProperty($this, 'date_to', 'Časové pokrytie - dátum do');
		$this->addProperty($this->dateTo);

		$this->contactPoint = new SelectProperty($this, 'contact_point', 'Kontaktný bod', false, new ContactPointCodelist());
		$this->contactPoint->setEmptyValue('- nie je vybraný -');
		$this->addProperty($this->contactPoint);

		$this->website = new UriProperty($this, 'website', 'Webová stránka');
        $this->website->setHint('Zadajte URL webovej stránky, kde dataset vznikol alebo ktorá súvisí s datasetom.');
		$this->addProperty($this->website);

		$this->documentation = new UriProperty($this, 'documentation', 'Odkaz na dokumentáciu');
        $this->documentation->setHint('Zadajte URL dokumentácie datasetu.');
		$this->addProperty($this->documentation);

		$this->conformsTo = new UriProperty($this, 'conforms_to', 'Odkaz na špecifikáciu');
        $this->conformsTo->setHint('Zadajte URL špecifikácie, ktorou sa riadi dataset.');
		$this->addProperty($this->conformsTo);

		$this->related = new MultiUriProperty($this, 'related', 'Súvisiaci zdroj');
        $this->related->setHint('Zadajte URL špecifikácie, ktorou sa riadi dataset.');
		$this->addProperty($this->related);

		$this->eurovoc = new MultiUriProperty($this, 'eurovoc', 'Klasifikácia podľa EuroVoc');
        $this->eurovoc->setHint('Použite hodnotu z ###https://op.europa.eu/sk/web/eu-vocabularies/concept-scheme/-/resource?uri=http://eurovoc.europa.eu/100141l###číselníka Eurovoc###END_LINK###.');
		$this->eurovoc->addSingleValueValidator(new EurovocThemeValidator());
		$this->addProperty($this->eurovoc);

		$this->temporalResolution = new TimeResolutionProperty($this, 'temporal_resolution', 'Časové rozlíšenie');
        $this->temporalResolution->setHint('Zadajte časové rozlíšenie dát, ide o najmenší časový rozdiel v datasete.');
		$this->addProperty($this->temporalResolution);

		$this->spatialResolution = new DecimalProperty($this, 'spatial_resolution', 'Priestorové rozlíšenie v metroch');
        $this->spatialResolution->setHint('Zadajte priestorové rozlíšenie dát, ide o najmenší priestorový rozdiel v datasete.');
		$this->addProperty($this->spatialResolution);

		$this->legislation = new MultiUriProperty($this, 'applicable_legislation', 'Právny predpis');
		$this->addProperty($this->legislation);

		$this->hvdCategories = new MultiSelectProperty($this, 'hvd_categories', 'Kategória HVD', false, DefaultCodelists::getHvdCategoryCodelist());
		$this->addProperty($this->hvdCategories);

        $this->addCustomMetadataProperties();

		$this->distributionEntity = new Distribution($settings);
		$this->distributions = new ObjectProperty($this, 'distributions', 'Distribúcie', false, $this->distributionEntity);
		$this->addProperty($this->distributions);
	}

	public function renderFormState(array $values, IFormNamespace $ns, array $errors = [], array $commands = [], bool $showErrors = true): void {
		$distributions = $values['distributions'] ?? [];

		if (in_array('Pridať ďalšiu distribúciu', $commands, true)) {
			$distributions[] = $this->distributionEntity->getDefaultValues();
		}
		$values['distributions'] = $distributions;

		parent::renderFormState($values, $ns, $errors, $commands, $showErrors);
	}

	protected function renderProperty(Property $property, array $values, IFormNamespace $ns, array $errors = []): void {
		?>

		<?php if ($property->getName() === $this->type->getName()): ?>
			<div class="hvd-parent">
				<?php parent::renderProperty($property, $values, $ns, $errors); ?>
			</div>
		<?php elseif ($property->getName() === $this->hvdCategories->getName()): ?>
			<div class="hvd-elements" style="display: none;">
				<?php parent::renderProperty($property, $values, $ns, $errors); ?>
			</div>
		<?php else:?>
			<?php parent::renderProperty($property, $values, $ns, $errors); ?>
		<?php endif?>

		<script>
            jQuery(document).ready(function($) {
                const hvdType = <?php echo wp_json_encode(KnownUris::HvdType); ?>;
                const toggleHvdControls = () => {
                    const isHvd = $('.hvd-parent input[value="' + hvdType + '"]').prop("checked");
                    $('.hvd-elements').toggle(isHvd);
                }
                $('.hvd-parent input[type="checkbox"]').click(toggleHvdControls);
                toggleHvdControls();
            });
		</script>

		<?php
	}

	public function validateValues(array $data): array {
		self::modifyLegislationValuesForHvd($data, $this->isHvd($data), $this->legislation);
		return parent::validateValues($data);
	}

	protected function onPostUpdated(int $post_id): void {
		$names = $this->title->getPostValue($post_id);
		$key = $this->getSettings()->getDefaultLanguage()->getCode();
		if (isset($names[$key])) {
			$name = $names[$key];
			/** @noinspection UnusedFunctionResultInspection */
			wp_update_post([ 'ID' => $post_id, 'post_title' => $name], false, false);
		}
	}

	public function isHvd(array $data): bool {
		$types = (array)$this->type->extractValue($data);
		return in_array(KnownUris::HvdType, $types, true);
	}

	public function isSerie(array $data): bool {
		return (bool)$this->isSerie->extractValue($data);
	}

	public static function modifyLegislationValuesForHvd(array &$data, bool $isHvd, MultiUriProperty $legislationProperty): void {
		$legislations = $legislationProperty->extractValue($data) ?? [];
		if (!is_array($legislations)) {
			$legislations = [];
		}

		$contains = in_array(KnownUris::HvdLegislation, $legislations, true);

		if ($isHvd) {
			if (!$contains) {
				$legislations[] = KnownUris::HvdLegislation;
			}
		} elseif ($contains) {
			foreach ($legislations as $index => $legislation) {
				if ($legislation === KnownUris::HvdLegislation) {
					unset($legislations[$index]);
				}
			}
		}

		$data[$legislationProperty->getName()] = $legislations;
	}

	public function addTriples(int $postId, Graph $g): ?string {
		$iri = $this->getSettings()->getDatasetUrl($postId);

		$isSerie = (bool)$this->isSerie->getPostValue($postId);

		$g->addType($iri, $isSerie ? KnownUris::DcatDatasetSeriesClass : KnownUris::DcatDatasetClass);
		$this->title->addPostTriples($postId, $g, $iri, KnownUris::DctTitle);
		$this->description->addPostTriples($postId, $g, $iri, KnownUris::DctDescription);
		$this->publisher->addPostTriples($postId, $g, $iri, KnownUris::DctPublisher);
		$this->issued->addPostTriples($postId, $g, $iri, KnownUris::DctIssued);
		$this->modified->addPostTriples($postId, $g, $iri, KnownUris::DctModified);
		$this->theme->addPostTriples($postId, $g, $iri, KnownUris::DcatTheme);
		$this->periodicity->addPostTriples($postId, $g, $iri, KnownUris::DctAccrualPeriodicity);
		$this->keywords->addPostTriples($postId, $g, $iri, KnownUris::DcatKeyword);
		$this->type->addPostTriples($postId, $g, $iri, KnownUris::DctType);
		$this->spatial->addPostTriples($postId, $g, $iri, KnownUris::DctSpatial);
		$this->spatialOptional->addPostTriples($postId, $g, $iri, KnownUris::DctSpatial);

		$dateFrom = Helpers::getDateValue($this->dateFrom->getPostValue($postId));
		$dateTo = Helpers::getDateValue($this->dateTo->getPostValue($postId));
		if ($dateFrom !== null || $dateTo !== null) {
			$blank = $g->newBNode([KnownUris::DctPeriodOfTime]);
			if ($dateFrom !== null) {
				$g->addLiteral($blank, KnownUris::DcatStartDate, Helpers::dateToLiteral($dateFrom));
			}
			if ($dateTo !== null) {
				$g->addLiteral($blank, KnownUris::DcatEndDate, Helpers::dateToLiteral($dateTo));
			}
            $g->addResource($iri, KnownUris::DctTemporal, $blank);
		}

		$contactPointId = (int)$this->contactPoint->getPostValue($postId);
		if ($contactPointId > 0) {
			$contactPointIri = (new ContactPoint( $this->getSettings()))->addTriples($contactPointId, $g);
			$g->addResource($iri, KnownUris::DcatContactPoint, $contactPointIri);
		}

		$this->website->addPostTriples($postId, $g, $iri, KnownUris::DcatLandingPage);
		$this->documentation->addPostTriples($postId, $g, $iri, KnownUris::FoafPage);
		$this->conformsTo->addPostTriples($postId, $g, $iri, KnownUris::DctConformsTo);
		$this->related->addPostTriples($postId, $g, $iri, KnownUris::DctRelation);
		$this->eurovoc->addPostTriples($postId, $g, $iri, KnownUris::DcatTheme);
		$this->spatialResolution->addPostTriples($postId, $g, $iri, KnownUris::DcatSpatialResolutionInMeters);
		$this->temporalResolution->addPostTriples($postId, $g, $iri, KnownUris::DcatTemporalResolution);
		$this->legislation->addPostTriples($postId, $g, $iri, KnownUris::DcatApApplicableLegislation);
		$this->hvdCategories->addPostTriples($postId, $g, $iri, KnownUris::DcatApHvdCategory);

        $parentSerieId = (int)$this->parentSerie->getPostValue($postId);
        if ($parentSerieId > 0) {
            $parentSerieIri = $this->getSettings()->getDatasetUrl($parentSerieId);
            $g->addResource($iri, KnownUris::DcatInSeries, $parentSerieIri);
        }

		$index = 1;
		foreach ($this->distributions->getPostValue($postId) as $distribution) {
			$distributionIri = $this->getSettings()->getDistributionUrl($postId, $index);
			$g->addResource($iri, KnownUris::DcatDistribution, $distributionIri);
			$this->distributionEntity->addDistributionTriples($distributionIri, $distribution, $g);
			$index++;
		}

		return $iri;
	}

	public function customValidation(array $values): array {
		$errors = parent::customValidation($values);

		$isHvd = $this->isHvd($values);

		$notEmptyValidator = new NotEmptyStringValidator();
		if ($isHvd) {
			$propertyErrors = $notEmptyValidator->validate($this->hvdCategories->extractValue($values));
			if (!empty($propertyErrors)) {
				$errors[$this->hvdCategories->getName()] = $propertyErrors;
			}

			$propertyErrors = $notEmptyValidator->validate($this->legislation->extractValue($values));
			if (!empty($propertyErrors)) {
				$errors[$this->legislation->getName()] = $propertyErrors;
			}
		}

		$isSerie = $this->isSerie($values);
		$distributions = (array)$this->distributions->extractValue($values);
		if ($isSerie) {
			if (count($distributions) > 0) {
				$errors[$this->distributions->getName()] = ['Dátová séria nemôže obsahovať distribúcie'];
			}
		} elseif (count($distributions) === 0) {
			$errors[$this->distributions->getName()] = ['Dataset musí obsahovať aspoň jednu distribúciu'];
		}

		return $errors;
	}
}