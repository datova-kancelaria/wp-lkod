<?php

namespace Mirri\Lkod\Entities;

use EasyRdf\Graph;
use Mirri\Lkod\Codelists\ContactTypeCodelist;
use Mirri\Lkod\Entity;
use Mirri\Lkod\Helpers;
use Mirri\Lkod\KnownUris;
use Mirri\Lkod\Properties\EmailProperty;
use Mirri\Lkod\Properties\LiteralStringLanguageDependentProperty;
use Mirri\Lkod\Properties\RadioProperty;
use Mirri\Lkod\Settings;
use Mirri\Lkod\Validators\NotEmptyStringValidator;

class ContactPoint extends Entity {
	public const TYPE = 'dcat_contact_point';

	private RadioProperty $type;

	private LiteralStringLanguageDependentProperty $name;

	private EmailProperty $email;

	public function __construct(Settings $settings) {
		parent::__construct($settings, self::TYPE);

		$contactTypeCodelist = new ContactTypeCodelist();
		$this->type = new RadioProperty($this, 'type', 'Typ kontaktu', true, $contactTypeCodelist);
		$this->type->setDefaultValue(ContactTypeCodelist::Organization);
		$this->addProperty($this->type);

		$this->name = new LiteralStringLanguageDependentProperty($this, 'name', 'Meno/názov', true);
		$this->name->addDefaultLanguageValidator(new NotEmptyStringValidator());
		$this->addProperty($this->name);

		$this->email = new EmailProperty($this, 'email', 'E-mailová adresa', true);
		$this->email->addValidator(new NotEmptyStringValidator());
		$this->addProperty($this->email);
	}

	public function addTriples(int $postId, Graph $g): ?string {
		$iri = $this->getSettings()->getContactPointUrl($postId);
		$g->addType($iri, ContactTypeCodelist::getUri($this->type->getPostValue($postId)));
		$this->name->addPostTriples($postId, $g, $iri, KnownUris::VcardFn);
		$this->email->addPostTriples($postId, $g, $iri, KnownUris::VcardHasEmail);
		return $iri;
	}

	protected function customValidation(array $values): array {
		$errors = parent::customValidation($values);

		$notEmptyValidator = new NotEmptyStringValidator();
		$nameDefined = empty($notEmptyValidator->validate($this->name->extractDefaultLanguageValue($values)));
		$emailDefined = empty($notEmptyValidator->validate($this->email->extractValue($values)));

		if (!$nameDefined && !$emailDefined) {
			$errors['_'] = ['Kontaktný bod musí mať aspoň jedno z: meno/názov alebo e-mailovú adresu.'];
		}

		return $errors;
	}

	protected function onPostUpdated(int $post_id): void {
		$names = $this->name->getPostValue($post_id);
		$key = $this->getSettings()->getDefaultLanguage()->getCode();
		if (isset($names[$key])) {
			$name = $names[$key];
			/** @noinspection UnusedFunctionResultInspection */
			wp_update_post([ 'ID' => $post_id, 'post_title' => $name], false, false);

			$updated = Helpers::now()->format(\DateTimeInterface::ATOM);
			foreach (get_posts(['post_type' => Dataset::TYPE, 'numberposts' => -1, 'meta_key' => 'contact_point', $post_id, 'post_status' => 'any']) as $post) {
				update_post_meta($post->ID, 'modified', $updated);
			}
		}
    }
}