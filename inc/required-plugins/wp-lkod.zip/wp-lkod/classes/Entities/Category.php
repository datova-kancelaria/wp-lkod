<?php

namespace Mirri\Lkod\Entities;

use Mirri\Lkod\Entity;
use Mirri\Lkod\Properties\ImageProperty;
use Mirri\Lkod\Properties\LiteralStringProperty;
use Mirri\Lkod\Settings;
use Mirri\Lkod\Validators\NotEmptyStringValidator;

class Category extends Entity {
	public const TYPE = 'dcat_category';

	private LiteralStringProperty $name;

	public function __construct(Settings $settings) {
		parent::__construct($settings, self::TYPE);

		$this->name = new LiteralStringProperty($this, 'name', 'Názov kategórie', true);
		$this->addProperty($this->name);

		$image = new ImageProperty($this, 'icon', 'Ikona - obrázok', true);
		$image->addValidator(new NotEmptyStringValidator());
		$this->addProperty($image);
	}

	protected function onPostUpdated(int $post_id): void {
		$name = $this->name->getPostValue($post_id);
		/** @noinspection UnusedFunctionResultInspection */
		wp_update_post([ 'ID' => $post_id, 'post_title' => $name], false, false);
	}
}