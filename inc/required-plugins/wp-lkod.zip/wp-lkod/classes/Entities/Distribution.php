<?php

namespace Mirri\Lkod\Entities;

use EasyRdf\Graph;
use Mirri\Lkod\Codelists\DataServiceCodelist;
use Mirri\Lkod\Codelists\DefaultCodelists;
use Mirri\Lkod\Codelists\StaticCodelist;
use Mirri\Lkod\Entity;
use Mirri\Lkod\Helpers;
use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\KnownUris;
use Mirri\Lkod\Properties\LiteralStringLanguageDependentProperty;
use Mirri\Lkod\Properties\MultiUriProperty;
use Mirri\Lkod\Properties\RadioProperty;
use Mirri\Lkod\Properties\SelectProperty;
use Mirri\Lkod\Properties\UploadProperty;
use Mirri\Lkod\Properties\UriProperty;
use Mirri\Lkod\Settings;
use Mirri\Lkod\Validators\NotEmptyStringValidator;

class Distribution extends Entity {
    public const TYPE = 'dcat_distribution';

	private SelectProperty $authorsWorkType;

	private SelectProperty $originalDatabaseType;

	private SelectProperty $databaseProtectedBySpecialRightsType;

	private SelectProperty $personalDataType;

	private LiteralStringLanguageDependentProperty $authorName;

	private LiteralStringLanguageDependentProperty $originalAuthorName;

	private RadioProperty $method;

	private RadioProperty $fileType;

	private UploadProperty $file;

	private UriProperty $url;

    private SelectProperty $service;

    private SelectProperty $format;

    private SelectProperty $mediaType;

    private MultiUriProperty $legislation;

    private UriProperty $conformsTo;

    private SelectProperty $compressFormat;

    private SelectProperty $packageFormat;

    private LiteralStringLanguageDependentProperty $title;

    public function __construct(Settings $settings) {
		parent::__construct($settings, 'dcat_distribution');

		$licenseCodelist = DefaultCodelists::getLicenseCodelist();

		$this->authorsWorkType = new SelectProperty($this, 'authors_work_type', 'Typ autorského diela', true, $licenseCodelist);
		$this->authorsWorkType->setDefaultValue($settings->getDefaultLicenseType());
		$this->addProperty($this->authorsWorkType);

		$this->originalDatabaseType = new SelectProperty($this, 'original_database_type', 'Typ originálnej databázy', true, $licenseCodelist);
		$this->originalDatabaseType->setDefaultValue($settings->getDefaultLicenseType());
		$this->addProperty($this->originalDatabaseType);

		$this->databaseProtectedBySpecialRightsType = new SelectProperty($this, 'database_protected_by_special_rights_type', 'Typ špeciálnej právnej ochrany', true, $licenseCodelist);
		$this->databaseProtectedBySpecialRightsType->setDefaultValue($settings->getDefaultLicenseType());
		$this->addProperty($this->databaseProtectedBySpecialRightsType);

		$this->personalDataType = new SelectProperty($this, 'personal_data_containment_type', 'Typ výskytu osobných údajov', true, DefaultCodelists::getPersonalDataCodelist());
		$this->personalDataType->setDefaultValue($settings->getDefaultPersonalDataType());
		$this->addProperty($this->personalDataType);

		$this->authorName = new LiteralStringLanguageDependentProperty($this, 'author_name', 'Meno autora diela');
		$this->addProperty($this->authorName);

		$this->originalAuthorName = new LiteralStringLanguageDependentProperty($this, 'original_author_name', 'Meno autora originálnej databázy');
		$this->addProperty($this->originalAuthorName);

		$this->method = new RadioProperty($this, 'method', 'Spôsob prístupu', true, new StaticCodelist(['file' => 'Súbor na stiahnutie', 'service' => 'Prístupová služba'], false));
		$this->method->setDefaultValue('file');
        $this->method->setHint('Prístupová služba je typ distribúcie, kedy sú dáta dostupné cez OpenAPI alebo odkaz, kde sú dáta automatizovane aktualizované.');
		$this->addProperty($this->method);

		$this->fileType = new RadioProperty($this, 'file_type', 'Spôsob vloženia súboru na stiahnutie', true, new StaticCodelist(['upload' => 'Upload súboru', 'url' => 'Vloženie URL adresy súboru'], false));
		$this->fileType->setDefaultValue('upload');
		$this->addProperty($this->fileType);

		$this->file = new UploadProperty($this, 'upload', 'Súbor na stiahnutie');
		$this->addProperty($this->file);

		$this->url = new UriProperty($this, 'url', 'URL adresa súboru na stiahnutie');
        $this->url->setHint('Zadajte URL adresu súboru. Napr. https://mirri.gov.sk/dataset.csv');
		$this->addProperty($this->url);

        $this->format = new SelectProperty($this, 'format', 'Formát súboru na stiahnutie', false, DefaultCodelists::getFormatCodelist());
        $this->format->setEmptyValue('- hodnota nie je vybraná -');
        $this->addProperty($this->format);

        $mediaTypeCodelist = DefaultCodelists::getMediaTypeCodelist();
        $this->mediaType = new SelectProperty($this, 'media_type', 'Typ média súboru na stiahnutie', false, $mediaTypeCodelist);
        $this->mediaType->setEmptyValue('- hodnota nie je vybraná -');
        $this->addProperty($this->mediaType);

        $this->legislation = new MultiUriProperty($this, 'applicable_legislation', 'Právny predpis');
        $this->addProperty($this->legislation);

        $this->conformsTo = new UriProperty($this, 'conforms_to', 'Odkaz na strojovo-čitateľnú schému súboru na stiahnutie');
        $this->conformsTo->setHint('Zadajte URL na schému popisu distribúcie.');
        $this->addProperty($this->conformsTo);

        $this->compressFormat = new SelectProperty($this, 'compress_format', 'Typ média kompresného formátu', false, $mediaTypeCodelist);
        $this->compressFormat->setEmptyValue('- bez kompresie -');
        $this->compressFormat->setHint('Vyberte typ kompresného formátu ak je dataset komprimovaný.');
        $this->addProperty($this->compressFormat);

        $this->packageFormat = new SelectProperty($this, 'package_format', 'Typ média balíčkovacieho formátu', false, $mediaTypeCodelist);
        $this->packageFormat->setEmptyValue('- bez balíčkovania -');
        $this->packageFormat->setHint('Vyberte typ balíčkového formátu ak je dataset balíčkovaný.');
        $this->addProperty($this->packageFormat);

        $this->title = new LiteralStringLanguageDependentProperty($this, 'title', 'Názov distribúcie');
        $this->addProperty($this->title);

        $this->service = new SelectProperty($this, 'service', 'Prístupová služba', false, new DataServiceCodelist());
        $this->service->setEmptyValue('- hodnota nie je vybraná -');
        $this->addProperty($this->service);

        $this->addCustomMetadataProperties();
	}

	public function renderMultipleFormStates(array $values, IFormNamespace $ns, array $errors = []): void {
		?>

		<div id="distribution-list" style="margin-top: 40px;">
            <hr>
			<h2 style="font-size: 2em; margin: 0 0 20px 0; padding: 0">Distribúcie</h2>
			<?php $index = 1;?>
			<?php foreach ($values as $key => $objectValues): ?>
				<div class="entity-form-key-wrap" style="padding-left: 20px; margin-top: 20px;">
					<h3>Distribúcia č. <?php echo esc_html($index); ?></h3>
					<?php $this->renderFormState($objectValues, $ns->createInnerNamespace([$key]), $errors[$key] ?? [], [], false); ?>

                    <div>
                        <button class="button button-secondary" onclick="jQuery(this).closest('.entity-form-key-wrap').remove(); return false;">Odstrániť túto distribúciu</button>
                    </div>
				</div>
				<?php $index++; ?>
			<?php endforeach; ?>
		</div>

		<script>
            jQuery(document).ready(function($) {
                const list = $('#distribution-list');

                const showOrHideControls = function (distribution) {
					distribution = $(distribution);

                    const method = distribution.find('.distribution-method input:checked').val();
                    distribution.find('.distribution-method-file').toggle(method === 'file');
                    distribution.find('.distribution-method-service').toggle(method !== 'file');

                    const type = distribution.find('.distribution-method-file-type input:checked').val();
                    distribution.find('.distribution-method-file-upload').toggle(type === 'upload');
                    distribution.find('.distribution-method-file-url').toggle(type !== 'upload');
                }

                list.find('.distribution-access').each(function(_, element) {
                    showOrHideControls(element);
                });

                list.find('.distribution-access input').click(function() {
                    showOrHideControls($(this).closest('.distribution-access'));
                });
            });
		</script>

		<?php
	}

    public function customValidation(array $values): array {
        $errors = [];

        $notEmptyValidator = new NotEmptyStringValidator();
        switch ($this->method->extractValue($values)) {
            case 'file':
                switch ($this->fileType->extractValue($values)) {
                    case 'upload':
                        $propertyErrors = $notEmptyValidator->validate($this->file->extractValue($values));
                        if (!empty($propertyErrors)) {
                            $errors[$this->file->getName()] = $propertyErrors;
                        }
                        break;
                    case 'url':
                        $propertyErrors = $notEmptyValidator->validate($this->url->extractValue($values));
                        if (!empty($propertyErrors)) {
                            $errors[$this->url->getName()] = $propertyErrors;
                        }
                        break;
                }

                $propertyErrors = $notEmptyValidator->validate($this->format->extractValue($values));
                if (!empty($propertyErrors)) {
                    $errors[$this->format->getName()] = $propertyErrors;
                }

                $propertyErrors = $notEmptyValidator->validate($this->mediaType->extractValue($values));
                if (!empty($propertyErrors)) {
                    $errors[$this->mediaType->getName()] = $propertyErrors;
                }

                break;
            case 'service':
                $propertyErrors = $notEmptyValidator->validate($this->service->extractValue($values));
                if (!empty($propertyErrors)) {
                    $errors[$this->service->getName()] = $propertyErrors;
                }
                break;
        }

        return $errors;
    }

	public function renderFormState(array $values, IFormNamespace $ns, array $errors = [], array $commands = [], bool $showErrors = true): void {
		if ($showErrors) {
            $this->renderErrors($errors);
        }
		?>

		<div>
			<h4>Špecifikácia podmienok použitia</h4>
			<?php $this->renderProperty($this->authorsWorkType, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->originalDatabaseType, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->databaseProtectedBySpecialRightsType, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->personalDataType, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->authorName, $values, $ns, $errors); ?>
			<?php $this->renderProperty($this->originalAuthorName, $values, $ns, $errors); ?>

			<h4>Prístup k údajom</h4>
			<div class="distribution-access">
				<div class="distribution-method">
					<?php $this->renderProperty($this->method, $values, $ns, $errors); ?>
				</div>

				<div class="distribution-method-file">
					<div class="distribution-method-file-type">
						<?php $this->renderProperty($this->fileType, $values, $ns, $errors); ?>
					</div>

					<div class="distribution-method-file-upload">
						<?php $this->renderProperty($this->file, $values, $ns, $errors); ?>
					</div>

					<div class="distribution-method-file-url">
						<?php $this->renderProperty($this->url, $values, $ns, $errors); ?>
					</div>
				</div>

                <div class="distribution-method-service">
                    <?php $this->renderProperty($this->service, $values, $ns, $errors); ?>
                </div>
			</div>

            <?php $this->renderProperty($this->format, $values, $ns, $errors); ?>
            <?php $this->renderProperty($this->mediaType, $values, $ns, $errors); ?>
            <?php $this->renderProperty($this->legislation, $values, $ns, $errors); ?>
            <?php $this->renderProperty($this->conformsTo, $values, $ns, $errors); ?>
            <?php $this->renderProperty($this->compressFormat, $values, $ns, $errors); ?>
            <?php $this->renderProperty($this->packageFormat, $values, $ns, $errors); ?>
            <?php $this->renderProperty($this->title, $values, $ns, $errors); ?>

            <?php $this->renderCustomProperties($values, $ns, $errors); ?>
		</div>

		<?php
	}

    public function addDistributionTriples(string $iri, array $values, Graph $g): void {
        $g->addType($iri, KnownUris::DcatDistributionClass);

        $terms = $g->newBNode([KnownUris::LegTermsOfUseClass]);
        $g->addResource($iri, KnownUris::LegTermsOfUse, $terms);
        $this->authorsWorkType->addTriples($this->authorsWorkType->extractValue($values), $g, $terms, KnownUris::LegAuthorsWorkType);
        $this->originalDatabaseType->addTriples($this->originalDatabaseType->extractValue($values), $g, $terms, KnownUris::LegOriginalDatabaseType);
        $this->databaseProtectedBySpecialRightsType->addTriples($this->databaseProtectedBySpecialRightsType->extractValue($values), $g, $terms, KnownUris::LegDatabaseProtectedBySpecialRightsType);
        $this->personalDataType->addTriples($this->personalDataType->extractValue($values), $g, $terms, KnownUris::LegPersonalDataContainmentType);
        $this->authorName->addTriples($this->authorName->extractValue($values), $g, $terms, KnownUris::LegAuthorName);
        $this->originalAuthorName->addTriples($this->originalAuthorName->extractValue($values), $g, $terms, KnownUris::LegOriginalDatabaseAuthorName);

        switch ($this->method->extractValue($values)) {
            case 'file':
                $url = null;
                switch ($this->fileType->extractValue($values)) {
                    case 'upload':
                        $fileId = $this->file->extractValue($values);
                        if (!empty($fileId)) {
                            $url = wp_get_attachment_url($fileId);
                        }
                        break;
                    case 'url':
                        $url = $this->url->extractValue($values);
                        break;
                }

                if (!empty($url) && is_string($url)) {
                    Helpers::addTriplesAsUris($url, $g, $iri, KnownUris::DcatDownloadUrl);
                    Helpers::addTriplesAsUris($url, $g, $iri, KnownUris::DcatAccessUrl);
                }

                break;
            case 'service':
                $dataServiceId = (int)$this->service->extractValue($values);
                if ($dataServiceId > 0) {
                    $dataServiceEntity = new DataService($this->getSettings());
                    $dataServiceIri = $dataServiceEntity->addTriples($dataServiceId, $g);
                    $g->addResource($iri, KnownUris::DcatAccessService, $dataServiceIri);

                    $endpointUrl = $dataServiceEntity->getEndpointUrl($dataServiceId);
                    if (!empty($endpointUrl)) {
                        Helpers::addTriplesAsUris($endpointUrl, $g, $iri, KnownUris::DcatAccessUrl);
                    }
                }
                break;
        }

        $this->format->addTriples($this->format->extractValue($values), $g, $iri, KnownUris::DctFormat);
        $this->mediaType->addTriples($this->mediaType->extractValue($values), $g, $iri, KnownUris::DcatMediaType);
        $this->legislation->addTriples($this->legislation->extractValue($values), $g, $iri, KnownUris::DcatApApplicableLegislation);
        $this->conformsTo->addTriples($this->conformsTo->extractValue($values), $g, $iri, KnownUris::DctConformsTo);
        $this->compressFormat->addTriples($this->compressFormat->extractValue($values), $g, $iri, KnownUris::DcatCompressFormat);
        $this->packageFormat->addTriples($this->packageFormat->extractValue($values), $g, $iri, KnownUris::DcatPackageFormat);
        $this->title->addTriples($this->title->extractValue($values), $g, $iri, KnownUris::DctTitle);
    }
}