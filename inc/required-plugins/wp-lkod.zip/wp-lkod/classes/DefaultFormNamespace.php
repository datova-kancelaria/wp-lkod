<?php

namespace Mirri\Lkod;

class DefaultFormNamespace implements IFormNamespace {
	private array $prefix;

	private bool $useArrayNotation;

	public function __construct(string|array $prefix = '', $useArrayNotation = false) {
		$this->prefix = is_array($prefix) ? $prefix : [$prefix];
		$this->useArrayNotation = $useArrayNotation;
	}

	private static function combine(array $prefix, array|string $name, bool $useArrayNotation): string {
		$values = $prefix;

		if (is_array($name)) {
			/** @noinspection MissUsingForeachInspection */
			foreach ($name as $value) {
				$values[] = $value;
			}
		} else {
			$values[] = $name;
		}

		if ($useArrayNotation) {
			$c = count($values);
			if ($c > 1) {
				$name = '';
				foreach ($values as $value) {
					if (!empty($name)) {
						$name .= '['.$value.']';
					} else {
						$name = $value;
					}
				}
				return $name;
			}

			if ($c === 1) {
				return $values[0];
			}

			return '';
		}

		$c = count($values);
		if ($c > 1 && isset($values[$c - 1]) && $values[$c - 1] === '[]') {
			return implode('_', array_slice($values, 0, -1)) . '[]';
		}

		return implode('_', $values);
	}

	public function prefixName(array|string $name): string {
		if (!$this->useArrayNotation && is_array($name)) {
			$c = count($name);
			if ($c > 1 && isset($name[$c - 1]) && $name[$c - 1] === '') {
				$name[$c - 1] = '[]';
			}
		}

		return self::combine($this->prefix, $name, $this->useArrayNotation);
	}

	public function prefixIdentifier(array|string $name): string {
		return self::combine($this->prefix, $name, false);
	}

	public function normalizeData(array $data): ?array {
		if (empty($this->prefix)) {
			return $data;
		}

		if ($this->useArrayNotation) {
			$normalized = $data;
			foreach ($this->prefix as $p) {
				if (isset($normalized[$p])) {
					$normalized = $normalized[$p];
				} else {
					return null;
				}
			}
			return $normalized;
		}

		$singlePrefix = implode('_', $this->prefix) . '_';
		$len          = strlen($singlePrefix);
		$normalized   = [];
		foreach ($data as $key => $value) {
			if (str_starts_with( $key, $singlePrefix)) {
				$normalized[substr($key, $len)] = $value;
			} else {
				$normalized[$key] = $value;
			}
		}

		return $normalized;
	}

	public function createInnerNamespace(array $name): IFormNamespace {
		$prefix   = $this->prefix;
		/** @noinspection MissUsingForeachInspection */
		foreach ($name as $n) {
			$prefix[] = $n;
		}
		return new self($prefix, $this->useArrayNotation);
	}
}