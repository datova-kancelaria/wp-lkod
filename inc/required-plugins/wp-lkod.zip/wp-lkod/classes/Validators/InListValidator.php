<?php

namespace Mirri\Lkod\Validators;

use Mirri\Lkod\IValidator;

class InListValidator implements IValidator {
	private array $allowedValues;

	public function __construct(array $allowedValues) {
		$this->allowedValues = $allowedValues;
	}

	public function validate($value): array {
		/** @noinspection PhpRedundantOptionalArgumentInspection */
		if (!empty($value) && !in_array($value, $this->allowedValues, false)) {
			return ['Hodnota nie je z číselníka'];
		}
		return [];
	}
}