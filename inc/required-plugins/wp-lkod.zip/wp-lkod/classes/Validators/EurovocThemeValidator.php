<?php

namespace Mirri\Lkod\Validators;

use Mirri\Lkod\IValidator;
use Mirri\Lkod\KnownUris;

class EurovocThemeValidator implements IValidator {

	public function validate($value): array {
		$errors = [];

		if (!str_starts_with($value, KnownUris::EurovocPrefix)) {
			$errors[] = 'Hodnota z číselníka EuroVoc musí začínať ' . KnownUris::EurovocPrefix;
		}

		return $errors;
	}
}