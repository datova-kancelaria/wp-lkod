<?php

namespace Mirri\Lkod\Validators;

use Mirri\Lkod\IValidator;

class NotEmptyStringValidator implements IValidator {
	public function validate($value): array {
		if (self::isEmpty($value)) {
			return ['Hodnota nesmie byť prázdna'];
		}
		return [];
	}

	public static function isEmpty(mixed $value): bool {
		if ($value === null) {
			return true;
		}

		if (is_array($value)) {
			return count($value) === 0;
		}

		if (is_object($value)) {
			return false;
		}

		$value = trim((string)$value);
		return empty($value);
	}
}