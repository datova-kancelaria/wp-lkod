<?php

namespace Mirri\Lkod\Validators;

use Mirri\Lkod\IValidator;
use Mirri\Lkod\Settings;

class UriValidator implements IValidator {
	private array $allowedSchemes;

	public function __construct(array $allowedSchemes) {
		$this->allowedSchemes = [];
		foreach ($allowedSchemes as $scheme) {
			$this->allowedSchemes[] = self::normalizeScheme($scheme);
		}
	}

	public function validate(mixed $value): array {
		return self::validateUri($value, $this->allowedSchemes);
	}

	public static function validateUri(mixed $value, array $allowedSchemes = []): array {
		if (!empty($value)) {
			$errors = [];

			$parts = parse_url((string)$value);

			if (is_array($parts)) {
				$scheme = self::normalizeScheme((string)($parts['scheme'] ?? ''));
				if (!in_array($scheme, $allowedSchemes, true)) {
					$errors[] = 'Hodnota nie je platná URI, nemá platnú schému';
				} elseif ( filter_var($parts['host'], FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) === false) {
					$errors[] = 'Hodnota nie je platná URI, nemá platné doménové meno';
				}
			} else {
				$errors[] = 'Hodnota nie je platná URI';
			}
			return $errors;
		}
		return [];
	}

	private static function normalizeScheme(string $scheme): string {
		return mb_strtolower($scheme, 'UTF-8');
	}
}