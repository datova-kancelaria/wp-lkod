<?php

namespace Mirri\Lkod;

use EasyRdf\Graph;
use EasyRdf\RdfNamespace;
use Mirri\Lkod\Entities\SettingsOptions;
use Mirri\Lkod\Settings\CustomMetadata;
use Mirri\Lkod\Settings\Language;
use Mirri\Lkod\Settings\Publisher;

class Settings {
	/**
	 * @var Language[]
	 */
	private array $languages = [];

	private Language $defaultLanguage;

	/**
	 * @var Publisher[]
	 */
	private array $publishers = [];

	/**
	 * @var CustomMetadata[]
	 */
	private array $customMetadata = [];

	private static ?Settings $defaultSettings = null;

	public function __construct() {
		RdfNamespace::set('dcatap', KnownUris::DcatApPrefix);
		RdfNamespace::delete('dc');
		RdfNamespace::delete('dcterms');
		RdfNamespace::set('dct', KnownUris::DctPrefix);
		RdfNamespace::set('leg', KnownUris::LegPrefix);

		$this->defaultLanguage = new Language('sk', 'Slovensky', 'sk', true);

		$rawLanguages = (array)get_option(SettingsOptions::EnabledLanguagesSettingName, []);
		$allLanguages = Language::getAvailableLanguages();
		foreach ($rawLanguages as $rawLanguage) {
			if (isset($allLanguages[$rawLanguage])) {
				$this->languages[] = $allLanguages[$rawLanguage];
			}
		}


		$rawPublishers = get_option(SettingsOptions::PublishersSettingName, []);
		if (is_array($rawPublishers)) {
			$index = 0;
			foreach ($rawPublishers as $rawPublisher) {
				$name = trim((string)($rawPublisher['name'] ?? ''));
				$iri = trim((string)($rawPublisher['iri'] ?? ''));

				if (!empty($name) && !empty($iri)) {
					$this->publishers[] = new Publisher($iri, $name, $index === 0);
					$index++;
				}
			}
		}

		$rawCustomMetadata = get_option(SettingsOptions::CustomMetadataSettingName, []);
		if (is_array($rawCustomMetadata)) {
			foreach ($rawCustomMetadata as $rawCustomMetadataItem) {
				$name = trim((string)($rawCustomMetadataItem['name'] ?? ''));
				$label = trim((string)($rawCustomMetadataItem['label'] ?? ''));
				$type = trim((string)($rawCustomMetadataItem['type'] ?? ''));
				$use = array_values(array_filter((array)($rawCustomMetadataItem['use'] ?? [])));
				$listText = (string)($rawCustomMetadataItem['list'] ?? '');
				$list = [];
				foreach (preg_split('/\r\n|\r|\n/', $listText) as $listItem) {
					$listItem = trim($listItem);
					if (!empty($listItem)) {
						$list[] = $listItem;
					}
				}

				if (!empty($name) && !empty($type) && !empty($use)) {
					$this->customMetadata[] = new CustomMetadata($name, $label, $type, $use, $list);
				}
			}
		}
	}

	/**
	 * @return Language[]
	 */
	public function getLanguages(): array {
		return $this->languages;
	}

	public function getDefaultLanguage(): Language {
		return $this->defaultLanguage;
	}

	/**
	 * @return Language[]
	 */
	public function getLanguagesWithDefault(): array {
		return array_merge([$this->getDefaultLanguage()], $this->getLanguages());
	}

	/**
	 * @return Publisher[]
	 */
	public function getPublishers(): array {
		return $this->publishers;
	}

	public function getDefaultPublisher(): ?Publisher {
		foreach ($this->publishers as $publisher) {
			if ($publisher->isDefault()) {
				return $publisher;
			}
		}
		return $this->publishers[0] ?? null;
	}

	public function addCustomMetadata(CustomMetadata $customMetadata): void {
		$this->customMetadata[] = $customMetadata;
	}

	/**
	 * @return CustomMetadata[]
	 */
	public function getCustomMetadata(): array {
		return $this->customMetadata;
	}

	public function getDefaultLicenseType(): ?string {
		return get_option(SettingsOptions::DefaultLicenseSettingName, null);
	}

	public function getDefaultPersonalDataType(): ?string {
		return get_option(SettingsOptions::DefaultPersonalDataSettingName, null);
	}

	public function getDefaultSpatial(): ?string {
		return get_option(SettingsOptions::DefaultSpatialSettingName, null);
	}

	public function getAllowedIriSchemes(): array {
		return ['http', 'https'];
	}

	public function getAllowedDownloadableSchemes(): array {
		return [ 'http', 'https' ];
	}

	public function isCatalogEnabled(): bool {
		return !empty(get_option(SettingsOptions::CatalogExportEnabledSettingName, false));
	}

	public function getCatalogUrl(): string {
		return rest_url('wp-lkod/v1/catalog');
	}

	public function getDatasetUrl(int $postId): string {
		return rest_url('wp-lkod/v1/dataset/' . $postId);
	}

	public function getContactPointUrl(int $postId): string {
		return rest_url('wp-lkod/v1/contact-point/' . $postId);
	}

	public function getDataServiceUrl(int $postId): string {
		return rest_url('wp-lkod/v1/service/' . $postId);
	}

	public function getDistributionUrl(int $datasetPostId, int $index): string {
		return $this->getDatasetUrl($datasetPostId) . '/distribution/' . $index;
	}

	public static function getDefaultSettings(): self {
		return self::$defaultSettings ??= new self();
	}

	public function getPublisherByIri(string $iri): ?Publisher {
		foreach ($this->publishers as $publisher) {
			if ($publisher->getIri() === $iri) {
				return $publisher;
			}
		}
		return null;
	}
}