<?php

namespace Mirri\Lkod;

use EasyRdf\Graph;
use Mirri\Lkod\Settings\Language;

abstract class LanguageDependentProperty extends Property {
	/**
	 * @var IValidator[]
	 */
	private array $defaultLanguageValidators = [];

	public function getDataType(): string {
		return 'string';
	}

	public function registerPostMeta(): void {
		foreach ($this->getEntity()->getSettings()->getLanguagesWithDefault() as $lang) {
			$meta = $this->getPostMeta();
			$meta['label'] = $this->getLabel() . ' (' . $lang->getLabel().')';
			register_post_meta($this->getEntity()->getType(), $this->getName() . '-' . $lang->getCode(), $meta);
		}
	}

    public function getPostValue(int $postId): array {
		$values = [];
		foreach ($this->getEntity()->getSettings()->getLanguagesWithDefault() as $lang) {
			$code = $lang->getCode();
			$values[$code] = get_post_meta($postId, $this->getName() . '-' . $code, $this->isSingleValued());
		}
		return $values;
	}

    public function registerSetting(): void {
        foreach ($this->getEntity()->getSettings()->getLanguagesWithDefault() as $lang) {
            $meta = $this->getPostMeta();
            $meta['label'] = $this->getLabel() . ' (' . $lang->getLabel().')';
            $meta['sanitize_callback'] = function ($value) use ($lang) {
                $value = $this->filterSingleLanguageValue($value);
                $errors = Entity::flattenArray($this->validateSingleValue($lang, $value));
                if (!empty($errors)) {
                    foreach ($errors as $index => $error) {
                        add_settings_error(
                                $this->getName(),
                                $this->getName() . '-' . $index,
                                $this->getLabel() . ' - ' . $error,
                                'error'
                        );
                    }
                }
                return $value;
            };
            register_setting($this->getEntity()->getType(), $this->getName() . '_' . $lang->getCode(), $meta);
        }
    }

    public function getSettingValue(): array {
        $values = [];
        foreach ($this->getEntity()->getSettings()->getLanguagesWithDefault() as $lang) {
            $code = $lang->getCode();
            $values[$code] = get_option($this->getName() . '_' . $code, '');
        }
        return $values;
    }

	protected function filterSingleLanguageValue(mixed $value): mixed {
		return (string)wp_scrub_utf8((string)$value);
	}

	public function filterValue($value): array {
		$values = [];
		if (is_array($value)) {
			foreach ($this->getEntity()->getSettings()->getLanguagesWithDefault() as $lang) {
				$code = $lang->getCode();
				if (isset($value[$code])) {
					$values[$code] = $this->filterSingleLanguageValue($value[$code]);
				}
			}
		}
		return $values;
	}

	protected function validateSingleValue(Language $language, $value): array {
		$errors = [];

		foreach ($this->getValidators() as $validator) {
			/** @noinspection MissUsingForeachInspection */
			foreach ($validator->validate($value) as $error) {
				$errors[] = $error;
			}
		}

		if ($language->isDefault()) {
			foreach ($this->getDefaultLanguageValidators() as $validator) {
				/** @noinspection MissUsingForeachInspection */
				foreach ($validator->validate($value) as $error) {
					$errors[] = $error;
				}
			}
		}

		return $errors;
	}

	public function validateValue( mixed $value ): array {
		$errors = [];

        foreach ($this->getEntity()->getSettings()->getLanguagesWithDefault() as $lang) {
			$langValue = $value[$lang->getCode()] ?? null;
			/** @noinspection MissUsingForeachInspection */
			foreach ($this->validateSingleValue($lang, $langValue) as $error) {
				$errors[$lang->getCode()][] = $error;
			}
		}

		return $errors;
	}

	public function saveValue($post_id, $value): void {
		foreach ($this->getEntity()->getSettings()->getLanguagesWithDefault() as $lang) {
            $key = $this->getName() . '-' . $lang->getCode();
            $langValue = $value[$lang->getCode()] ?? ($this->isSingleValued() ? null : []);
			self::storeValue($post_id, $key, $langValue, $this->isSingleValued());
		}
	}

	public function addDefaultLanguageValidator(IValidator $validator): void {
		$this->defaultLanguageValidators[] = $validator;

	}

	public function getDefaultLanguageValidators(): array {
		return $this->defaultLanguageValidators;
	}

	protected function renderLabelContent(Language $language): void {
		?>

        <span <?php if ($this->isRequired()): ?> class="label-required"<?php endif; ?>>
            <?php echo esc_html($this->getLabel())?>
            <span class="<?php echo esc_attr('fi fi-' . $language->getFlag()) ?>"></span>
            <?php if ($language->isDefault()): ?>
                <?php $this->renderRequiredLabelText(); ?>
            <?php endif?>
        </span>

		<?php
	}

	abstract protected function renderLanguageElementAndErrors(Language $language, $value, array $errors, string $id, string $name): void;

	protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
		$languages = $this->getEntity()->getSettings()->getLanguagesWithDefault();
		?>

		<?php foreach ($languages as $lang):?>

			<?php
				$langValue = $value[$lang->getCode()] ?? null;
				$langErrors = $errors[$lang->getCode()] ?? [];
			?>

			<div class="<?php echo esc_attr(!$lang->isDefault() ? 'wp-lkod-loc-group' : '') ?>">
				<?php $this->renderLanguageElementAndErrors($lang, $langValue, $langErrors, $ns->prefixIdentifier([$this->getName(), $lang->getCode()]), $ns->prefixName([$this->getName(), $lang->getCode()])) ?>
			</div>

		<?php endforeach?>

		<?php
	}

    public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
        $this->addTriples($this->getPostValue($postId), $g, $subject, $predicate);
    }

    public function addTriples(mixed $values, Graph $g, string $subject, string $predicate): void {
        foreach ($this->getEntity()->getSettings()->getLanguagesWithDefault() as $lang) {
            if (!empty($values[$lang->getCode()])) {
                $g->addLiteral($subject, $predicate, $values[$lang->getCode()], $lang->getCode());
            }
        }
    }

    public function extractLanguageValue(array $data, Language $language): mixed {
        $values = $this->extractValue($data);
        if (is_array($values) && isset($values[$language->getCode()])) {
            return $values[$language->getCode()];
        }
        return null;
    }

    public function extractDefaultLanguageValue(array $data): mixed {
        return $this->extractLanguageValue($data, $this->getEntity()->getSettings()->getDefaultLanguage());
    }
}