<?php

namespace Mirri\Lkod;

interface IValidator {
	public function validate($value): array;
}