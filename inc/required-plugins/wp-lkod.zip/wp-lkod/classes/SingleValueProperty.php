<?php

namespace Mirri\Lkod;

use WP_Post;

abstract class SingleValueProperty extends Property {

	public function isSingleValued(): bool {
		return true;
	}

	public function filterValue($value): mixed {
		if (is_object($value) || is_array($value)) {
			return null;
		}
		return $value;
	}
}