<?php

namespace Mirri\Lkod\Properties;

use DateTime;
use DateTimeInterface;
use EasyRdf\Graph;
use Mirri\Lkod\Helpers;

class DateProperty extends PlainSingleProperty {
	public function filterValue($value): ?string {
		$dt = null;
		if (is_string($value)) {
			$dt = DateTime::createFromFormat('j.n.Y', str_replace(' ', '', $value), Helpers::getDefaultTimezone());
		}

		if ($dt instanceof DateTimeInterface) {
			return $dt->format(DateTimeInterface::ATOM);
		}
		return null;
	}

	protected function renderPlainElement($value, array $errors, string $name, string $id): void {
		$date = Helpers::getDateValue($value);
		$datePart = $date instanceof DateTimeInterface ? $date->format('j. n. Y') : '';
        parent::renderPlainElement($datePart, $errors, $name, $id);
        Helpers::enableDateSelector($id);
	}

	public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
		$this->addTriples($this->getPostValue($postId), $g, $subject, $predicate);
	}

	public function addTriples(mixed $value, Graph $g, string $subject, string $predicate): void {
		$literal = Helpers::dateToLiteral($value);
		if ($literal !== null) {
			$g->addLiteral($subject, $predicate, $literal);
		}
	}
}