<?php

namespace Mirri\Lkod\Properties;

use EasyRdf\Graph;
use Mirri\Lkod\Validators\UriValidator;

class MultiUriProperty extends MultiDynamicProperty {
	protected function init(): void {
		$this->addSingleValueValidator(new UriValidator($this->getSettings()->getAllowedIriSchemes()));
	}

	public function getDataType(): string {
        return 'string';
    }

    public function filterValue(mixed $value): array {
        if (is_array($value)) {
            return array_values(array_filter($value));
        }
        return [];
    }

    protected function renderSingleElement(int $index, mixed $value, string $idPrefix, string $name): void {
        $id = $idPrefix . '-el-' . $index;
        ?>

        <div class="wp-lkod-line-element" data-i="<?php echo esc_attr($index)?>">
            <label for="<?php echo esc_attr($id)?>" class="screen-reader-text">
                <?php echo esc_html($this->getLabel()) ?>
            </label>

            <input id="<?php echo esc_attr($id)?>" type="text" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value)?>">

            <button class="button">
                Odstrániť
            </button>
        </div>

        <?php
    }

    protected function renderJsAddElement(string $name): void {
        ?>

        const labelText = <?php echo wp_json_encode($this->getLabel()) ?>;
        const name = <?php echo wp_json_encode($name) ?>;

        let maxIndex = 0;
        parent.find('.wp-lkod-line-element').each(function(_, e) {
            const i = parseInt($(e).attr('data-i'));
            if (i > maxIndex) {
                maxIndex = i;
            }
        });

        const nextIndex = maxIndex + 1;
        const newId = id + '-el-' + nextIndex;

        const el = $(document.createElement('div'));
        el.attr('class', 'wp-lkod-line-element');
        el.attr('data-i', nextIndex)

        const label = $(document.createElement('label'));
        label.attr('for', id + '-element-' + nextIndex);
        label.attr('class', 'screen-reader-text');
        label.text(labelText);
        el.append(label);
        el.append(' ');

        const input = $(document.createElement('input'));
        input.attr('id', newId);
        input.attr('name', name);
        input.attr('type', 'text');
        el.append(input);
        el.append(' ');

        const button = $(document.createElement('button'));
        button.attr('class', 'button');
        button.text('Odstrániť');
        button.click(removeButtonClick);
        el.append(button);

        parent.append(el);
        <?php
    }

    public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
        $this->addPostTriplesAsUris($postId, $g, $subject, $predicate);
    }

    public function addTriples(mixed $values, Graph $g, string $subject, string $predicate): void {
        $this->addTriplesAsUris($values, $g, $subject, $predicate);
    }
}