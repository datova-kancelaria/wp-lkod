<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\Entities\Dataset;
use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\Validators\NotEmptyStringValidator;
use Mirri\Lkod\Validators\UriValidator;

class PublishersProperty extends MultiProperty {
	public function getDataType(): string {
		return 'array';
	}

    public function getPostMeta(): array {
        $meta = parent::getPostMeta();
        $meta['show_in_rest'] = [
            'schema' => [
                'type' => 'array',
                'items' => [
                     'type' => 'object',
                     'properties' => [
                         'name' => ['type' => 'string', 'required' => true],
                         'iri' => ['type' => 'string', 'required' => true],
                     ],
                     'additionalProperties' => false,
                ]
            ]
        ];
        return $meta;
    }

    public static function getPublisherDatasetsCount(string $iri): int {
        if (!empty($iri)) {
            return count(get_posts(['post_type' => Dataset::TYPE, 'numberposts' => -1, 'meta_key' => 'publisher', 'meta_value' => $iri, 'post_status' => 'any']));
        }
        return 0;
    }

    public function filterValue(mixed $value): array {
        $value = array_values(array_filter((array)$value));
        $previousValue = (array)$this->getSettingValue();
        $previousIri = array_column($previousValue, 'iri');
        $newIris = [];

        foreach ($value as $publisher) {
            $iri = trim($publisher['iri'] ?? '');
            if (!empty($iri)) {
                $newIris[] = $iri;
            }
        }

        $newIris = array_unique($newIris);

        $shouldReturnPreviousValue = false;

        foreach (array_diff($previousIri, $newIris) as $iri) {
            if (self::getPublisherDatasetsCount($iri) > 0) {
                $shouldReturnPreviousValue = true;
                break;
            }
        }

		return $shouldReturnPreviousValue ? $previousValue : $value;
	}

	public function validateValue(mixed $value): array {
		$errors = parent::validateValue($value);

        $newIris = [];
        $newNames = [];

		foreach ($value as $index => $publisher) {
			$number = $index + 1;
			if (!isset($publisher['name']) || trim($publisher['name']) === '') {
				$errors[] = 'Poskytovateľ č. ' . $number . ' nemá vyplnené meno';
			} elseif (!in_array($publisher['name'], $newNames, true)) {
                $newNames[] = $publisher['name'];
            } else {
                $errors[] = 'Poskytovateľ č. ' . $number . ' má duplicitné meno';
            }

			if (!isset($publisher['iri']) || trim($publisher['iri']) === '') {
				$errors[] = 'Poskytovateľ č. ' . $number . ' nemá vyplnené IRI';
			} else {
				foreach (UriValidator::validateUri($publisher['iri'], ['http', 'https']) as $error) {
					$errors[] = 'Poskytovateľ č. ' . $number . ' - IRI - ' . $error;
				}

                if (!preg_match('@^https://data.gov.sk/id/legal-subject/\d{8}$@', $publisher['iri'])) {
                    $errors[] = 'Poskytovateľ č. ' . $number . ' - IRI - nie je v tvare https://data.gov.sk/id/legal-subject/xxxxxxxx, kde xxxxxxxx je IČO poskytovateľa';
                }

                if (!in_array($publisher['iri'], $newIris, true)) {
                    $newIris[] = $publisher['iri'];
                } else {
                    $errors[] = 'Poskytovateľ č. ' . $number . ' má duplicitné IRI';
                }
			}
		}

		return $errors;
	}

	private function renderSingleElement(int $index, array $value, string $id, string $name): void {
        $count = self::getPublisherDatasetsCount($value['iri'] ?? '');
		?>

		<div class="wp-lkod-line-element" data-i="<?php echo esc_attr($index)?>">
			<div>
				<div><label for="<?php echo esc_attr($id . 'name')?>">Názov</label></div>
				<div><input type="text" id="<?php echo esc_attr($id . 'name')?>" name="<?php echo esc_attr($name . '[name]')?>" value="<?php echo esc_attr($value['name'] ?? '');?>"></div>
			</div>
			<div>
				<div><label for="<?php echo esc_attr($id . 'iri')?>">IRI</label></div>
				<div><input type="text" id="<?php echo esc_attr($id . 'iri')?>" name="<?php echo esc_attr($name . '[iri]')?>" value="<?php echo esc_attr($value['iri'] ?? '');?>" style="min-width: 350px"></div>
			</div>
            <div style="margin-top: 20px">
                <?php if ($index > 0 && $count === 0):?>
                    <button class="button">
                        Odstrániť
                    </button>
                <?php else:?>
                    <div style="line-height: 30px">
                        Počet datasetov poskytovateľa: <?php echo esc_html($count) ?>
                    </div>
                <?php endif;?>
            </div>
		</div>

		<?php
	}

	protected function renderJsAddElement(string $name): void {
		?>

		const labelText = <?php echo wp_json_encode($this->getLabel()) ?>;
		const name = <?php echo wp_json_encode($name) ?>;

		let maxIndex = 0;
		parent.find('.wp-lkod-line-element').each(function(_, e) {
			const i = parseInt($(e).attr('data-i'));
			if (i > maxIndex) {
				maxIndex = i;
			}
		})

		const nextIndex = maxIndex + 1;
		const newId = id + '-el-' + nextIndex;

		const el = $(document.createElement('div'));
		el.attr('class', 'wp-lkod-line-element');
		el.attr('data-i', nextIndex)

		const addInput = function(l, n, id) {
			const div = $(document.createElement('div'));
			el.append(div);

			const labelDiv = $(document.createElement('div'));
			div.append(labelDiv);
			const label = $(document.createElement('label'));

			labelDiv.append(label);
			label.text(l);
			label.attr('for', id);

			const inputDiv = $(document.createElement('div'));
			div.append(inputDiv);
			const input = $(document.createElement('input'));
			inputDiv.append(input);
			input.attr('type', 'text');
			input.attr('name', n);
			input.attr('id', id);
			input.val('');
		}

		addInput('Názov', name + '[' + nextIndex + '][name]', newId + '-name');
		addInput('IRI', name + '[' + nextIndex + '][iri]', newId + '-iri');

		const buttonDiv = $(document.createElement('div'));
		buttonDiv.attr('style', 'margin-top: 20px');
		el.append(buttonDiv);
		const button = $(document.createElement('button'));
		buttonDiv.append(button);
		button.attr('class', 'button');
		button.text('Odstrániť');
		button.click(removeButtonClick);

		parent.append(el);

		<?php
	}

	protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
		$defaultId = $ns->prefixIdentifier($this->getName());

		$publishers = empty($value) ? [] : (array)$value;
		if (empty($publishers)) {
			$publishers = [['name' => '', 'iri' => '']];
		}
		?>

		<h2 style="margin-bottom: 0.5em">
			<?php echo esc_html($this->getLabel()) ?>
		</h2>

		<div>
			<?php $this->renderErrors($errors) ?>

			<div class="wp-lkod-line-elements" id="<?php echo esc_attr($defaultId . '-elements')?>">
				<?php foreach ($publishers as $index => $publisher):?>
					<?php $this->renderSingleElement($index, $publisher, $defaultId . '-el-' . $index, $ns->prefixName($this->getName() . '[' . $index . ']'))?>
				<?php endforeach;?>
			</div>

			<button id="<?php echo esc_attr($defaultId . '-add')?>" class="button">
				Pridať ďalšieho poskytovateľa
			</button>

			<script>
                jQuery(document).ready(function($) {
                    const id = <?php echo wp_json_encode($defaultId) ?>;
                    const parent = $('#' + id + '-elements');

                    const removeButtonClick = function (e) {
                        e.preventDefault();

                        const el = $(e.target).closest('.wp-lkod-line-element');
                        el.remove();

                        return false;
                    }

                    parent.find('.wp-lkod-line-element button').click(removeButtonClick);

                    $('#' + id + '-add').click(function(e) {
                        e.preventDefault();

						<?php $this->renderJsAddElement($ns->prefixName($this->getName()));?>

                        return false;
                    });
                })
			</script>
		</div>

		<?php
	}
}