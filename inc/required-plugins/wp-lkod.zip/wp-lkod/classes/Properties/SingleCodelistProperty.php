<?php

namespace Mirri\Lkod\Properties;

use EasyRdf\Graph;
use Mirri\Lkod\Codelists\ICodelist;
use Mirri\Lkod\Entity;
use Mirri\Lkod\SingleValueProperty;
use Mirri\Lkod\Validators\InListValidator;

abstract class SingleCodelistProperty extends SingleValueProperty {
	private ICodelist $codelist;

	public function __construct(Entity $entity, string $name, string $label, bool $isRequired, ICodelist $codelist) {
		parent::__construct($entity, $name, $label, $isRequired);
		$this->codelist = $codelist;
		if ($isRequired) {
			$this->addValidator(new InListValidator($this->codelist->getKeys()));
		}
	}

	public function getCodelist(): ICodelist {
		return $this->codelist;
	}

	public function getDataType(): string {
		return 'string';
	}

	public function filterValue($value): string {
		return (string)wp_scrub_utf8((string)parent::filterValue($value));
	}

	public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
		$this->addPostTriplesAsUris($postId, $g, $subject, $predicate);
	}

	public function addTriples(mixed $value, Graph $g, string $subject, string $predicate): void {
		$this->addTriplesAsUris($value, $g, $subject, $predicate);
	}
}