<?php

namespace Mirri\Lkod\Properties;

use EasyRdf\Graph;
use Mirri\Lkod\Validators\UriValidator;

class UriProperty extends PlainSingleProperty {
    protected function init(): void {
        $this->addValidator(new UriValidator($this->getSettings()->getAllowedIriSchemes()));
    }

	public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
		$this->addPostTriplesAsUris($postId, $g, $subject, $predicate);
	}

	public function addTriples(mixed $value, Graph $g, string $subject, string $predicate): void {
		$this->addTriplesAsUris($value, $g, $subject, $predicate);
	}
}