<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\LanguageDependentProperty;
use Mirri\Lkod\Settings\Language;

class KeywordsProperty extends LanguageDependentProperty {
    public function isSingleValued(): bool {
        return false;
    }

    protected function filterSingleLanguageValue($value): array {
        return self::parseValues($value);
    }

    public static function parseValues($value): array {
        $values = [];
        if (is_array($value)) {
            $values = $value;
        } else {
            $value = (string) wp_scrub_utf8( (string) $value );
            foreach (explode(PHP_EOL, $value) as $line) {
                foreach (explode(',', $line) as $keyword) {
                    $keyword = trim($keyword);
                    if (!empty($keyword)) {
                        $values[] = $keyword;
                    }
                }
            }
        }
        return $values;
    }

    protected function renderLanguageElementAndErrors(Language $language, $value, array $errors, string $id, string $name): void {
        ?>

        <div class="wp-lkod-form-label-wrap">
            <label for="<?php echo esc_attr($id)?>">
                <?php $this->renderLabelContent($language); ?>
            </label>
        </div>

        <?php $this->renderErrors($errors); ?>

        <?php
        $langValues = [];
        foreach ($value as $keyword) {
            $keyword = trim($keyword);
            if (!empty($keyword)) {
                $langValues[] = $keyword;
            }
        }
        $compoundLangValue = implode(PHP_EOL, $langValues);
        ?>

        <div>
            <textarea id="<?php echo esc_attr($id)?>" rows="5" name="<?php echo esc_attr($name); ?>" style="width: 100%;"><?php echo esc_textarea($compoundLangValue)?></textarea>
        </div>

        <?php
    }
}