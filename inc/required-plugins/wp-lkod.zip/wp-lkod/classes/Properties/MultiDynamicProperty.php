<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\IFormNamespace;

abstract class MultiDynamicProperty extends MultiProperty {
	abstract protected function renderSingleElement(int $index, mixed $value, string $idPrefix, string $name): void;

	abstract protected function renderJsAddElement(string $name): void;

	protected function renderMultiElements(array $values, array $errors, IFormNamespace $ns): void {
        $id = $ns->prefixIdentifier($this->getName());
        $name = $ns->prefixName([$this->getName(), '']);
		?>

		<div>
			<?php $this->renderErrors($errors) ?>

			<div class="wp-lkod-line-elements" id="<?php echo esc_attr($id . '-elements')?>">
				<?php foreach ($values as $index => $v):?>
					<?php $this->renderSingleElement($index, $v, $id, $name) ?>
				<?php endforeach;?>
			</div>

			<button id="<?php echo esc_attr($id . '-add')?>" class="button">
				Pridať ďalšiu hodnotu
			</button>

			<script>
                jQuery(document).ready(function($) {
                    const id = <?php echo wp_json_encode($id) ?>;
                    const parent = $('#' + id + '-elements');

                    const removeButtonClick = function (e) {
                        e.preventDefault();

                        const el = $(e.target).closest('.wp-lkod-line-element');
                        el.remove();

                        return false;
                    }

                    parent.find('.wp-lkod-line-element button').click(removeButtonClick);

                    $('#' + id + '-add').click(function(e) {
                        e.preventDefault();

                        <?php $this->renderJsAddElement($name);?>

                        return false;
                    });
                })
			</script>
		</div>

		<?php
	}

	protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
		?>

		<div style="margin-bottom: 0.5em" <?php if ($this->isRequired()): ?> class="label-required"<?php endif; ?>>
			<?php echo esc_html($this->getLabel()) ?>
            <?php $this->renderRequiredLabelText()?>
		</div>

		<?php $this->renderMultiElements((array)$value, $errors, $ns) ?>

		<?php
	}
}