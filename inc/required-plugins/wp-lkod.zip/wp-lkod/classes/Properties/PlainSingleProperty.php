<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\SingleValueProperty;

class PlainSingleProperty extends SingleValueProperty {
	public function getDataType(): string {
		return 'string';
	}

	public function filterValue(mixed $value): mixed {
		return (string)wp_scrub_utf8((string)parent::filterValue($value));
	}

	public function validateValue(mixed $value): array {
		$errors = parent::validateValue($value);
		if ($value !== null && !is_string($value)) {
			$errors[] = 'Hodnota nie je text';
		}
		return $errors;
	}

	protected function renderPlainElement(?string $value, array $errors, string $name, string $id): void {
        ?>

        <div class="wp-lkod-form-label-wrap">
            <label for="<?php echo esc_attr($id)?>" <?php if ($this->isRequired()): ?> class="required"<?php endif; ?>>
                <?php echo esc_html($this->getLabel())?>
                <?php $this->renderRequiredLabelText(); ?>
            </label>
        </div>

        <?php $this->renderErrors($errors); ?>

        <div>
            <input id="<?php echo esc_attr($id)?>" type="text" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value)?>" style="width: 100%;">
        </div>

        <?php
	}

	protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
        $id = $ns->prefixIdentifier($this->getName());
        $name = $ns->prefixName($this->getName());
		$this->renderPlainElement($value, $errors, $name, $id);
	}
}