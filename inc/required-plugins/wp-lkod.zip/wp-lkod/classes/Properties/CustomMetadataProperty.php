<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\Entities\DataService;
use Mirri\Lkod\Entities\Dataset;
use Mirri\Lkod\Entities\Distribution;
use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\Validators\UriValidator;

class CustomMetadataProperty extends MultiProperty {
	private static array $types = ['text' => 'Text', 'date' => 'Dátum', 'list' => 'Zoznam', 'url' => 'URL', 'email' => 'E-mail'];

	private static array $entities = [Dataset::TYPE => 'Datasety', Distribution::TYPE => 'Distribúcie', DataService::TYPE => 'Dátové služby'];

    public function getPostMeta(): array {
        $meta = parent::getPostMeta();
        $meta['show_in_rest'] = [
            'schema' => [
                'type' => 'array',
                'items' => [
                    'type' => 'object',
                    'properties' => [
                        'name' => ['type' => 'string', 'required' => true],
                        'label' => ['type' => 'string', 'required' => true],
                        'type' => ['type' => 'string', 'required' => true],
                        'list' => ['type' => 'string', 'required' => false],
                        'use' => ['type' => 'array', 'required' => false, 'items' => ['type' => 'string']],
                    ],
                    'additionalProperties' => false,
                ]
            ]
        ];
        return $meta;
    }

	public function getDataType(): string {
		return 'array';
	}

	public function filterValue(mixed $value): array {
		$value = array_values(array_filter((array)$value));
        foreach ($value as &$metadata) {
            if (empty($metadata['name'])) {
                $hash = hash('sha256', ($metadata['type'] ?? '') . '_' .  ($metadata['label'] ?? '') . '_' . time());
                $metadata['name'] = 'custom_md_' . substr($hash, 0, 12);
            }
        }
        return $value;
	}

	public function validateValue(mixed $value): array {
		$errors = parent::validateValue($value);

        $newLabels = [];

		foreach ($value as $index => $publisher) {
			$number = $index + 1;
			if (!isset($publisher['name']) || trim($publisher['name']) === '') {
				$errors[] = 'Metaúdaj č. ' . $number . ' nemá vyplnené názov';
			} elseif (!in_array($publisher['name'], $newLabels, true)) {
                $newLabels[] = $publisher['name'];
            } else {
                $errors[] = 'Metaúdaj č. ' . $number . ' má duplicitný názov';
            }

			if (empty($publisher['type']) || !isset(self::$types[$publisher['type']])) {
				$errors[] = 'Metaúdaj č. ' . $number . ' nemá vyplnený typ';
			}
		}

		return $errors;
	}

	private function renderSingleElement(int $index, array $value, string $id, string $name): void {
		?>

		<div class="wp-lkod-block-element" data-i="<?php echo esc_attr($index)?>" style="padding-left: 20px; margin-bottom: 1em">
            <input type="hidden" name="<?php echo esc_attr($name . '[name]')?>" value="<?php echo esc_attr($value['name'] ?? '');?>">
			<div style="margin-bottom: 1em">
                <div><label for="<?php echo esc_attr($id . 'label')?>">Názov metaúdaju</label></div>
                <div><input type="text" id="<?php echo esc_attr($id . 'label')?>" name="<?php echo esc_attr($name . '[label]')?>" value="<?php echo esc_attr($value['label'] ?? '');?>"></div>
            </div>

            <div style="margin-bottom: 1em">
				<div><label for="<?php echo esc_attr($id . 'type')?>">Typ údaju</label></div>
				<div>
					<select id="<?php echo esc_attr($id . 'type')?>" name="<?php echo esc_attr($name . '[type]')?>" readonly>
						<?php foreach (self::$types as $typeKey => $typeLabel): ?>
							<option value="<?php echo esc_attr($typeKey)?>" <?php echo ($value['type'] ?? '') === $typeKey ? 'selected' : ''?>><?php echo esc_html($typeLabel)?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="custom-metadata-list-options" style="margin-bottom: 1em">
				<div><label for="<?php echo esc_attr($id . 'list')?>">Zoznam povolených hodnôt</label></div>
				<div><textarea style="width: 100%" rows="5" id="<?php echo esc_attr($id . 'list')?>" name="<?php echo esc_attr($name . '[list]')?>"><?php echo esc_textarea($value['list'] ?? '');?></textarea></div>
			</div>

            <div style="margin-bottom: 1em">
				<div>
					Používať pre
				</div>
				<?php foreach (self::$entities as $entityKey => $entityLabel): ?>
					<label style="display: block">
						<input type="checkbox" name="<?php echo esc_attr($name . '[use][]')?>" value="<?php echo esc_attr($entityKey)?>" <?php echo in_array($entityKey, (array)($value['use'] ?? []), true) ? 'checked' : ''?> >
						<?php echo esc_html($entityLabel)?>
					</label>
				<?php endforeach; ?>
			</div>

			<button class="button">
				Odstrániť tento metaúdaj
			</button>
		</div>

		<?php
	}

	protected function renderJsAddElement(string $name): void {
		$typeOptions = [];
		foreach (self::$types as $typeKey => $typeLabel) {
			$typeOptions[] = ['k' => $typeKey, 'v' => $typeLabel];
		}

		$useOptions = [];
		foreach (self::$entities as $entityKey => $entityLabel) {
			$useOptions[] = ['k' => $entityKey, 'v' => $entityLabel];
		}
		?>

		const labelText = <?php echo wp_json_encode($this->getLabel()) ?>;
		const name = <?php echo wp_json_encode($name) ?>;
		const typeOptions = $(<?php echo wp_json_encode($typeOptions) ?>);
		const useOptions = $(<?php echo wp_json_encode($useOptions) ?>);

		let maxIndex = 0;
		parent.find('.wp-lkod-block-element').each(function(_, e) {
			const i = parseInt($(e).attr('data-i'));
				if (i > maxIndex) {
				maxIndex = i;
			}
		})

		const nextIndex = maxIndex + 1;
		const newId = id + '-el-' + nextIndex;

		const el = $(document.createElement('div'));
		el.attr('class', 'wp-lkod-block-element');
        el.attr('style', 'padding-left: 20px; margin-bottom: 1em');
		el.attr('data-i', nextIndex)

        let div = $(document.createElement('div'));
        div.attr('style', 'margin-bottom: 1em');
        el.append(div);

		let labelDiv = $(document.createElement('div'));
		let label = $(document.createElement('label'));
		label.text('Názov metaúdaju');
		labelDiv.append(label);
		label.attr('for', newId + '-label');
		div.append(labelDiv);

		let inputDiv = $(document.createElement('div'));
        div.append(inputDiv);
		let input = $(document.createElement('input'));
		inputDiv.append(input);
		input.attr('type', 'text');
		input.attr('name', name + '[' + nextIndex + '][label]');
		input.attr('id', newId + '-label');
		input.val('');

        div = $(document.createElement('div'));
        div.attr('style', 'margin-bottom: 1em');
        el.append(div);

		labelDiv = $(document.createElement('div'));
		label = $(document.createElement('label'));
		label.text('Typ údaju');
		labelDiv.append(label);
		label.attr('for', newId + '-type');
        div.append(labelDiv);

		const select = $(document.createElement('select'));
		select.attr('id', newId + '-type');
		select.attr('name', name + '[' + nextIndex + '][type]');
		typeOptions.each(function(_, value) {
			const option = $(document.createElement('option'));
			option.text(value.v);
			option.attr('value', value.k);
			select.append(option);
		})
        select.change(function() {
            showOrHideOptions($(this).closest('.wp-lkod-block-element'));
        })
        div.append(select);

        div = $(document.createElement('div'));
        div.attr('style', 'margin-bottom: 1em');
        div.attr('class', 'custom-metadata-list-options');
        el.append(div);

        labelDiv = $(document.createElement('div'));
        label = $(document.createElement('label'));
        label.text('Zoznam povolených hodnôt');
        labelDiv.append(label);
        label.attr('for', newId + '-list');
        div.append(labelDiv);

        inputDiv = $(document.createElement('div'));
        div.append(inputDiv);
        input = $(document.createElement('textarea'));
        inputDiv.append(input);
        input.attr('name', name + '[' + nextIndex + '][list]');
        input.attr('style', 'width: 100%;');
        input.attr('rows', '5');
        input.attr('id', newId + '-list');
        input.val('');

        div = $(document.createElement('div'));
        div.attr('style', 'margin-bottom: 1em');
        el.append(div);

		const useHeaderDiv = $(document.createElement('div'));
		useHeaderDiv.text('Používať pre');
		div.append(useHeaderDiv);

		useOptions.each(function(_, value) {
			const label = $(document.createElement('label'));
			const checkbox = $(document.createElement('input'));
			checkbox.attr('type', 'checkbox');
			checkbox.attr('value', value.k);
			checkbox.attr('name', name + '[' + nextIndex + '][use][]');
			label.append(checkbox);
			label.append(' ');
			label.append(value.v);
			label.attr('style', 'display: block');
            div.append(label);
		});

		const buttonDiv = $(document.createElement('div'));
		el.append(buttonDiv);
		const button = $(document.createElement('button'));
		buttonDiv.append(button);
		button.attr('class', 'button');
		button.text('Odstrániť');
		button.click(removeButtonClick);

        showOrHideOptions(el);

		parent.append(el);

		<?php
	}

	protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
		$defaultId = $ns->prefixIdentifier($this->getName());

		$customMetadata = empty($value) ? [] : (array)$value;
		?>

		<h2>
			<?php echo esc_html($this->getLabel()) ?>
		</h2>

		<div>
			<?php $this->renderErrors($errors) ?>

			<div class="wp-lkod-line-elements" id="<?php echo esc_attr($defaultId . '-elements')?>">
				<?php foreach ($customMetadata as $index => $publisher):?>
					<?php $this->renderSingleElement($index, $publisher, $defaultId . '-el-' . $index, $ns->prefixName($this->getName() . '[' . $index . ']'))?>
				<?php endforeach;?>
			</div>

			<button id="<?php echo esc_attr($defaultId . '-add')?>" class="button">
				Pridať ďalšiu metaúdajovú vlastnosť
			</button>

			<script>
                jQuery(document).ready(function($) {
                    const id = <?php echo wp_json_encode($defaultId) ?>;
                    const parent = $('#' + id + '-elements');

                    const removeButtonClick = function (e) {
                        e.preventDefault();

                        const el = $(e.target).closest('.wp-lkod-block-element');
                        el.remove();

                        return false;
                    }

                    const showOrHideOptions = function(parent) {
                        parent = $(parent);

                        const type = parent.find('select').val();
                        parent.find('.custom-metadata-list-options').toggle(type === 'list');
                    }

                    parent.find('.wp-lkod-block-element').each(function(_, el) {
                        showOrHideOptions(el);
                    });

                    parent.find('.wp-lkod-block-element select').change(function() {
                        showOrHideOptions($(this).closest('.wp-lkod-block-element'));
                    })

                    parent.find('.wp-lkod-block-element button').click(removeButtonClick);

                    $('#' + id + '-add').click(function(e) {
                        e.preventDefault();

						<?php $this->renderJsAddElement($ns->prefixName($this->getName()));?>

                        return false;
                    });
                })
			</script>
		</div>

		<?php
	}
}