<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\Property;

class UploadProperty extends Property {

	public function isSingleValued(): bool {
		return true;
	}

	public function getDataType(): string {
		return 'integer';
	}

	protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
        $id = $ns->prefixIdentifier($this->getName());
        $name = $ns->prefixName($this->getName());
		$url = !empty($value) ? wp_get_attachment_url($value) : null;
		?>

        <div style="margin-bottom: 0.5em">
            <?php echo esc_html($this->getLabel()) ?>
        </div>

	    <div id="<?php echo esc_attr($id . '-preview'); ?>" style="margin-bottom: 1em">
            <?php if ($url) : ?>
                <a href="<?php echo esc_url($url); ?>" target="_blank">
                    <?php echo esc_html(basename($url)); ?>
                </a>
            <?php endif; ?>
        </div>

        <input type="hidden" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value); ?>" id="<?php echo esc_attr($id); ?>">

        <button type="button" class="button" id="<?php echo esc_attr($id . '-add'); ?>">
            <?php echo $value ? 'Zmeniť súbor' : 'Pridať súbor'; ?>
        </button>

        <button type="button" class="button" id="<?php echo esc_attr($id . '-remove'); ?>">
            Odstrániť súbor
        </button>

        <!--suppress JSCheckFunctionSignatures -->
        <script>
            jQuery(document).ready(function($) {
                const id = <?php echo wp_json_encode($id) ?>;
                const addButton = $('#' + id + '-add');
                const removeButton = $('#' + id + '-remove');
                const preview = $('#' + id + '-preview');
                const input = $('#' + id);
                let mediaFrame;

                const showOrHideButtons = function () {
                    const hasFile = input.val() !== '';
                    if (hasFile) {
                        addButton.text('Zmeniť súbor');
                        removeButton.show();
                    } else {
                        addButton.text('Pridať súbor');
                        removeButton.hide();
                    }
                };

                removeButton.click(function(e) {
                    e.preventDefault();

                    input.val('');
                    preview.empty();
                    showOrHideButtons();
                })

                addButton.click(function(e) {
                    e.preventDefault();

                    if (mediaFrame) {
                        mediaFrame.open();
                        return;
                    }

                    mediaFrame = wp.media({
                        title: 'Vyberte súbor',
                        button: { text: 'Použiť súbor' },
                        multiple: false
                    });

                    mediaFrame.on('select', function () {
                        const attachment = mediaFrame.state().get('selection').first().toJSON();

                        input.val(attachment.id);
                        const link = $(document.createElement('a'));
                        link.attr('href', attachment.url);
                        link.attr('target', '_blank');
                        link.text(attachment.filename);
                        preview.empty().append(link);

                        showOrHideButtons();
                    });

                    mediaFrame.open();
                });

                showOrHideButtons();
            });
        </script>

        <?php
	}
}