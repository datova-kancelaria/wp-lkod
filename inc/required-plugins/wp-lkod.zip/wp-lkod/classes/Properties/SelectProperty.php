<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\IFormNamespace;

class SelectProperty extends SingleCodelistProperty {
    private string $emptyValue = '';

    public function getEmptyValue(): string {
        return $this->emptyValue;
    }

    public function setEmptyValue(string $emptyValue): void {
        $this->emptyValue = $emptyValue;
    }

    protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
        $id = $ns->prefixIdentifier($this->getName());
        $name = $ns->prefixName($this->getName());
        $options = [];
        $emptyValue = $this->getEmptyValue();
        if (!empty($emptyValue)) {
            $options[''] = $emptyValue;
        }
        foreach ($this->getCodelist() as $k => $v) {
            $options[$k] = $v;
        }
        ?>

        <div class="wp-lkod-form-label-wrap">
            <label for="<?php echo esc_attr($id)?>" <?php if ($this->isRequired()): ?> class="required"<?php endif; ?>>
                <?php echo esc_html($this->getLabel())?>
                <?php $this->renderRequiredLabelText(); ?>
            </label>
        </div>

        <?php $this->renderErrors($errors); ?>

        <select id="<?php echo esc_attr($id)?>" name="<?php echo esc_attr($name)?>">
            <?php foreach ($options as $k => $v):?>
                <option value="<?php echo esc_attr($k)?>"<?php echo ($value === (string)$k) ? ' selected' : ''?>><?php echo esc_html($v)?></option>
            <?php endforeach;?>
        </select>

        <?php
    }
}