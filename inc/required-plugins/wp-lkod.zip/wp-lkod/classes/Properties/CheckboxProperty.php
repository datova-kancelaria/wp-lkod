<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\SingleValueProperty;

class CheckboxProperty extends SingleValueProperty {
	public function getDataType(): string {
        return 'boolean';
    }

	public function filterValue($value): bool {
		return (bool)$value;
	}

    protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
        $id = $ns->prefixIdentifier($this->getName());
        $name = $ns->prefixName($this->getName());
        ?>

        <input type="hidden" name="<?php echo esc_attr($name) ?>" value="0">
        <label>
            <input type="checkbox" <?php echo $value ? 'checked' : '' ?> name="<?php echo esc_attr($name) ?>" id="<?php echo esc_attr($id) ?>" value="1">
            <?php echo esc_html($this->getLabel()) ?>
        </label>

        <?php
    }
}