<?php

namespace Mirri\Lkod\Properties;

use EasyRdf\Graph;
use EasyRdf\Literal;
use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\KnownUris;
use Mirri\Lkod\SingleValueProperty;

class TimeResolutionProperty extends SingleValueProperty {
	private static array $units = ['y' => 'roky', 'mo' => 'mesiace', 'd' => 'dni', 'h' => 'hodiny', 'm' => 'minúty', 's' => 'sekundy'];

	private static array $emptyValue = ['', 'd'];

	public function getDataType(): string {
		return 'string';
	}

    public static function normalizeValue($value): array {
        if (is_array($value)) {
            $c = '';
            $u = '';
            if (isset($value['value'], $value['unit'])) {
                $c = (string)$value['value'];
                $u = (string)$value['unit'];
            } else {
                $c = (string)($value[0] ?? '');
                $u = (string)($value[1] ?? '');
            }

            return [$c, $u];
        }
        return self::unserialize($value) ?? self::$emptyValue;
    }

	private static function serialize($value, string $unit): string {
		$n = !empty($value) ? filter_var($value, FILTER_VALIDATE_INT) : null;
		if (is_int($n) && $value >= 0) {
			return $n . $unit;
		}
		return '';
	}

	private static function unserialize(?string $value): ?array {
		if (!empty($value) && preg_match('/^(\d+)([a-z]+)$/', $value, $matches)) {
			return [$matches[1], $matches[2]];
		}
		return null;
	}

	public function filterValue($value): mixed {
		if (is_array($value) && isset($value['value'], $value['unit'])) {
			$serialized = self::serialize($value['value'], $value['unit']);
            if (!empty($serialized)) {
                return $serialized;
            }
		}
		return $value;
	}

    public function validateValue(mixed $value): array {
        $errors = [];
        if (is_string($value)) {
            $a = self::unserialize($value);
            if (!is_array($a)) {
                $errors[] = 'Hodnota nie je v správnom formáte';
            }
        } elseif (is_array($value)) {
            $vt = (string)($value['value'] ?? '');
            $v = (int)$vt;
            $u = (string)($value['unit'] ?? '');
            if (!empty($vt) || $v < 0) {
                $errors[] = 'Hodnota musí byť väčšia ako 0';
            }

            if (!isset(self::$units[$u])) {
                $errors[] = 'Neplatná jednotka času';
            }
        }
        return $errors;
    }

	protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
        $id = $ns->prefixIdentifier($this->getName());
        $name = $ns->prefixName($this->getName());

		$parts = self::normalizeValue($value);
		$formattedNumber = (string)$parts[0];
		$unit = $parts[1] ?? 'd';
		?>

		<div style="margin-bottom: 0.5em">
			<?php echo esc_html($this->getLabel()) ?>
		</div>

		<?php $this->renderErrors($errors); ?>

		<div>
			<div>
				<div>
					<label for="<?php echo esc_attr($id . '-value')?>" class="screen-reader-text">
						<?php echo esc_html($this->getLabel() . ' hodnota') ?>
					</label>
				</div>
				<div>
					<input id="<?php echo esc_attr($id . '-value')?>" type="text" name="<?php echo esc_attr($name.'[value]'); ?>" value="<?php echo esc_attr($formattedNumber)?>" style="width: 100%;">
				</div>
			</div>
			<div>
				<div>
					<label for="<?php echo esc_attr($id . '-unit')?>" class="screen-reader-text">
						<?php echo esc_html($this->getLabel() . ' jednotka') ?>
					</label>
				</div>
				<div>
					<select id="<?php echo esc_attr($id . '-unit')?>" name="<?php echo esc_attr($name.'[unit]'); ?>">
						<?php foreach (self::$units as $unitKey => $unitLabel): ?>
							<option value="<?php echo esc_attr($unitKey) ?>" <?php echo $unitKey === $unit ? 'selected' : '' ?>><?php echo esc_html($unitLabel) ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
		</div>

		<?php
	}

    public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
        $this->addTriples($this->getPostValue($postId), $g, $subject, $predicate);
    }

    public function addTriples(mixed $serializedValue, Graph $g, string $subject, string $predicate): void {
        $value = self::normalizeValue($serializedValue);
        $numericValue = (int)$value[0];
        if ($numericValue !== 0) {
            $sign = $numericValue < 0 ? '-' : '';
            $unit = '';
            $time = false;
            switch ($value[1]) {
                case 'y':
                    $unit = 'Y';
                    break;
                case 'mo':
                    $unit = 'M';
                    break;
                case 'd':
                    $unit = 'D';
                    break;
                case 'h':
                    $unit = 'H';
                    $time = true;
                    break;
                case 'm':
                    $unit = 'M';
                    $time = true;
                    break;
                case 's':
                    $unit = 'S';
                    $time = true;
                    break;
            }

            if (!empty($unit)) {
                $durationText = $sign . 'P' . ($time ? 'T' : '') . $numericValue . $unit;
                $g->addLiteral($subject, $predicate, Literal::create($durationText, null, KnownUris::XsdDuration));
            }
        }
    }
}