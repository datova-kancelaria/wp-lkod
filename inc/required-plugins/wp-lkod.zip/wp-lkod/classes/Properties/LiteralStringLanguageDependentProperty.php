<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\LanguageDependentProperty;
use Mirri\Lkod\Settings\Language;

class LiteralStringLanguageDependentProperty extends LanguageDependentProperty {
    public function isSingleValued(): bool {
        return true;
    }

    protected function renderLanguageElementAndErrors(Language $language, $value, array $errors, string $id, string $name): void {
        ?>

        <div class="wp-lkod-form-label-wrap">
            <label for="<?php echo esc_attr($id)?>">
                <?php $this->renderLabelContent($language); ?>
            </label>
        </div>

        <?php $this->renderErrors($errors); ?>

        <div>
            <input id="<?php echo esc_attr($id)?>" type="text" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($value)?>" style="width: 100%;">
        </div>

        <?php
    }
}