<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\IFormNamespace;

class MultiCheckboxProperty extends MultiCodelistProperty {
    public function filterValue(mixed $value): array {
        if (is_array($value)) {
            return array_values(array_filter($value));
        }
        return [];
    }

    /** @noinspection PhpRedundantOptionalArgumentInspection */
    protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
        $id = $ns->prefixIdentifier($this->getName());
        $name = $ns->prefixName([$this->getName(), '']);
        $values = (array)$value;
        ?>
        <div style="margin-bottom: 0.5em" <?php if ($this->isRequired()): ?> class="label-required"<?php endif; ?>>
            <?php echo esc_html($this->getLabel()) ?>
            <?php $this->renderRequiredLabelText()?>
        </div>
        <div>
            <?php foreach ($this->getCodelist() as $k => $v):?>
                <div>
                    <label>
                        <input type="checkbox" <?php echo in_array($k, $values, false) ? 'checked' : '' ?> name="<?php echo esc_attr($name) ?>" id="<?php echo esc_attr($id.'-'.$k) ?>" value="<?php echo esc_attr($k) ?>">
                        <?php echo esc_html($v) ?>
                    </label>
                </div>
            <?php endforeach;?>
        </div>
        <?php
    }
}