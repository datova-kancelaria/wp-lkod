<?php

namespace Mirri\Lkod\Properties;

use EasyRdf\Graph;
use Mirri\Lkod\Codelists\ISearchableOptions;
use Mirri\Lkod\Entity;
use Mirri\Lkod\Validators\InListValidator;

class AutocompleteProperty extends PlainSingleProperty {
	private ISearchableOptions $options;

    public function __construct(Entity $entity, string $name, string $label, bool $isRequired, ISearchableOptions $options) {
        parent::__construct($entity, $name, $label, $isRequired);
        $this->options = $options;
        if ($isRequired) {
            $this->addValidator(new InListValidator($options->getKeys()));
        }
    }

	public function getOptions(): ?ISearchableOptions {
		return $this->options;
	}

    public function filterValue($value): ?string {
        if (is_array($value) && isset($value['value'])) {
            $v = parent::filterValue($value['value']);
        } else {
            $v = parent::filterValue($value);
        }
        return $v === '' ? null : $v;
    }

    public function validateValue(mixed $value): array {
        $errors = parent::validateValue($value);

        if (!empty($value) && !$this->options->exists($value)) {
            $errors[] = 'Hodnota nie je z číselníka';
        }

        return $errors;
    }

    protected function renderPlainElement(?string $value, array $errors, string $name, string $id) : void {
        $valueLabel = ($value !== null ? $this->options->getLabel($value) : '') ?? '';
        parent::renderPlainElement($valueLabel, $errors, $name . '[label]', $id . '-label');
        ?>

        <input type="hidden" id="<?php echo esc_attr($id . '-hidden')?>" name="<?php echo esc_attr($name . '[value]')?>" value="<?php echo esc_attr($value)?>">

        <script>
            jQuery(document).ready(function($) {
                const id = <?php echo wp_json_encode($id)?>;
                const url = <?php echo wp_json_encode(admin_url('admin-ajax.php'))?>;
                const action = <?php echo wp_json_encode('lkod-codelist-autocomplete-' . $this->options->getAjaxAction())?>;
                const nonce = <?php echo wp_json_encode(wp_create_nonce('lkod-codelist-autocomplete'))?>;

                $('#' + id + '-label').autocomplete({
                    minLength: 1,
                    source: function (request, response) {
                        $.ajax({
                            url: url,
                            type:     'GET',
                            dataType: 'json',
                            data: {
                                action: action,
                                nonce:  nonce,
                                query:  request.term
                            },
                            success: function (data) {
                                response(data);
                            },
                            error: function () {
                                response([]);
                            },
                        });
                    },
                    select: (event, ui) => {
                        event.preventDefault();
                        jQuery('#' + id + '-label').val(ui.item.label);
                        jQuery('#' + id + '-hidden').val(ui.item.value);
                    },
                    change: function (event, ui) {
                        if (!ui.item || ui.item.label !== this.value) {
                            $(this).val('');
                            jQuery('#' + id + '-label').val('');
                        }
                    },
                    focus: function (event, ui) {
                        event.preventDefault();
                        $(this).val(ui.item.label);
                    }
                });
            });
        </script>

        <?php
    }

    public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
        $this->addPostTriplesAsUris($postId, $g, $subject, $predicate);
    }
}