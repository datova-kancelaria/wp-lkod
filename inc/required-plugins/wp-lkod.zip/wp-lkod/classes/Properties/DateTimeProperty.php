<?php

namespace Mirri\Lkod\Properties;

use DateTime;
use DateTimeInterface;
use EasyRdf\Graph;
use Mirri\Lkod\Helpers;
use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\SingleValueProperty;

class DateTimeProperty extends SingleValueProperty {
    private bool $defaultEditableValueShouldBeNow = false;

    public function setDefaultValueShouldBeNow(bool $value): void {
        $this->defaultEditableValueShouldBeNow = $value;
    }

    public function getDataType(): string {
        return 'string';
    }

	public function filterValue($value): ?string {
		$dt = null;
		if (is_array($value)) {
			if (!empty($value['now']) ) {
				$dt = new DateTime();
			} elseif (isset($value['date'], $value['time'])) {
				$dt = DateTime::createFromFormat('j.n.Y G:i:s', str_replace(' ', '', $value['date']) . ' ' . str_replace(' ', '', $value['time']), Helpers::getDefaultTimezone());
			}
		} elseif (is_string($value)) {
			$dt = Helpers::getDateValue($value);
		}

		if ($dt instanceof DateTimeInterface) {
			return $dt->format(DateTimeInterface::ATOM);
		}
		return null;
	}

    protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
        $id = $ns->prefixIdentifier($this->getName());
        $name = $ns->prefixName($this->getName());

        $isNow = empty($value) || $value === 'now' || $this->defaultEditableValueShouldBeNow;
        $date = Helpers::getDateValue($value) ?? new DateTime();

        $datePart = $date->format('j. n. Y');
        $timePart = $date->format('G:i:s');
        ?>

        <div style="margin-bottom: 0.5em">
            <?php echo esc_html($this->getLabel()) ?>
        </div>

        <?php $this->renderErrors($errors); ?>

        <div>
            <label for="<?php echo esc_attr($id . '-now')?>">
                <input type="radio" name="<?php echo esc_attr($name . '[now]') ?>" class="<?php echo esc_attr($id . '-selector') ?>" id="<?php echo esc_attr($id . '-now') ?>" value="1" <?php echo $isNow ? 'checked' : '' ?>>
                <?php echo esc_html('aktuálny dátum a čas')?>
            </label>
        </div>

        <div>
            <label for="<?php echo esc_attr($id . '-custom')?>">
                <input type="radio" name="<?php echo esc_attr($name . '[now]') ?>" class="<?php echo esc_attr($id . '-selector') ?>" id="<?php echo esc_attr($id . '-custom') ?>" value="0" <?php echo !$isNow ? 'checked' : '' ?>>
                <?php echo esc_html('iný dátum a čas')?>
            </label>
        </div>

        <div style="display: none; column-gap: 1em;" id="<?php echo esc_attr($id . '-custom-values')?>">
            <div>
                <label for="<?php echo esc_attr($id . '-date')?>" class="screen-reader-text">
                    <?php echo esc_html($this->getLabel() . ' - dátum')?>
                </label>
                <span class="dashicons dashicons-calendar" style="display: inline-block; vertical-align: middle;"></span>
                <input type="text" name="<?php echo esc_attr($name . '[date]') ?>" id="<?php echo esc_attr($id . '-date')?>" value="<?php echo esc_attr($datePart) ?>">
            </div>
            <div>
                <label for="<?php echo esc_attr($id . '-time')?>" class="screen-reader-text">
                    <?php echo esc_html($this->getLabel() . ' - čas')?>
                </label>
                <span class="dashicons dashicons-clock" style="display: inline-block; vertical-align: middle;"></span>
                <input type="text" name="<?php echo esc_attr($name . '[time]') ?>" id="<?php echo esc_attr($id . '-time')?>" value="<?php echo esc_attr($timePart) ?>">
            </div>
        </div>

        <?php Helpers::enableDateSelector($id . '-date')?>

        <script>
            jQuery(document).ready(function($) {
                const id = <?php  echo wp_json_encode($id) ?>;

                const toggleFields = function() {
                    $('#' + id + '-custom-values').css('display', $('#' + id + '-custom').is(':checked') ? 'flex' : 'none');
                };

                $('.' + id + '-selector').click(toggleFields);

                toggleFields();
            });
        </script>

        <?php
    }

    public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
        $this->addTriples($this->getPostValue($postId), $g, $subject, $predicate);
    }

    public function addTriples(mixed $value, Graph $g, string $subject, string $predicate): void {
        $literal = Helpers::dateTimeToLiteral($value);
        if ($literal !== null) {
            $g->addLiteral($subject, $predicate, $literal);
        }
    }
}