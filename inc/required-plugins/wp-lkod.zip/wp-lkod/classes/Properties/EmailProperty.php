<?php

namespace Mirri\Lkod\Properties;

use EasyRdf\Graph;

class EmailProperty extends PlainSingleProperty {
	public function validateValue($value): array {
		if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
			return ['E-mailová adresa nie je správna'];
		}
		return [];
	}

	public function addPostTriples(int $postId, Graph $g, string $iri, string $predicate): void {
		$value = $this->getPostValue($postId);
		if (!empty($value)) {
			$g->addResource($iri, $predicate, 'mailto:' . $value);
		}
	}
}