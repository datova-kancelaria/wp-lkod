<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\IFormNamespace;

class RadioProperty extends SingleCodelistProperty {
    protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
        $id = $ns->prefixIdentifier($this->getName());
        $name = $ns->prefixName($this->getName());
        ?>

        <div style="margin-bottom: 0.5em">
            <?php echo esc_html($this->getLabel()) ?>
        </div>

        <?php $this->renderErrors($errors); ?>

        <div>
            <?php foreach ($this->getCodelist() as $k => $v):?>
                <div>
                    <label>
                        <input type="radio" <?php echo $k === $value ? 'checked' : '' ?> name="<?php echo esc_attr($name) ?>" id="<?php echo esc_attr($id.'-'.$k) ?>" value="<?php echo esc_attr($k) ?>">
                        <?php echo esc_html($v) ?>
                    </label>
                </div>
            <?php endforeach;?>
        </div>

        <?php
    }
}