<?php

namespace Mirri\Lkod\Properties;

class MultiSelectProperty extends MultiDynamicCodelistProperty {
    protected function renderSingleElement(int $index, mixed $value, string $idPrefix, string $name ): void {
        $id = $idPrefix . '-el-' . $index;
        ?>

        <div class="wp-lkod-line-element" data-i="<?php echo esc_attr($index)?>">
            <label for="<?php echo esc_attr($id)?>" class="screen-reader-text">
                <?php echo esc_html($this->getLabel()) ?>
            </label>

            <select id="<?php echo esc_attr($id)?>" name="<?php echo esc_attr($name)?>">
                <?php foreach ($this->getCodelist() as $k => $v):?>
                    <option value="<?php echo esc_attr($k)?>"<?php echo ($value === $k) ? ' selected' : ''?>><?php echo esc_html($v)?></option>
                <?php endforeach;?>
            </select>

            <button class="button">
                Odstrániť
            </button>
        </div>

        <?php
    }

    protected function renderJsAddElement(string $name): void {
        $options = [];
        foreach ($this->getCodelist() as $k => $v) {
            $options[] = ['k' => $k, 'v' => $v];
        }
        ?>

        const labelText = <?php echo wp_json_encode($this->getLabel()) ?>;
        const options = $(<?php echo wp_json_encode($options) ?>);
        const name = <?php echo wp_json_encode($name) ?>;

        let maxIndex = 0;
        parent.find('.wp-lkod-line-element').each(function(_, e) {
            const i = parseInt($(e).attr('data-i'));
            if (i > maxIndex) {
                maxIndex = i;
            }
        })

        const nextIndex = maxIndex + 1;
        const newId = id + '-el-' + nextIndex;

        const el = $(document.createElement('div'));
        el.attr('class', 'wp-lkod-line-element');
        el.attr('data-i', nextIndex)

        const label = $(document.createElement('label'));
        label.attr('for', id + '-element-' + nextIndex);
        label.attr('class', 'screen-reader-text');
        label.text(labelText);
        el.append(label);
        el.append(' ');

        const select = $(document.createElement('select'));
        select.attr('id', newId);
        select.attr('name', name);
        options.each(function(_, value) {
            const option = $(document.createElement('option'));
            option.text(value.v);
            option.attr('value', value.k);
            select.append(option);
        })
        el.append(select);
        el.append(' ');

        const button = $(document.createElement('button'));
        button.attr('class', 'button');
        button.text('Odstrániť');
        button.click(removeButtonClick);
        el.append(button);

        parent.append(el);

        <?php
    }
}