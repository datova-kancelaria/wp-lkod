<?php

namespace Mirri\Lkod\Properties;

use EasyRdf\Graph;
use Mirri\Lkod\LanguageDependentProperty;
use Mirri\Lkod\Settings\Language;

class LiteralTextareaLanguageDependentProperty extends LanguageDependentProperty {
    public function isSingleValued(): bool {
        return true;
    }

    protected function renderLanguageElementAndErrors(Language $language, $value, array $errors, string $id, string $name): void {
        ?>

        <div class="wp-lkod-form-label-wrap">
            <label for="<?php echo esc_attr($id)?>">
                <?php $this->renderLabelContent($language); ?>
            </label>
        </div>

        <?php $this->renderErrors($errors); ?>

        <div>
            <textarea id="<?php echo esc_attr($id)?>" rows="5" name="<?php echo esc_attr($name); ?>" style="width: 100%;"><?php echo esc_textarea($value)?></textarea>
        </div>

        <?php
    }
}