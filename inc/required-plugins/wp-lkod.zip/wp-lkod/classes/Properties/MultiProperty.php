<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\IValidator;
use Mirri\Lkod\Property;

abstract class MultiProperty extends Property {
	/**
	 * @var IValidator[]
	 */
	private array $singleValueValidators = [];

	public function getSingleValueValidators(): array {
		return $this->singleValueValidators;
	}

	public function addSingleValueValidator(IValidator $validator): void {
		$this->singleValueValidators[] = $validator;
	}

	public function isSingleValued(): bool {
		return false;
	}

	public function validateValue( mixed $value ): array {
		$errors =  parent::validateValue( $value );

		if (is_array($value)) {
			foreach ($value as $v) {
				foreach ($this->getSingleValueValidators() as $validator) {
					/** @noinspection MissUsingForeachInspection */
					foreach ($validator->validate($v) as $error) {
						$errors[] = $error;
					}
				}
			}
		} elseif ($value !== null) {
			$errors[] = 'Hodnota nie je platná';
		}

		return $errors;
	}
}