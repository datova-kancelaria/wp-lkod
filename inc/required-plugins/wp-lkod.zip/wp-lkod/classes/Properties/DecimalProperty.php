<?php

namespace Mirri\Lkod\Properties;

use EasyRdf\Graph;
use EasyRdf\Literal;
use Mirri\Lkod\KnownUris;

class DecimalProperty extends PlainSingleProperty {
	public function getDataType(): string {
		return 'number';
	}

	public function filterValue($value): mixed {
		$value = str_replace(',', '.', trim((string)$value));
		$n = filter_var($value, FILTER_VALIDATE_FLOAT);
		return is_numeric($n) ? $n : $value;
	}

	public function validateValue(mixed $value): array {
		if (!empty($value) && !is_numeric($value)) {
			return ['Hodnota nie je číslo'];
		}

		if (is_numeric($value) && $value < 0) {
			return ['Hodnota nie je kladné číslo'];
		}

		return [];
	}

	protected function renderPlainElement($value, array $errors, string $name, string $id): void {
		$number = $this->filterValue($value);
		$formattedNumber = is_numeric($number) ? number_format($number, 2, ',', ' ') : $number;
		parent::renderPlainElement($formattedNumber, $errors, $name, $id);
	}

	public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
		$this->addTriples($this->getPostValue($postId), $g, $subject, $predicate);
	}

	public function addTriples(mixed $sourceValue, Graph $g, string $subject, string $predicate): void {
		$value = (float)$sourceValue;
		if ($value > 0) {
			$g->addLiteral($subject, $predicate, Literal::create($value, null, KnownUris::XsdDecimal));
		}
	}
}