<?php

namespace Mirri\Lkod\Properties;

use EasyRdf\Graph;
use Mirri\Lkod\Codelists\ICodelist;
use Mirri\Lkod\Entity;
use Mirri\Lkod\Validators\InListValidator;

abstract class MultiDynamicCodelistProperty extends MultiDynamicProperty {
	private ICodelist $codelist;

	public function __construct(Entity $entity, string $name, string $label, bool $isRequired, ICodelist $codelist) {
		parent::__construct($entity, $name, $label, $isRequired);
		$this->codelist = $codelist;
		if ($isRequired) {
			$this->addSingleValueValidator(new InListValidator($this->codelist->getKeys()));
		}
	}

	public function getCodelist(): ICodelist {
		return $this->codelist;
	}

	public function getDataType(): string {
		return 'string';
	}

	public function addPostTriples(int $postId, Graph $g, string $subject, string $predicate): void {
		$this->addPostTriplesAsUris($postId, $g, $subject, $predicate);
	}
}