<?php

namespace Mirri\Lkod\Properties;

use Mirri\Lkod\Entity;
use Mirri\Lkod\IFormNamespace;
use Mirri\Lkod\Property;

class ObjectProperty extends Property {
	private Entity $referencedEntity;

	public function __construct(Entity $entity, string $name, string $label, bool $isRequired, Entity $referencedEntity) {
		parent::__construct($entity, $name, $label, $isRequired);
		$this->referencedEntity = $referencedEntity;
	}

	public function isSingleValued(): bool {
		return false;
	}

	public function getDataType(): string {
		return 'object';
	}

    public function getPostMeta(): array {
        $meta = parent::getPostMeta();
        $meta['show_in_rest'] = [
            'schema' => [
                'type' => 'object',
                'properties' => [],
                'additionalProperties' => true,
            ],
        ];
        return $meta;
    }

	public function filterValue($value): array {
		return array_map(function($objectValues) {
			return $this->referencedEntity->filterValues($objectValues);
		}, (array)$value);
	}

	public function validateValue($value): array {
		$errors = [];

		foreach ($value as $key => $objectValues) {
			$state = $this->referencedEntity->validateValues($objectValues);
			if (!empty($state['errors']) && is_array($state['errors'])) {
				$errors[$key] = $state['errors'];
			}
		}

		return $errors;
	}

	protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void {
		if (empty($value)) {
			$value = [];
		}
		?>

		<div>
            <?php $this->referencedEntity->renderMultipleFormStates($value, $ns->createInnerNamespace([$this->getName()]), $errors); ?>
		</div>

		<?php
	}
}