<?php

namespace Mirri\Lkod\Properties;

class LiteralStringProperty extends PlainSingleProperty {

}