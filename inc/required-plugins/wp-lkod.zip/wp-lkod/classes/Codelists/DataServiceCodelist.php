<?php

namespace Mirri\Lkod\Codelists;

use Mirri\Lkod\Entities\DataService;

class DataServiceCodelist extends PostTypeCodelist {
	public function __construct() {
		parent::__construct(DataService::TYPE);
	}
}