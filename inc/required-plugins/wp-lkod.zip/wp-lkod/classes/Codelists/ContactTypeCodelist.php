<?php

namespace Mirri\Lkod\Codelists;

use Mirri\Lkod\KnownUris;

class ContactTypeCodelist extends StaticCodelist {
	public const Organization = 'organization';

	public const Individual = 'individual';

	public function __construct() {
		parent::__construct([
			self::Organization => 'Organizácia',
			self::Individual => 'Osoba',
		]);
	}

	public static function getUri(string $type): string {
		return match ($type) {
			self::Individual => KnownUris::VcardIndividual,
			default => KnownUris::VcardOrganization,
		};
	}
}