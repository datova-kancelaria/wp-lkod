<?php

namespace Mirri\Lkod\Codelists;

use ArrayIterator;
use Mirri\Lkod\Settings;

class PublisherCodelist extends StaticCodelist {
	public function __construct(Settings $settings) {
		$options = [];

		foreach ($settings->getPublishers() as $publisher) {
			if ($publisher->isDefault()) {
				$options[$publisher->getIri()] = $publisher->getName();
			}
		}

		foreach ($settings->getPublishers() as $publisher) {
			if (!$publisher->isDefault()) {
				$options[$publisher->getIri()] = $publisher->getName();
			}
		}

		parent::__construct($options);
	}
}