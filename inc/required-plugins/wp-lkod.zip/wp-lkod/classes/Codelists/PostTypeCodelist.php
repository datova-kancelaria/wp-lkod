<?php

namespace Mirri\Lkod\Codelists;

class PostTypeCodelist extends StaticCodelist {
	public function __construct(string $type) {
		$options = [];
		/** @noinspection SpellCheckingInspection */
		foreach (get_posts([ 'post_type' => $type, 'numberposts' => -1, 'post_status' => 'any']) as $post) {
			$id = (string)$post->ID;
			$options[$id] = $post->post_title;
		}
		parent::__construct($options);
	}
}