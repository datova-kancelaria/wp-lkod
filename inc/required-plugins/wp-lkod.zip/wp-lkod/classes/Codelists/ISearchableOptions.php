<?php

namespace Mirri\Lkod\Codelists;

interface ISearchableOptions extends ICodelist {
	public function search(string $query): array;

	public function exists(string $value): bool;

	public function getLabel(string $value): ?string;

	public function getAjaxAction(): string;
}