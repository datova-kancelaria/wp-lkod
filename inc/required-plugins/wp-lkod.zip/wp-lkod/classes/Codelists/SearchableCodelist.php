<?php

namespace Mirri\Lkod\Codelists;

class SearchableCodelist implements ISearchableOptions {
	private ICodelist $options;

	/**
	 * @var array<int, string>
	 */
	private array $indexToWord;

	/**
	 * @var array<string, int>
	 */
	private array $wordToIndex;

	/**
	 * @var array<string, int[]>
	 */
	private array $prefixToWordIndices;

	/**
	 * @var array<int, int[]>
	 */
	private array $wordIndexToValueIndices;

	/**
	 * @var array<int, string>
	 */
	private array $indexToValue;

	/**
	 * @var array<string, string>
	 */
	private array $all;

	public function __construct(ICodelist $options) {
		$this->options = $options;
		
		$this->loadIndex();
	}
	
	private function addWord(string $word, int $index): void
	{
		$word = trim($word);
		if (!empty($word)) {
			$word = mb_strtolower($word, 'UTF-8');

			if (!isset($this->wordToIndex[$word])) {
				$wordIndex = count($this->indexToWord);
				$this->indexToWord[] = $word;
				$this->wordToIndex[$word] = $wordIndex;

				$len = mb_strlen($word, 'UTF-8');
				for ($i = 0; $i < $len && $i < 3; $i++) {
					$prefix = mb_substr($word, 0, $i + 1, 'UTF-8');
					if (!isset($this->prefixToWordIndices[$prefix])) {
						$this->prefixToWordIndices[$prefix] = [];
					}
					$this->prefixToWordIndices[$prefix][] = $wordIndex;
				}
			} else {
				$wordIndex = $this->wordToIndex[$word];
			}

			if (!isset($this->wordIndexToValueIndices[$wordIndex])) {
				$this->wordIndexToValueIndices[$wordIndex] = [];
			}
			$this->wordIndexToValueIndices[$wordIndex][] = $index;
		}
	}

	private function buildIndex(): void {
		$this->prefixToWordIndices = [];
		$this->wordToIndex = [];
		$this->indexToWord = [];
		$this->wordIndexToValueIndices = [];
		$this->indexToValue = [];

		/** @noinspection PhpRedundantOptionalArgumentInspection */
		$this->all = iterator_to_array($this->options, true);

		/**
		 * @var string $value
		 * @var string $label
		 */
		foreach ($this->all as $value => $label) {
			$valueIndex = count($this->indexToValue);
			$this->indexToValue[] = $value;

			foreach (preg_split('/\s/u', $label) as $word) {
				$this->addWord($word, $valueIndex);

				$normalized = iconv('UTF-8', 'ASCII//TRANSLIT', $word);
				if ($normalized !== $word) {
					$this->addWord($normalized, $valueIndex);
				}
			}
		}
	}

	private function loadIndex(): void {
		$key = 'lkod-codelist-searchable'.$this->options->getCodelistKey();
		$cached = get_transient($key);
		if (is_array($cached)) {
			$this->prefixToWordIndices = $cached['prefixToWordIndices'] ?? [];
			$this->wordToIndex = $cached['wordToIndex'] ?? [];
			$this->indexToWord = $cached['indexToWord'] ?? [];
			$this->wordIndexToValueIndices = $cached['wordIndexToValueIndices'] ?? [];
			$this->indexToValue = $cached['indexToValue'] ?? [];
			$this->all = $cached['all'] ?? [];
		} else {
			$this->buildIndex();
			set_transient($key, [
				'prefixToWordIndices' => $this->prefixToWordIndices,
				'wordToIndex' => $this->wordToIndex,
				'indexToWord' => $this->indexToWord,
				'wordIndexToValueIndices' => $this->wordIndexToValueIndices,
				'indexToValue' => $this->indexToValue,
				'all' => $this->all,
			], 86400);
		}
	}

	private function getIndicesForWord(string $term): array {
		$prefix = mb_strtolower(mb_strlen($term, 'UTF-8') > 3 ? mb_substr($term, 0, 3, 'UTF-8') : $term);
		$termLen = (int)mb_strlen($term, 'UTF-8');
		$indices = [];
		if (isset($this->prefixToWordIndices[$prefix])) {
			foreach ($this->prefixToWordIndices[$prefix] as $wordIndex) {
				if (isset($this->indexToWord[$wordIndex])) {
					$word = $this->indexToWord[$wordIndex];
					if (isset($this->wordIndexToValueIndices[$wordIndex]) && $termLen <= mb_strlen($word, 'UTF-8') && mb_strpos($word, $term, 0, 'UTF-8') === 0) {
						/** @noinspection MissUsingForeachInspection */
						foreach ($this->wordIndexToValueIndices[$wordIndex] as $index) {
							$indices[] = $index;
						}
					}
				}
			}
		}
		return array_unique($indices);
	}

	public function search(string $query): array {
		$query = mb_strtolower($query, 'UTF-8');
		$terms = preg_split('/\s/u', $query);

		foreach (array_keys($terms) as $i) {
			$term = trim($terms[$i]);
			if (empty($term)) {
				unset($terms[$i]);
			}
		}
		$terms = array_values($terms);

		if (empty($terms)) {
			return [];
		}

		foreach ($terms as $term) {
			$termIndices = $this->getIndicesForWord($term);
			if (!isset($selectedIndices)) {
				$selectedIndices = $termIndices;
			} else {
				$selectedIndices = array_intersect($selectedIndices, $termIndices);
			}
		}

		$selected = [];

		if (isset($selectedIndices)) {
			foreach ($selectedIndices as $index) {
				if (isset($this->indexToValue[$index])) {
					$value = $this->indexToValue[$index];
					if (isset($this->all[$value])) {
						$selected[$value] = $this->all[$value];
					}
				}
			}
		}

		DefaultCodelists::sort($selected);

		return $selected;
	}

	public function getAjaxAction(): string {
		return $this->options->getCodelistKey();
	}

	public function getLabel(string $value): ?string {
		return $this->all[$value] ?? null;
	}

	public function exists(string $value): bool {
		return isset($this->all[$value]);
	}

	public function getCodelistKey(): string {
		return $this->options->getCodelistKey();
	}

	public function getKeys(): array {
		return $this->options->getKeys();
	}

	public function getOptions(): array {
		return $this->options->getOptions();
	}

	public function getIterator(): \Traversable {
		return $this->options->getIterator();
	}
}