<?php

namespace Mirri\Lkod\Codelists;

use IteratorAggregate;

interface ICodelist extends IteratorAggregate {

	public function getCodelistKey(): string;

	public function getKeys(): array;

	public function getOptions(): array;

	public function getLabel(string $key): ?string;
}