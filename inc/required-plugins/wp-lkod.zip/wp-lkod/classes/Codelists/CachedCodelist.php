<?php

namespace Mirri\Lkod\Codelists;

use ArrayIterator;
use WP_Error;

abstract class CachedCodelist implements ICodelist {
	private ?array $options = null;

	private const expiration = 86400;

	abstract protected function loadOptions(): array|WP_Error;

	abstract public function getCodelistKey(): string;

	public function getOptions(): array {
		if ($this->options === null) {
			$key = 'lkod-codelist-'.$this->getCodelistKey();
			$cached = get_transient($key);
			if (is_array($cached)) {
				$this->options = $cached;
			} else {
				$loadedOptions = $this->loadOptions();

				if (is_wp_error($loadedOptions)) {
					return $loadedOptions;
				}

				DefaultCodelists::sort($loadedOptions);

				$this->options = $loadedOptions;

				set_transient($key, $this->options, self::expiration);
			}
		}
		return $this->options;
	}

	public function getKeys(): array {
		return array_keys($this->getOptions());
	}

	public function getIterator(): ArrayIterator {
		return new ArrayIterator($this->getOptions());
	}

	public function getLabel(string $key): ?string {
		$options = $this->getOptions();
		return $options[$key] ?? null;
	}
}