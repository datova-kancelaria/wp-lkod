<?php

namespace Mirri\Lkod\Codelists;

use ArrayIterator;

class StaticCodelist implements ICodelist {
	private array $options;

	public function __construct(array $options = [], bool $sort = true) {
		if ($sort) {
			DefaultCodelists::sort( $options);
		}
		$this->options = $options;
	}

	public function getIterator(): ArrayIterator {
		return new ArrayIterator($this->options);
	}

	public function getCodelistKey(): string {
		return '';
	}

	public function getKeys(): array {
		return array_keys($this->options);
	}

	public function getOptions(): array {
		return $this->options;
	}
	public function getLabel(string $key): ?string {
		return $this->options[$key] ?? null;
	}
}