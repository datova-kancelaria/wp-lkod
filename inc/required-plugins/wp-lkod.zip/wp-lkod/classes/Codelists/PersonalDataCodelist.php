<?php

namespace Mirri\Lkod\Codelists;

class PersonalDataCodelist extends NkodCodelist {
	protected function filterOptions(array $options): array {
		unset($options['https://data.gov.sk/def/personal-data-occurence-type/3']);
		return $options;
	}
}