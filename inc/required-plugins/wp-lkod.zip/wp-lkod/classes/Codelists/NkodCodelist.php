<?php

namespace Mirri\Lkod\Codelists;

use WP_Error;

class NkodCodelist extends CachedCodelist {
	private string $type;

	public function __construct(string $type) {
		$this->type = $type;
	}

	public function getCodelistKey(): string {
		return $this->type;
	}

	protected function filterOptions(array $options): array {
		return $options;
	}

	protected function loadOptions(): array|WP_Error {
		$url = 'https://data.slovensko.sk/codelists?keys[]='.urlencode($this->type);

		$response = wp_remote_get($url, ['timeout' => 15]);

		if (is_wp_error($response)) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code($response);
		if ($code >= 400) {
			return new WP_Error(
				'bad_response',
				"Nepodarilo sa načítať číselník z data.slovensko.sk",
				[ 'url' => $url, 'status' => $code ]
			);
		}

		$body = wp_remote_retrieve_body($response);

		$values = [];
		/** @noinspection PhpUnhandledExceptionInspection */
		foreach (json_decode( $body, true, 512, JSON_THROW_ON_ERROR) as $codelist) {
			if ( isset( $codelist['id'], $codelist['values'] ) && $codelist['id'] === $this->type && is_array( $codelist['values'] ) ) {
				foreach ($codelist['values'] as $value) {
					if ( isset( $value['id'], $value['label'] ) ) {
						$values[$value['id']] = $value['label'];
					}
				}
			}
		}

		if (count($values) === 0) {
			return new WP_Error( 'empty_body', 'Nepodarilo sa načítať správny číselník z data.slovensko.sk', [
				'url' => $url,
			] );
		}

		return $this->filterOptions($values);
	}
}