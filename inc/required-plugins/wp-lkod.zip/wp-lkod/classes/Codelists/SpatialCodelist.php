<?php

namespace Mirri\Lkod\Codelists;

use EasyRdf\Graph;
use EasyRdf\Resource;
use Exception;
use WP_Error;

class SpatialCodelist extends CachedCodelist {
	private string $url;

	public function __construct(string $url) {
		$this->url = $url;
	}

	public function getCodelistKey(): string {
		return $this->url;
	}

	protected function loadOptions(): array|WP_Error {
		$response = wp_remote_get($this->url, ['timeout' => 15]);

		if (is_wp_error($response)) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code($response);
		if ($code >= 400) {
			return new WP_Error(
				'bad_response',
				"Nepodarilo sa načítať číselník z data.slovensko.sk",
				[ 'url' => $this->url, 'status' => $code ]
			);
		}

		$body = wp_remote_retrieve_body($response);

		$values = [];
		$graph = new Graph();
		try {
			$graph->parse($body, 'turtle');

			$types = [
				'https://data.gov.sk/def/ontology/location/NUTS1',
				'https://data.gov.sk/def/ontology/location/NUTS2',
				'https://data.gov.sk/def/ontology/location/NUTS3',
				'https://data.gov.sk/def/ontology/location/LAU1',
				'https://data.gov.sk/def/ontology/location/LAU2',
			];

			foreach ($types as $type) {
				foreach ($graph->allOfType($type) as $subject) {
					if ($subject instanceof Resource) {
						$object = $subject->getLiteral('<http://www.w3.org/2004/02/skos/core#prefLabel>', 'sk');
						if ($object !== null) {
							$values[$subject->getUri()] = $object->getValue();
						}
					}
				}
			}
		} catch (Exception $e) {
			return new WP_Error(
				'parse_error',
				"Nebolo možné získať číselník",
				[ 'url' => $this->url, 'message' => $e->getMessage() ]
			);
		}

		return $values;
	}
}