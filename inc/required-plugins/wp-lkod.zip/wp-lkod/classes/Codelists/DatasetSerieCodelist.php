<?php

namespace Mirri\Lkod\Codelists;

use Mirri\Lkod\Entities\Dataset;

class DatasetSerieCodelist extends StaticCodelist {
	public function __construct() {
		$options = [];

		/** @noinspection SpellCheckingInspection */
		foreach (get_posts([ 'post_type' => Dataset::TYPE, 'numberposts' => -1, 'meta_key' => 'is_serie', 'meta_value' => '1', 'post_status' => 'any']) as $post) {
			$id = (string)$post->ID;
			$options[$id] = $post->post_title;
		}

		parent::__construct($options);
	}
}