<?php

namespace Mirri\Lkod\Codelists;

use Mirri\Lkod\Entities\ContactPoint;

class ContactPointCodelist extends PostTypeCodelist {
	public function __construct() {
		parent::__construct(ContactPoint::TYPE);
	}
}