<?php /** @noinspection HttpUrlsUsage */

namespace Mirri\Lkod\Codelists;

use Collator;

class DefaultCodelists {
	private static array $codelists = [];

	private static ?Collator $collator = null;

	public static function getNkodCodelist(string $type): NkodCodelist {
		if (!isset(self::$codelists[$type])) {
			self::$codelists[$type] = new NkodCodelist($type);
		}
		return self::$codelists[$type];
	}

	public static function getDatasetTypeCodelist(): NkodCodelist {
		return self::getNkodCodelist('https://data.gov.sk/set/codelist/dataset-type');
	}

	public static function getDatasetThemeCodelist(): NkodCodelist {
		return self::getNkodCodelist('http://publications.europa.eu/resource/authority/data-theme');
	}

	public static function getFrequencyCodelist(): NkodCodelist {
		return self::getNkodCodelist('http://publications.europa.eu/resource/authority/frequency');
	}

	public static function getHvdCategoryCodelist(): NkodCodelist {
		return self::getNkodCodelist('http://data.europa.eu/bna/asd487ae75');
	}

	public static function getSpatialCodelist(): SpatialCodelist {
		$type = 'https://raw.githubusercontent.com/slovak-egov/centralny-model-udajov/refs/heads/main/cbox/national/nuts2004.ttl';
		if (!isset(self::$codelists[$type])) {
			self::$codelists[$type] = new SpatialCodelist($type);
		}
		return self::$codelists[$type];
	}

	public static function getLicenseCodelist(): NkodCodelist {
		return self::getNkodCodelist('http://publications.europa.eu/resource/authority/licence');
	}

	public static function getPersonalDataCodelist(): PersonalDataCodelist {
		$type = 'https://data.gov.sk/set/codelist/personal-data-occurence-type';
		if (!isset(self::$codelists[$type])) {
			self::$codelists[$type] = new PersonalDataCodelist($type);
		}
		return self::$codelists[$type];
	}

	public static function getFormatCodelist(): NkodCodelist {
		return self::getNkodCodelist('http://publications.europa.eu/resource/authority/file-type');
	}

	public static function getMediaTypeCodelist(): NkodCodelist {
		return self::getNkodCodelist('http://www.iana.org/assignments/media-types');
	}

	public static function getPublisherCodelist(): PublisherCodelist {
		$type = '_publishers';
		if (!isset(self::$codelists[$type])) {
			self::$codelists[$type] = new PublisherCodelist();
		}
		return self::$codelists[$type];
	}

	public static function getDefaultCollator(): Collator {
		if (!self::$collator) {
			self::$collator = new Collator('sk_SK.UTF-8');
		}
		return self::$collator;
	}

	public static function sort(array &$array): void {
		$collator = self::getDefaultCollator();
		uasort($array, static function ($a, $b) use ($collator) { return $collator->compare($a, $b); });
	}
}