<?php

namespace Mirri\Lkod\Codelists;

use Mirri\Lkod\Entities\Category;

class CategoryCodelist extends PostTypeCodelist {
	public function __construct() {
		parent::__construct(Category::TYPE);
	}
}