<?php

namespace Mirri\Lkod;

use EasyRdf\Graph;
use Mirri\Lkod\Codelists\StaticCodelist;
use Mirri\Lkod\Properties\DateProperty;
use Mirri\Lkod\Properties\EmailProperty;
use Mirri\Lkod\Properties\LiteralStringProperty;
use Mirri\Lkod\Properties\SelectProperty;
use Mirri\Lkod\Properties\UriProperty;
use WP_Post;

class Entity {
	private string $type;

	/**
	 * @var Property[]
	 */
	protected array $properties = [];

	/**
	 * @var IValidator[]
	 */
    private array $validators = [];

	private Settings $settings;

	public function __construct(Settings $settings, string $type) {
		$this->settings = $settings;
		$this->type = $type;
	}

	public function getSettings(): Settings {
		return $this->settings;
	}

	public function addProperty(Property $property): void {
		$this->properties[] = $property;
	}

	/**
	 * @return Property[]
	 */
	public function getProperties(): array {
		return $this->properties;
	}

	public function getType(): string {
		return $this->type;
	}

	public function registerPostMeta(): void {
		foreach ($this->getProperties() as $property) {
			$property->registerPostMeta();
		}
	}

    public function registerSettings(): void {
        foreach ($this->getProperties() as $property) {
            $property->registerSetting();
        }
    }

	public function renderForm(WP_Post $post, IFormNamespace $ns): void {
        /** @noinspection UnusedFunctionResultInspection */
        wp_nonce_field('wp-lkod-save-' . $this->getType(), 'wp-lkod-nonce');

		$stateKey = $this->getTransientKey('state', $post->ID);

        $errors = [];
        $commands = [];

		$state = get_transient($stateKey);
		if (is_array($state)) {
            $values = $state['values'] ?? [];
            $errors = $state['errors'] ?? [];
            $commands = $state['commands'] ?? [];
            delete_transient($stateKey);
		} else {
			$values = $this->getPostValues($post->ID);
		}

		$this->renderFormState($values, $ns, $errors, $commands);
	}

    public function renderMultipleFormStates(array $values, IFormNamespace $ns, array $errors = []): void {
        ?>

        <?php foreach ($values as $key => $objectValues): ?>

            <div class="entity-form-key-wrap">
                <?php $this->renderFormState($objectValues, $ns->createInnerNamespace([$key]), $errors[$key] ?? [], [], false); ?>
            </div>

        <?php endforeach; ?>

        <?php
    }

    public function renderFormState(array $values, IFormNamespace $ns, array $errors = [], array $commands = [], bool $showErrors = true): void {
        if ($showErrors) {
            $this->renderErrors($errors);
        }

        foreach ($this->getProperties() as $property) {
            $this->renderProperty($property, $values, $ns, $errors);
        }
    }

    protected function renderProperty(Property $property, array $values, IFormNamespace $ns, array $errors = []): void {
        $property->renderForm($property->extractValue($values), $errors[$property->getName()] ?? [], $ns);
    }

	protected function renderErrors(array $errors): void {
        $result = [];
        foreach ($errors as $key => $errorsForKey) {
            if (is_array($errorsForKey)) {
                $errorsForKey = self::flattenArray($errorsForKey);
            } else {
                $errorsForKey = [$errorsForKey];
            }

            $errorsForKey = array_unique(array_filter($errorsForKey));

            $property = null;
            foreach ($this->getProperties() as $p) {
                if ($p->getName() === $key) {
                    $property = $p;
                    break;
                }
            }

            $propertyName = $property ? $property->getLabel() . ': ' : '';

            foreach ($errorsForKey as $error) {
                $result[] = $propertyName . $error;
            }
        }

        $result = array_unique($result);

        ?>

		<?php if (!empty($result)):?>
			<div class="error">
				<?php self::renderErrorsFromList($result);?>
			</div>
		<?php endif;?>

		<?php
	}

    public static function flattenArray($array): array {
        $result = [];
        foreach ($array as $value) {
            if (is_array($value)) {
                $result = array_merge($result, self::flattenArray($value));
            } else {
                $result[] = $value;
            }
        }
        return $result;
    }

	public static function renderErrorsFromList(array $errors): void {
        $errors = self::flattenArray($errors);
		if (!empty($errors)) {
			?>
			<?php foreach ($errors as $error): ?>
				<p><?php echo esc_html($error); ?></p>
			<?php endforeach; ?>
			<?php
		}
	}

    public function validateNonce(array $input): bool {
        return isset($input['wp-lkod-nonce']) && wp_verify_nonce($input['wp-lkod-nonce'], 'wp-lkod-save-' . $this->getType());
    }

	public function saveForm(int $post_id, array $data): void {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        if (!empty($data['_command'])) {
            $state = ['values' => $this->filterValues($data), 'commands' => [$data['_command']]];
        } else {
            $state = $this->saveValues($post_id, $data);
        }

        if (empty($state['isValid'])) {
            set_transient($this->getTransientKey('state', $post_id), $state, 60);
        }
	}

    public function saveValues(int $postId, array $values): array {
        $state = $this->validateValues($values);

        if ($state['isValid']) {
            foreach ($this->getProperties() as $property) {
                $propertyValue = $property->extractValue($state['values']);
                $property->saveValue($postId, $propertyValue);
            }
            $this->onPostUpdated($postId);
        }

        return $state;
    }

    protected function onPostUpdated(int $post_id): void {

    }

	public function getPostValues(int $postId): array {
		$values = [];
		foreach ($this->getProperties() as $property) {
			$values[$property->getName()] = $property->getPostValue($postId);
		}
		return $values;
	}

    public function filterValues(array $data): array {
        $values = [];
        foreach ($this->getProperties() as $property) {
            $values[$property->getName()] = $property->filterValue($property->extractValue($data));
        }
        return $values;
    }

	/**
	 * @param array $data
	 *
	 * @return array{values: mixed, errors: array<string, string[]>, isValid: bool}
	 */
	public function validateValues(array $data): array {
		$values = [];
		$errors = [];
		foreach ($this->getProperties() as $property) {
            $rawValue = $property->extractValue($data);
			$propertyValue = $property->filterValue($rawValue);
			$propertyErrors = $property->validateValue($propertyValue);
			$values[$property->getName()] = $propertyValue;
			if (!empty($propertyErrors)) {
				$errors[$property->getName()] = $propertyErrors;
			}
		}

        $errors = array_merge_recursive($errors, $this->customValidation($values));

		$entityErrors = [];
        foreach ($this->getValidators() as $validator) {
	        /** @noinspection MissUsingForeachInspection */
	        foreach ($validator->validate($this) as $error) {
                $entityErrors[] = $error;
            }
        }
		if (!empty($entityErrors)) {
			$errors['_'] = isset($errors['_']) ? array_merge($errors['_'], $entityErrors) : $entityErrors;
		}

		return ['values' => $values, 'errors' => $errors, 'isValid' => empty($errors)];
	}

    protected function customValidation(array $values): array {
        return [];
    }

	private function getTransientKey(string $name, int $post_id): string {
		return 'wp-lkod-state-' . $name . '-' . $this->getType() . '-' . $post_id;
	}

    public function addValidator(IValidator $validator): void {
        $this->validators[] = $validator;
    }

    public function getValidators(): array {
        return $this->validators;
    }

    public function getDefaultValues(): array {
        $values = [];
        foreach ($this->getProperties() as $property) {
            $value = $property->getDefaultValue();
            if ($value !== null) {
                $values[$property->getName()] = $value;
            }
        }
        return $values;
    }

    public function addTriples(int $postId, Graph $g): ?string {
        return null;
    }

    public function getGraph(int $postId): ?Graph {
        $g = new Graph();
        /** @noinspection UnusedFunctionResultInspection */
        $this->addTriples($postId, $g);
        return $g;
    }

    public function addCustomMetadataProperties(): void {
        foreach ($this->getSettings()->getCustomMetadata() as $customMetadata) {
            if (in_array($this->getType(), $customMetadata->getEntities(), true)) {
                $name = $customMetadata->getName();
                $label = $customMetadata->getLabel();

                switch ($customMetadata->getType()) {
                    case 'text':
                        $this->addProperty(new LiteralStringProperty($this, $name, $label));
                        break;
                    case 'date':
                        $this->addProperty(new DateProperty($this, $name, $label));
                        break;
                    case 'list':
                        $options = [];
                        foreach ($customMetadata->getValues() as $v) {
                            $options[$v] = $v;
                        }
                        $property = new SelectProperty($this, $name, $label, false, new StaticCodelist($options));
                        $property->setEmptyValue('- hodnota nie je vybraná -');
                        $this->addProperty($property);
                        break;
                    case 'url':
                        $this->addProperty(new UriProperty($this, $name, $label));
                        break;
                    case 'email':
                        $this->addProperty(new EmailProperty($this, $name, $label));
                        break;
                }
            }
        }
    }

    public function getCustomMetadataProperties(): array {
        $properties = [];
        foreach ($this->getProperties() as $property) {
            if (str_starts_with($property->getName(), 'custom_')) {
                $properties[] = $property;
            }
        }
        return $properties;
    }

    public function renderCustomProperties(array $values, IFormNamespace $ns, array $errors = []): void {
        foreach ($this->getCustomMetadataProperties() as $property) {
            $this->renderProperty($property, $values, $ns, $errors);
        }
    }
}