<?php

namespace Mirri\Lkod;

use EasyRdf\Graph;

abstract class Property {
	private Entity $entity;

	private string $name;

	private string $label;

	private string $hint = '';

    private mixed $defaultValue = null;

    private bool $isRequired;

	/**
	 * @var IValidator[]
	 */
	private array $validators = [];

	public function __construct(Entity $entity, string $name, string $label, bool $isRequired = false) {
		$this->entity = $entity;
		$this->name = $name;
		$this->label = $label;
        $this->isRequired = $isRequired;
        $this->init();
	}

    protected function init(): void {

    }

	public function getEntity(): Entity {
		return $this->entity;
	}

    public function getSettings(): Settings {
        return $this->getEntity()->getSettings();

    }

	public function getName(): string {
		return $this->name;
	}

	public function getLabel(): string {
		return $this->label;
	}

	public function getPostMeta(): array {
		$options = [
			'label' => $this->getLabel(),
			'show_in_rest' => true,
            'single' => $this->isSingleValued(),
            'type' => $this->getDataType(),
            'auth_callback' => function ($allowed, string $metaKey, int $postId): bool {
                return current_user_can('edit_post', $postId);
            }
        ];
        if ($this->defaultValue !== null) {
            $options['default'] = $this->defaultValue;
        }
        return $options;
	}

    abstract public function isSingleValued(): bool;

    abstract public function getDataType(): string;

	public function registerPostMeta() : void {
		register_post_meta($this->getEntity()->getType(), $this->getName(), $this->getPostMeta());
	}

    public function registerSetting(): void {
        $args = $this->getPostMeta();
        unset($args['auth_callback']);
        $args['sanitize_callback'] = function ($value) {
            $value = $this->filterValue($value);
            $errors = Entity::flattenArray($this->validateValue($value));
            if (!empty($errors)) {
                foreach ($errors as $index => $error) {
                    add_settings_error(
                        $this->getName(),
                        $this->getName() . '-' . $index,
                        $this->getLabel() . ' - ' . $error,
                        'error'
                    );
                }
            }
            return $value;
        };
        register_setting($this->getEntity()->getType(), $this->getName(), $args);
    }

    public function getPostValue(int $postId) : mixed {
        return get_post_meta($postId, $this->getName(), $this->isSingleValued());
    }

    public function getSettingValue() : mixed {
        return get_option($this->getName());
    }

    public function getHint(): string {
		return $this->hint;
	}

	public function setHint(string $hint): void {
		$this->hint = $hint;
	}

    public function isRequired(): bool {
        return $this->isRequired;
    }

    public function getDefaultValue(): mixed {
        return $this->defaultValue;
    }

    public function setDefaultValue(mixed $defaultValue): void {
        $this->defaultValue = $defaultValue;
    }

	public function extractValue(array $data, ?string $key = null) {
		return $data[ $key ?? $this->getName() ] ?? null;
	}

	public function addValidator(IValidator $validator): void {
		$this->validators[] = $validator;
	}

	/**
	 * @return IValidator[]
	 */
	public function getValidators(): array {
		return $this->validators;
	}

	public function filterValue(mixed $value): mixed {
		return $value;
	}

	/**
	 * @param mixed $value
	 *
	 * @return string[]
	 */
	public function validateValue(mixed $value): array {
		$errors = [];

		foreach ($this->getValidators() as $validator) {
			/** @noinspection MissUsingForeachInspection */
			foreach ($validator->validate($value) as $error) {
				$errors[] = $error;
			}
		}

		return $errors;
	}

	public function saveValue(int $post_id, mixed $value): void {
		self::storeValue($post_id, $this->getName(), $value, $this->isSingleValued());
	}

    protected static function storeValue(int $post_id, $name, mixed $value, $isSingleValued): void {
        if (!$isSingleValued) {
            delete_post_meta($post_id, $name);
            if (is_array($value)) {
                foreach ($value as $v) {
                    add_post_meta($post_id, $name, $v);
                }
            }
        } else {
            update_post_meta($post_id, $name, $value);
        }
    }

    abstract protected function renderElementAndErrors($value, array $errors, IFormNamespace $ns): void;

    protected function renderRequiredLabelText(): void {
        ?>
        <?php if ($this->isRequired()): ?>
            (povinný údaj)
        <?php endif; ?>
        <?php
    }

    public function renderForm($value, array $errors, IFormNamespace $ns): void {
        $classes = ['wp-lkod-form-group'];
        if (!empty($errors)) {
            $classes[] = 'has-error';
        }
        ?>

        <div class="<?php echo esc_attr(implode(' ', $classes))?>">

            <?php $this->renderElementAndErrors($value, $errors, $ns); ?>

            <?php $this->renderHint(); ?>
        </div>

        <?php
    }

	public function renderHint(): void {
		$hint = $this->getHint();
		if (!empty($hint)) {
            $hint = esc_html($hint);
            $hint = preg_replace_callback('/###([^#]+)###/i', static function ($matches) {
                if (isset($matches[1])) {
                    if (strtolower($matches[1]) === 'end_link') {
                        return '</a>';
                    }
                    return '<a target="_blank" href="' . esc_attr($matches[1]) . '">';
                }
                return '';
            }, $hint);
            $hint = nl2br($hint);
            ?>

			<div class="wp-lkod-hint">
				<?php echo $hint; ?>
			</div>

			<?php
		}
	}



	public function renderErrors(array $errors): void {
		?>

		<?php if (!empty($errors)): ?>
			<div class="wp-lkod-inline-errors">
				<?php Entity::renderErrorsFromList($errors); ?>
			</div>
		<?php endif; ?>

		<?php
	}

    protected function addPostTriplesAsUris(int $postId, Graph $g, string $subject, string $predicate): void {
        $this->addTriplesAsUris($this->getPostValue($postId), $g, $subject, $predicate);
    }

    protected function addTriplesAsUris(mixed $values, Graph $g, string $subject, string $predicate): void {
        Helpers::addTriplesAsUris($values, $g, $subject, $predicate);
    }
}