<?php

namespace Mirri\Lkod;

use DateTime;
use DateTimeInterface;
use DateTimeZone;
use EasyRdf\Graph;
use EasyRdf\Literal;

class Helpers {
    private static ?DateTimeZone $timezone = null;

	public static function enableDateSelector(string $id) : void
	{
		?>

		<script>
            jQuery(document).ready(function($) {
                const id = <?php  echo wp_json_encode($id) ?>;
                $('#' + id).datepicker({
                    dateFormat: 'dd. mm. yy',
                    changeMonth: true,
                    changeYear: true
                });
            });
		</script>

		<?php
	}

    public static function dateToLiteral(mixed $value): ?Literal {
        $dt = self::getDateValue($value);
        return $dt ? new Literal($dt->format('Y-m-d'), null, KnownUris::XsdDate) : null;
    }

    public static function dateTimeToLiteral(mixed $value): ?Literal {
        $dt = self::getDateValue($value);
        return $dt ? new Literal($dt->format(DateTimeInterface::ATOM), null, KnownUris::XsdDateTime) : null;
    }

    public static function getDateValue(mixed $value): ?DateTimeInterface {
        if ($value instanceof DateTimeInterface) {
            return $value;
        }

        if (is_string($value) && !empty($value)) {
            if ($value === 'now') {
                $date = new DateTime();
            } else {
                $date = DateTime::createFromFormat(DateTimeInterface::ATOM, $value);
            }

            if ($date instanceof DateTimeInterface) {
                $date->setTimezone(self::getDefaultTimezone());
                return $date;
            }
        }
        return null;
    }

    public static function now(): DateTimeInterface {
        $dt = new DateTime();
        $dt->setTimezone(self::getDefaultTimezone());
        return $dt;
    }

    public static function addTriplesAsUris(mixed $values, Graph $g, string $subject, string $predicate): void {
        if (is_string($values) && !empty($values)) {
            $values = [$values];
        }
        if (is_array($values)) {
            foreach ($values as $value) {
                if (!empty($value)) {
                    $g->addResource($subject, $predicate, $value);
                }
            }
        }
    }

    public static function getDefaultTimezone(): DateTimeZone {
        if (self::$timezone === null) {
            self::$timezone = new DateTimeZone('Europe/Bratislava');
        }
        return self::$timezone;
    }
}