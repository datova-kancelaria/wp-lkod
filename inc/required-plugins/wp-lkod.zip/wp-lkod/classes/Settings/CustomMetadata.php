<?php

namespace Mirri\Lkod\Settings;

class CustomMetadata {
	private string $name;

	private string $label;

	private string $type;

	/**
	 * @var string[]
	 */
	private array $values;

	private array $entities;

	public function __construct(string $name, string $label, string $type, array $entities = [], array $values = []) {
		$this->name = $name;
		$this->label = $label;
		$this->type = $type;
		$this->entities = $entities;
		$this->values = $values;
	}

	public function getName(): string {
		return $this->name;
	}

	public function getLabel(): string {
		return $this->label;
	}

	public function getType(): string {
		return $this->type;
	}

	public function getValues(): array {
		return $this->values;
	}

	public function getEntities(): array {
		return $this->entities;
	}
}