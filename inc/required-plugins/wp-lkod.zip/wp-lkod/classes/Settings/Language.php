<?php

namespace Mirri\Lkod\Settings;

class Language {
	private string $code;

	private ?string $flag;

	private string $label;

	private bool $default;

	private static array $availableLanguages;

	public function __construct(string $code, string $label, ?string $flag = null, bool $default = false) {
		$this->code = $code;
		$this->label = $label;
		$this->flag = $flag;
		$this->default = $default;
	}

	public function getCode(): string {
		return $this->code;
	}

	public function getFlag(): string {
		return $this->flag;
	}

	public function getLabel(): string {
		return $this->label;
	}

	public function isDefault(): bool {
		return $this->default;
	}

	public static function getAvailableLanguages(): array {
		return self::$availableLanguages ??= [
			'en' => new Language('en', 'Anglicky', 'gb'),
			'de' => new Language('de', 'Nemecky', 'de'),
			'hu' => new Language('hu', 'Maďarsky', 'hu'),
			'cz' => new Language('cz', 'Česky', 'cz'),
			'pl' => new Language('pl', 'Poľsky', 'pl'),
			'ua' => new Language('ua', 'Ukrajinsky', 'ua'),
			'fr' => new Language('fr', 'Francúzsky', 'fr'),
			'es' => new Language('es', 'Španielsky', 'es'),
		];
	}
}