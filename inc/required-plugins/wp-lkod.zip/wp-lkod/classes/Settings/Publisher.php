<?php

namespace Mirri\Lkod\Settings;

class Publisher {
	private string $iri;

	private string $name;

	private bool $default;

	public function __construct(string $iri, string $name, bool $default = false) {
		$this->iri = $iri;
		$this->name = $name;
		$this->default = $default;
	}

	public function getIri(): string {
		return $this->iri;
	}

	public function getName(): string {
		return $this->name;
	}

	public function isDefault(): bool {
		return $this->default;
	}
}