<?php

namespace Mirri\Lkod;

interface IFormNamespace {
	public function prefixName(array|string $name): string;

	public function prefixIdentifier(array|string $name): string;

	public function normalizeData(array $data): ?array;

	public function createInnerNamespace(array $name): IFormNamespace;
}