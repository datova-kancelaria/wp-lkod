<?php

namespace Mirri\Lkod\Shacl;

use EasyRdf\Resource;

interface IPropertyShapeObject {
	public function validateResource(Resource $resource, string $context): array;
}