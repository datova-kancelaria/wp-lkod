<?php

namespace Mirri\Lkod\Shacl;
use EasyRdf\Exception;
use EasyRdf\Graph;

class Parser {
	public static function getPredicate(string $name): string {
		return 'http://www.w3.org/ns/shacl#' . $name;
	}

	/**
	 * @throws Exception
	 */
	public function parse(string $definition): array {

	}
}