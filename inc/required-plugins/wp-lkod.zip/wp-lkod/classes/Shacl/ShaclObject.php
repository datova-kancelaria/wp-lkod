<?php

namespace Mirri\Lkod\Shacl;

use EasyRdf\Graph;
use EasyRdf\Resource;

class ShaclObject
{
	private Resource $resource;

	public function __construct(Resource $resource) {
		$this->resource = $resource;
	}

	public function getResource(): Resource {
		return $this->resource;
	}
}