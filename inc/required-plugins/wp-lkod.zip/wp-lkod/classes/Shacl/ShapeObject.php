<?php

namespace Mirri\Lkod\Shacl;

use EasyRdf\Collection;
use EasyRdf\Resource;

class ShapeObject extends ShaclObject implements IPropertyShapeObject {
	/**
	 * @var IPropertyShapeObject[]
	 */
	protected array $properties = [];

	public function __construct(Resource $resource) {
		parent::__construct($resource);

		$this->properties = self::factoryProperties($resource);
	}

	private static function factoryProperties(Resource $resource): array {
		$properties = [];

		$references = $resource->allResources('sh:property');
		if (count($references) > 0) {
			foreach ($references as $propertyResource) {
				$properties[] = new PropertyShape($propertyResource);
			}
		}

		$orReferences = $resource->allResources('sh:or');
		if (count($orReferences) > 0) {
			foreach ($orReferences as $orReference) {
				$orOperator = new PropertyShapeOperatorOr($orReference);
				/*if ($orReference instanceof Collection) {
					foreach ($orReference as $p) {
						foreach (self::factoryProperties($p) as $property) {
							$orOperator->properties[] = $property;
						}
					}
				}*/
				$properties[] = $orOperator;
			}
		}

		$xOneReferences = $resource->allResources('sh:xone');
		if (count($xOneReferences) > 0) {
			foreach ($xOneReferences as $xOneReference) {
				$xOneOperator = new PropertyShapeOperatorXOne($xOneReference);
				/*if ($xOneReference instanceof Collection) {
					foreach ($xOneReference as $p) {
						foreach (self::factoryProperties($p) as $property) {
							$xOneOperator->properties[] = $property;
						}
					}
				}*/
				$properties[] = $xOneOperator;
			}
		}

		if ($resource instanceof Collection) {
			foreach ($resource as $p) {
				$properties[] = new ShapeObject($p);
			}
		}

		return $properties;
	}

	public function validate(Resource $resource, string $context = ''): array {
		$errors = [];

		$context .= $resource->getUri() ?? '';
		/**
		 * @var IPropertyShapeObject $property
		 */
		foreach ($this->properties as $property) {
			$errors += array_map(static function ($e) use ($context) {
				return (!empty($context) ? $context . ': ' : '') . $e;
			}, $property->validate($resource, $context));
		}

		return $errors;
	}
}