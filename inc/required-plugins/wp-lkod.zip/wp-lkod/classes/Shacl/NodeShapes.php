<?php

namespace Mirri\Lkod\Shacl;

use EasyRdf\Exception;
use EasyRdf\Graph;
use EasyRdf\RdfNamespace;
use EasyRdf\Resource;

class NodeShapes {
	/**
	 * @var NodeShape[]
	 */
	private array $shapes = [];

	/**
	 * @throws Exception
	 */
	public function parse(string $definition): void {
		RdfNamespace::set('sh', 'http://www.w3.org/ns/shacl#');
		$g = new Graph();
		$g->parse($definition, 'turtle');
		$this->loadFromGraph($g);
	}

	public function loadFromGraph(Graph $g): void {
		foreach ($g->allOfType('sh:NodeShape') as $r) {
			$this->shapes[] = new NodeShape($r);
		}
	}

	/**
	 * @throws Exception
	 */
	public static function dcat3(): self {
		$path = dirname( __DIR__, 2 ) . '/assets/shacl/dcat3.ttl';
		if (!is_file($path)) {
			throw new Exception('SHACL file not found');
		}
		$shapes = new self();
		$shapes->parse(file_get_contents($path));
		return $shapes;
	}

	public static function fromGraph(Graph $g): self {
		$shapes = new self();
		$shapes->loadFromGraph($g);
		return $shapes;
	}

	/**
	 * @param Resource $resource
	 *
	 * @return NodeShape[]
	 */
	public function getShapesForResource(Resource $resource): array {
		$shapes = [];

		foreach ($this->shapes as $shape) {
			if ($shape->supports($resource)) {
				$shapes[] = $shape;
			}
		}

		return $shapes;
	}

	public function getShapesForType(Resource $type) {
		$shapes = [];

		foreach ($this->shapes as $shape) {
			if ($shape->supportsType($type)) {
				$shapes[] = $shape;
			}
		}

		return $shapes;
	}

	public function isValid(Resource $resource): bool {
		$errors = $this->validate($resource);
		return empty($errors);
	}

	public function validate(Resource $resource, $threadNoShapesAsError = true): array {
		$errors = [];
		$shapes = $this->getShapesForResource($resource);
		if ($threadNoShapesAsError && count($shapes) === 0) {
			$errors[] = 'Pre objekt nebol nájdená definícia sh:NodeShape';
		}
		foreach ($shapes as $shape) {
			$errors += $shape->validate($resource);
		}
		return $errors;
	}

	public function validateType($resource, $type, $context, $threadNoShapesAsError = true): array {
		$errors = [];
		if ($resource instanceof Resource) {
			$shapes = $this->getShapesForType($resource->getGraph()->resource($type));
			if ($threadNoShapesAsError && count($shapes) === 0) {
				$errors[] = 'Pre objekt nebol nájdená definícia sh:NodeShape';
			}
			foreach ($shapes as $shape) {
				$errors += $shape->validate($resource);
			}
		} else {
			$errors[] = 'Invalid node kind in '. $context;
		}
		return $errors;
	}

	public function validateDataset(Resource $dataset, $threadNoShapesAsError = true): array {
		$errors = $this->validateType($dataset, 'dcat:Dataset', $threadNoShapesAsError);
		foreach ($dataset->all('dcat:distribution') as $distribution) {
			$errors += $this->validateDistribution($distribution, $threadNoShapesAsError, $dataset->getUri() . ' > dcat:distribution');
		}
		return $errors;
	}

	public function validateDistribution($distribution, $threadNoShapesAsError = true, string $context = ''): array {
		if ($distribution instanceof Resource) {
			$context .= (!empty($context) ? ' > ' : '') . $distribution->getUri();
		}
		$errors = $this->validateType($distribution, 'dcat:Distribution', $context, $threadNoShapesAsError);
		if ($distribution instanceof Resource) {
			foreach ($distribution->all('leg:termsOfUse') as $termsOfUse) {
				$errors += $this->validateType($termsOfUse, 'leg:TermsOfUse', $context . ' > leg:termsOfUse');
			}
		}
		return $errors;
	}
}