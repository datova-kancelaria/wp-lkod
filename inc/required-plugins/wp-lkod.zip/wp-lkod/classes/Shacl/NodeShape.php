<?php

namespace Mirri\Lkod\Shacl;

use EasyRdf\Resource;

class NodeShape extends PropertyShape
{
	public function __construct(Resource $resource) {
		parent::__construct($resource, ['sh:targetClass', 'dct:subject', 'rdfs:isDefinedBy']);
	}

	public function supports(Resource $resource): bool {
		foreach ($this->getTargetClasses() as $c) {
			if ($resource->isA($c)) {
				return true;
			}
		}
		return false;
	}

	public function supportsType(Resource $type): bool {
		foreach ($this->getTargetClasses() as $c) {
			if ($c->getUri() === $type->getUri()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @return Resource[]
	 */
	public function getTargetClasses(): array {
		return $this->resource->allResources('sh:targetClass');
	}

	public function validate(Resource $resource, string $context = ''): array {
		$errors = [];

		if ($this->supports($resource)) {
			$errors += parent::validate($resource, $context);
		}

		return $errors;
	}
}