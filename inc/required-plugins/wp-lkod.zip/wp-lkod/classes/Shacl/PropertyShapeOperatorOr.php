<?php

namespace Mirri\Lkod\Shacl;

use EasyRdf\Resource;

class PropertyShapeOperatorOr extends ShapeObject implements IPropertyShapeObject {

	public function validate(Resource $resource, string $context = ''): array {
		$errorsInBranches = [];
		foreach ($this->properties as $branch) {
			$branchErrors = $branch->validate($resource, $context);
			if (count($branchErrors) > 0) {
				$errorsInBranches[] = $branchErrors;
			} else {
				return [];
			}
		}
		return $errorsInBranches;
	}
}