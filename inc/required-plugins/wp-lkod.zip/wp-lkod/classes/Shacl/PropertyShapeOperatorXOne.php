<?php

namespace Mirri\Lkod\Shacl;

use EasyRdf\Resource;

class PropertyShapeOperatorXOne implements IPropertyShapeObject {

	private array $validators;

	public function __construct(array $validators) {
		$this->validators = $validators;
	}

	public function validateResource(Resource $resource, string $context = ''): array {
		$emptyBranchesCount = 0;
		$errors = [];
		foreach ($this->validators as $branch) {
			$branchErrors = $branch->validate($resource, $context);
			$errors += $branchErrors;
			if (count($branchErrors) === 0) {
				$emptyBranchesCount++;
			}
		}

		if ($emptyBranchesCount === 1) {
			return [];
		}

		return $errors;
	}
}