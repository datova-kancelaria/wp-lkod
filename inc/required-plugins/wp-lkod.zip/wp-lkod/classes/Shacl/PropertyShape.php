<?php

namespace Mirri\Lkod\Shacl;

use EasyRdf\Collection;
use EasyRdf\Graph;
use EasyRdf\Literal;
use EasyRdf\Resource;

class PropertyShape implements IPropertyShapeObject {

	/**
	 * @var string[]
	 */
	protected static array $defaultSupportedPredicates = [
		'sh:path',
		'sh:minCount',
		'sh:maxCount',
		'sh:uniqueLang',
		'rdf:type',
		'sh:qualifiedValueShape',
		'sh:qualifiedMinCount',
		'sh:qualifiedMaxCount',
		'sh:property',
		'sh:equals'
	];

	/**
	 * @var string[]
	 */
	protected static array $supportedQualifiedPredicates = [
		'sh:datatype',
		'rdf:type',
		'sh:pattern',
		'sh:nodeKind',
		'sh:class',
		'sh:or',
		'sh:xone',
		'sh:not',
		'sh:languageIn',
		'sh:hasValue',
	];
	
	protected Resource $resource;

	/**
	 * @var IPropertyShapeObject[]
	 */
	protected array $validators = [];

	/**
	 * @var string[]
	 */
	private array $supportedPredicates;
	
	public function __construct(Resource $resource, array $supportedPredicates = []) {
		$this->resource = $resource;

		$this->supportedPredicates = array_merge(self::$defaultSupportedPredicates, $supportedPredicates);

		$this->validators[] = $this;
		foreach ($this->resource->all('sh:property') as $property) {
			if ($property instanceof Resource) {
				$this->validators[] = new PropertyShape($property);
			}
		}
	}

	public function validate(Resource $resource, string $context): array {
		$errors = [];
		foreach ($this->validators as $validator) {
			if ($validator instanceof IPropertyShapeObject) {
				$errors += $validator->validateResource($resource, $context);
			}
		}
		return $errors;
	}

	public function validateResource(Resource $resource, string $context): array {
		$objects = $this->getObjects($resource);
		$subContext = $this->getContext();
		if (!empty($subContext)) {
			$context .= ' > ' . $subContext;
		}

		$errors = [];

		if ($this->resource->hasProperty('sh:equals')) {
			foreach ($this->resource->all('sh:equals') as $operand) {
				$expectedValues = self::followPath($resource, $operand);
				$diff1 = array_diff($objects, $expectedValues);
				$diff2 = array_diff($expectedValues, $objects);
				if (count($diff1) > 0 || count($diff2) > 0) {
					$errors[] = 'Expected ' . implode(', ', $expectedValues) . ' but got ' . implode(', ', $objects) . ' in ' . $context;
				}
			}
		}

		$errors += $this->validateObjects($objects, $context);
		return $errors;
	}

	public function validateObjects(array $objects, string $context): array {
		$errors = [];

		foreach ($this->resource->all('sh:minCount') as $minCountLiteral) {
			if ( ( $minCountLiteral instanceof Literal\Integer ) && count( $objects ) < $minCountLiteral->getValue() ) {
				$errors[] = 'Expected minimal count of ' . $minCountLiteral->getValue() . ' but got ' . count( $objects ) . ' in ' . $context;
			}
		}

		foreach ($this->resource->all('sh:maxCount') as $maxCountLiteral) {
			if ( ( $maxCountLiteral instanceof Literal\Integer ) && count( $objects ) > $maxCountLiteral->getValue() ) {
				$errors[] = 'Expected maximal count of ' . $maxCountLiteral->getValue() . ' but got ' . count( $objects ) . ' in ' . $context;
			}
		}

		foreach ($this->resource->all('sh:uniqueLang') as $uniqueLangLiteral) {
			if (($uniqueLangLiteral instanceof Literal\Boolean) && $uniqueLangLiteral->getValue()) {
				$languages = [];
				foreach ($objects as $o) {
					if ($o instanceof Literal) {
						$lang = $o->getLang();
						if ($lang) {
							if ( in_array( $lang, $languages, true ) ) {
								$errors[] = 'Expected unique language but got duplicate: ' . $lang . ' in ' . $context;
								break;
							}
							$languages[] = $lang;
						}
					}
				}
			}
		}

		$errors += self::comply($objects, $this->resource, $context, $this->supportedPredicates);

		$qualifiedObjects = $objects;
		foreach ($this->resource->all('sh:qualifiedValueShape') as $qualifiedValueShape) {
			$qualifiedObjects = self::filterObjects($qualifiedObjects, $qualifiedValueShape);
		}

		foreach ($this->resource->all('sh:qualifiedMinCount') as $qualifiedMinCountLiteral) {
			if ( ( $qualifiedMinCountLiteral instanceof Literal\Integer ) && count( $qualifiedObjects ) < $qualifiedMinCountLiteral->getValue() ) {
				$errors[] = 'Expected qualified minimal count of ' . $qualifiedMinCountLiteral->getValue() . ' but got ' . count( $qualifiedObjects ) . ' in ' . $context;
			}
		}

		foreach ($this->resource->all('sh:qualifiedMaxCount') as $qualifiedMaxCountLiteral) {
			if ( ( $qualifiedMaxCountLiteral instanceof Literal\Integer ) && count( $qualifiedObjects ) > $qualifiedMaxCountLiteral->getValue() ) {
				$errors[] = 'Expected qualified maximal count of ' . $qualifiedMaxCountLiteral->getValue() . ' but got ' . count( $qualifiedObjects ) . ' in ' . $context;
			}
		}

		return $errors;
	}

	private static function comply(array $objects, Resource $shape, string $context, array $supportedPredicates): array {
		$errors = [];

		$dataTypes = $shape->all('sh:datatype');
		if (count($dataTypes) > 0) {
			foreach ($objects as $o) {
				$errors += self::verifyNodeKind($context, 'sh:Literal', $o);
			}
			foreach ($dataTypes as $dataType) {
				if ($dataType instanceof Resource) {
					$dt = $dataType->shorten();
					foreach ($objects as $o) {
						$errors += self::verifyDataType($context, $dt, $o);
					}
				}
			}
		}

		foreach ($shape->all('sh:nodeKind') as $nodeKind) {
			if ($nodeKind instanceof Resource) {
				$dt = $nodeKind->shorten();
				foreach ($objects as $o) {
					$errors += self::verifyNodeKind($context, $dt, $o);
				}
			}
		}

		foreach ($shape->all('sh:pattern') as $pattern) {
			if ($pattern instanceof Literal) {
				foreach ($objects as $o) {
					$errors += self::verifyPattern($context, $pattern->getValue(), $o);
				}
			}
		}

		$expectedLanguages = [];
		foreach ($shape->all('sh:languageIn') as $languageIn) {
			if ($languageIn instanceof Collection) {
				foreach ($languageIn as $lang) {
					$expectedLanguages[] = $lang->getValue();
				}
			}
		}

		if (count($expectedLanguages) > 0) {
			foreach ($objects as $o) {
				if ($o instanceof Literal) {
					$lang = $o->getLang();
					if (!in_array($lang, $expectedLanguages, true)) {
						$errors[] = 'Expected language ' . implode(', ', $expectedLanguages) . ' but got ' . $lang . ' in ' . $context;
					}
				}
			}
		}

		$classes = $shape->all('sh:class');
		if (count($classes) > 0) {
			foreach ($objects as $o) {
				$errors += self::verifyNodeKind($context, 'sh:BlankNodeOrIRI', $o);
			}
			foreach ($classes as $classType) {
				if ($classType instanceof Resource) {
					foreach ($objects as $o) {
						$errors += self::verifyRdfType($context, $classType->getUri(), $o);
					}
				}
			}
		}

		if ($shape->hasProperty('sh:hasValue')) {
			foreach ($shape->all('sh:hasValue') as $hasValue) {
				$contains = false;
				if ($hasValue instanceof Resource) {
					foreach ($objects as $o) {
						if ($o instanceof Resource && $hasValue->getUri() === $o->getUri()) {
							$contains = true;
							break;
						}
					}
				} elseif ($hasValue instanceof Literal) {
					foreach ($objects as $o) {
						if ($o instanceof Literal && $hasValue->getValue() === $o->getValue()) {
							$contains = true;
							break;
						}
					}
				}

				if (!$contains) {
					$errors[] = 'Expected value ' . $hasValue->getUri() . ' but got none in ' . $context;
				}
			}
		}

		if ($shape->hasProperty('sh:or')) {
			$branchErrors = [];

			foreach ($shape->all('sh:or') as $branches) {
				if ($branches instanceof Collection) {
					foreach ($objects as $r) {
						$hasValidBranch = false;
						foreach ($branches as $branch) {
							$singleBranchErrors = (new PropertyShape($branch))->validate($r, $context);
							if (count($singleBranchErrors) === 0) {
								$hasValidBranch = true;
								break;
							}
							$branchErrors[] = $singleBranchErrors;
						}
						if (!$hasValidBranch) {
							$errors = array_merge($errors, $branchErrors);
						}
					}
				}
			}
		}

		if ($shape->hasProperty('sh:xone')) {
			foreach ($shape->all('sh:xone') as $branches) {
				if ($branches instanceof Collection) {
					$branchErrors = [];
					$validBranches = 0;
					foreach ($objects as $r) {
						foreach ( $branches as $branch ) {
							$singleBranchErrors = ( new PropertyShape( $branch ) )->validate($r, $context);
							if ( count( $singleBranchErrors ) === 0 ) {
								$validBranches ++;
							}
							$branchErrors[] = $singleBranchErrors;
						}
					}
					if ($validBranches === 0) {
						$errors[] = self::createErrorMessage('No xone branches were valid', $context, self::cloneResource($shape, ['sh:xone']));
					} elseif ($validBranches > 1) {
						$errors[] = self::createErrorMessage('More than one xone branches were valid', $context, self::cloneResource($shape, ['sh:xone']));
					}
				}
			}

		}

		if ($shape->hasProperty('sh:not')) {
			foreach ($shape->all('sh:not') as $operand) {
				foreach ($objects as $r) {
					$operandErrors = (new PropertyShape($operand))->validate($r, $context);
					if (count($operandErrors) === 0) {
						$errors[] = 'Expected not to be valid in ' . $context;
					}
				}
			}
		}

		foreach ($shape->properties() as $property) {
			if (!in_array($property, $supportedPredicates, true) && !in_array($property, self::$supportedQualifiedPredicates, true)) {
				throw new \RuntimeException('Not supported sh:property predicate: ' . $property);
			}
		}

		return $errors;
	}

	public static function followPath(Resource $o, Resource $path): array {
		if (!$path->isBNode()) {
			return $o->all($path);
		}
		return [$o];
	}

	public function getObjects(Resource $resource): array {
		$objects = [$resource];
		$forwardPathDefinition = $this->resource->getResource('sh:path');
		if ($forwardPathDefinition !== null) {
			$forwardPaths = [];
			if ($forwardPathDefinition instanceof Collection) {
				foreach ($forwardPathDefinition as $p) {
					$forwardPaths[] = $p;
				}
			} elseif ($forwardPathDefinition instanceof Resource) {
				$forwardPaths[] = $forwardPathDefinition;
			}

			foreach ($forwardPaths as $forwardPath) {
				$selected = [];
				foreach ($objects as $o) {
					$selected += self::followPath($o, $forwardPath);
				}
				$objects = $selected;
			}

			return $objects;
		}

		$reversePathDefinition = $this->resource->getResource('sh:inversePath');
		if ($reversePathDefinition !== null) {
			$inversePaths = [];
			if ($reversePathDefinition instanceof Collection) {
				foreach ($reversePathDefinition as $p) {
					$inversePaths[] = $p;
				}
			} elseif ($reversePathDefinition instanceof Resource) {
				$inversePaths[] = $reversePathDefinition;
			}

			foreach ($inversePaths as $inversePath) {
				$selected = [];
				foreach ($objects as $o) {
					if ($o instanceof Resource) {
						$selected += $o->getGraph()->resourcesMatching($inversePath, $o);
					}
				}
				$objects = $selected;
			}

			return $objects;
		}

		return $objects;
	}

	public function getContext(): string {
		$paths = [];
		foreach ($this->resource->all('sh:path') as $path) {
			if ($path instanceof Resource) {
				$paths[] = $path->getUri() ?? '';
			} elseif ($path instanceof Literal) {
				$paths[] = $path->getValue();
			}
		}
		return implode(' > ', $paths);
	}

	public static function filterObjects(array $objects, Resource $shape): array {
		$selected = [];

		foreach ($objects as $o) {
			$errors = self::comply([$o], $shape, 'object', []);
			if (empty($errors)) {
				$selected[] = $o;
			}
		}

		return $selected;
	}

	private static function verifyDataType(string $context, string $expectedDataType, $value): array {
		$errors = [];

		if ($value instanceof Literal) {
			$actualDataType = $value->getDatatype();

			if (empty($actualDataType)) {
				if (!empty($value->getLang())) {
					$actualDataType = 'rdf:langString';
				} else {
					$actualDataType = 'rdf:string';
				}
			}

			if ($actualDataType !== $expectedDataType) {
				$errors[] = "Hodnota $context nie je dátového typu $expectedDataType, ale $actualDataType";
			}
		}

		return $errors;
	}

	private static function verifyPattern(string $context, string $pattern, $value): array {
		$errors = [];

		if ($value instanceof Resource) {
			if (!$value->isBNode()) {
				$text = $value->getUri();
			}
		} elseif ($value instanceof Literal) {
			$text = $value->getValue();
		}

		if (isset($text) && !preg_match( '@' . str_replace( '@', '\@', $pattern ) . '@', $text)) {
			$errors[] = 'Value does not match pattern ' . $pattern . ' in ' . $context;
		}

		return $errors;
	}

	private static function verifyRdfType(string $context, string $type, $value): array {
		$errors = [];

		if ( $value instanceof Resource && !$value->isA($type) ) {
			$errors[] = 'Value does not have type ' . $type . ' in ' . $context;
		}

		return $errors;
	}

	private static function verifyNodeKind(string $context, string $expectedNodeKind, $value): array {
		$errors = [];

		switch ($expectedNodeKind) {
			case 'sh:IRI':
				$kinds = ['IRI'];
				break;
			case 'sh:BlankNode':
				$kinds = ['BlankNode'];
				break;
			case 'sh:Literal':
				$kinds = ['Literal'];
				break;
			case 'sh:BlankNodeOrIRI':
				$kinds = ['BlankNode', 'IRI'];
				break;
			case 'sh:BlankNodeOrLiteral':
				$kinds = ['BlankNode', 'Literal'];
				break;
			case 'sh:IRIOrLiteral':
				$kinds = ['IRI', 'Literal'];
				break;
			default:
				$errors[] = 'Unknown node kind: '.$expectedNodeKind;
				break;
		}

		if (isset($kinds)) {
			if ($value instanceof Literal) {
				$nodeKind = 'Literal';
			} elseif ($value instanceof Resource) {
				$nodeKind = $value->isBNode() ? 'BlankNode' : 'IRI';
			} else {
				$nodeKind = 'Unknown';
			}

			if (!in_array($nodeKind, $kinds)) {
				$errors[] = "Hodnota $context nie je typu $expectedNodeKind, ale $nodeKind";
			}
		}
		return $errors;
	}

	private static function cloneResource(Resource $resource, ?array $properties = null): Graph {
		$newGraph = new Graph();
		self::copyProperties($resource, $newGraph, $properties);
		return $newGraph;
	}

	private static function copyProperties(Resource $resource, Graph $g, ?array $properties = null, array $visited = []): void {
		$properties ??= $resource->properties();
		$newResource = $g->resource($resource->getUri());
		foreach ($properties as $property) {
			foreach ($resource->all($property) as $value) {
				$g->add($newResource, $property, $value);
				if ($value instanceof Resource && !in_array($value, $visited, true)) {
					$visited[] = $value;
					self::copyProperties($value, $g, null, $visited);
				}
			}
		}
	}

	private static function createErrorMessage(string $message, string $context, Graph $g): string {
		return 'Error: ' . $message . PHP_EOL . 'Context: ' . $context . PHP_EOL . 'Definition: ' . $g->serialise('turtle');
	}
}