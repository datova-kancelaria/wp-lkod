<?php

namespace Mirri\Lkod\Shacl;

class Validator {

}