<?php
/** @noinspection SpellCheckingInspection */
/** @noinspection PhpUnused */
/** @noinspection HttpUrlsUsage */

namespace Mirri\Lkod;

class KnownUris {
	public const HvdLegislation = 'http://data.europa.eu/eli/reg_impl/2023/138/oj';

	public const DctTitle = self::DctPrefix . 'title';

	public const DctDescription = self::DctPrefix . 'description';

	public const DctPublisher = self::DctPrefix . 'publisher';

	public const DctIssued = self::DctPrefix . 'issued';

	public const DctModified = self::DctPrefix . 'modified';

	public const DctAccrualPeriodicity = self::DctPrefix . 'accrualPeriodicity';

	public const DctType = self::DctPrefix . 'type';

	public const DctSpatial = self::DctPrefix . 'spatial';

	public const DctTemporal = self::DctPrefix . 'temporal';

	public const DctConformsTo = self::DctPrefix . 'conformsTo';

	public const DctRelation = self::DctPrefix . 'relation';

	public const DctFormat = self::DctPrefix . 'format';

	public const DcatDataset = self::DcatPrefix . 'dataset';

	public const DcatCatalogClass = self::DcatPrefix . 'Catalog';

	public const DcatDatasetClass = self::DcatPrefix . 'Dataset';

	public const DcatDatasetSeriesClass = self::DcatPrefix . 'DatasetSeries';

	public const DcatDistribution = self::DcatPrefix . 'distribution';

	public const DcatDistributionClass = self::DcatPrefix . 'Distribution';

	public const DcatDataServiceClass = self::DcatPrefix . 'DataService';

	public const DcatTheme = self::DcatPrefix . 'theme';

	public const DcatKeyword = self::DcatPrefix . 'keyword';

	public const DcatStartDate = self::DcatPrefix . 'startDate';

	public const DcatEndDate = self::DcatPrefix . 'endDate';

	public const DcatContactPoint = self::DcatPrefix . 'contactPoint';

	public const DcatLandingPage = self::DcatPrefix . 'landingPage';

	public const DcatTemporalResolution = self::DcatPrefix . 'temporalResolution';

	public const DcatSpatialResolutionInMeters = self::DcatPrefix . 'spatialResolutionInMeters';

	public const DcatInSeries = self::DcatPrefix . 'inSeries';

	public const DcatDownloadUrl = self::DcatPrefix . 'downloadURL';

	public const DcatAccessUrl = self::DcatPrefix . 'accessURL';

	public const DcatMediaType = self::DcatPrefix . 'mediaType';

	public const DcatCompressFormat = self::DcatPrefix . 'compressFormat';

	public const DcatPackageFormat = self::DcatPrefix . 'packageFormat';

	public const DcatAccessService = self::DcatPrefix . 'accessService';

	public const DcatEndpointUrl = self::DcatPrefix . 'endpointURL';

	public const DcatEndpointDescription = self::DcatPrefix . 'endpointDescription';

	public const FoafPage = self::FoafPrefix . 'page';

	public const FoafHomePage = self::FoafPrefix . 'homepage';

	public const DcatApApplicableLegislation = self::DcatApPrefix . 'applicableLegislation';

	public const DcatApHvdCategory = self::DcatApPrefix . 'hvdCategory';

	public const LegTermsOfUse = self::LegPrefix . 'termsOfUse';

	public const LegTermsOfUseClass = self::LegPrefix . 'TermsOfUse';

	public const LegAuthorsWorkType = self::LegPrefix . 'authorsWorkType';

	public const LegOriginalDatabaseType = self::LegPrefix . 'originalDatabaseType';

	public const LegDatabaseProtectedBySpecialRightsType = self::LegPrefix . 'databaseProtectedBySpecialRightsType';

	public const LegPersonalDataContainmentType = self::LegPrefix . 'personalDataContainmentType';

	public const LegAuthorName = self::LegPrefix . 'authorName';

	public const LegOriginalDatabaseAuthorName = self::LegPrefix . 'originalDatabaseAuthorName';

	public const HvdType = 'http://publications.europa.eu/resource/authority/dataset-type/HVD';

	public const SkosConcept = self::SkosPrefix . 'Concept';

	public const SkosConceptScheme = self::SkosPrefix . 'ConceptScheme';

	public const SkosPrefLabel = self::SkosPrefix . 'prefLabel';

	public const SkosHasTopConcept = self::SkosPrefix . 'hasTopConcept';

	public const DctIdentifier = self::DctPrefix . 'identifier';

	public const DctPeriodOfTime = self::DctPrefix . 'PeriodOfTime';

	public const DcatCatalogRecord = self::DcatPrefix . 'CatalogRecord';

	public const FoafPrimaryTopic = self::FoafPrefix . 'primaryTopic';

	public const DctSource = self::DctPrefix . 'source';

	public const VcardIndividual = self::VcardPrefix . 'Individual';

	public const VcardOrganization = self::VcardPrefix . 'Organization';

	public const VcardFn = self::VcardPrefix . 'fn';

	public const VcardHasEmail = self::VcardPrefix . 'hasEmail';

	public const XsdDate = self::XsdPrefix . 'date';

	public const XsdDateTime = self::XsdPrefix . 'dateTime';

	public const XsdDecimal = self::XsdPrefix . 'decimal';

	public const XsdDuration = self::XsdPrefix . 'duration';

	public const VcardPrefix = 'http://www.w3.org/2006/vcard/ns#';

	public const DctPrefix = 'http://purl.org/dc/terms/';

	public const DcatPrefix = 'http://www.w3.org/ns/dcat#';

	public const FoafPrefix = 'http://xmlns.com/foaf/0.1/';

	public const DcatApPrefix = 'http://data.europa.eu/r5r/';

	public const LegPrefix = 'https://data.gov.sk/def/ontology/legislation/';

	public const SkosPrefix = 'http://www.w3.org/2008/05/skos-xl#';

	public const XsdPrefix = 'http://www.w3.org/2001/XMLSchema#';

	public const EurovocPrefix = 'http://eurovoc.europa.eu/';
}