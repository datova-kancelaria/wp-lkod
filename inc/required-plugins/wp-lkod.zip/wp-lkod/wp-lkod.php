<?php /** @noinspection UnusedFunctionResultInspection */

/*
Plugin Name: Lokálny katalóg otvorených dát
Plugin URI: https://github.com/datova-kancelaria/LKOD
Description: WordPress plugin pre generovanie a správu lokálneho katalógu otvorených dát (LKOD), ktorý môže byť použitý na správu a publikovanie otvorených dát a tiež harvestovaný Národným katalógom otvorených dát (https://data.slovensko.sk/).
Version: 1.0
Author: MIRRI
Author URI: https://mirri.gov.sk/
License: EUPL
*/

use Mirri\Lkod\Codelists\DefaultCodelists;
use Mirri\Lkod\Codelists\SearchableCodelist;
use Mirri\Lkod\DefaultFormNamespace;
use Mirri\Lkod\Entities\Category;
use Mirri\Lkod\Entities\ContactPoint;
use Mirri\Lkod\Entities\DataService;
use Mirri\Lkod\Entities\Dataset;
use Mirri\Lkod\Entities\SettingsOptions;

require __DIR__ . '/vendor/autoload.php';

function wp_lkod_register_post_type_dataset(): void {
    $datasetLabels = [
        'name'                  => 'Datasety',
        'singular_name'         => 'Dataset',
        'menu_name'             => 'Datasety',
        'name_admin_bar'        => 'Dataset',
        'archives'              => 'Archív datasetov',
        'attributes'            => 'Atribúty datasetu',
        'parent_item_colon'     => 'Nadradený dataset:',
        'all_items'             => 'Všetky datasety',
        'add_new_item'          => 'Pridať nový dataset',
        'add_new'               => 'Pridať nový',
        'new_item'              => 'Nový dataset',
        'edit_item'             => 'Upraviť dataset',
        'update_item'           => 'Aktualizovať dataset',
        'view_item'             => 'Zobraziť dataset',
        'view_items'            => 'Zobraziť datasety',
        'search_items'          => 'Hľadať dataset',
        'not_found'             => 'Nenájdené',
        'not_found_in_trash'    => 'Nenájdené v koši',
        'featured_image'        => 'Ukážkový obrázok',
        'set_featured_image'    => 'Nastaviť ukážkový obrázok',
        'remove_featured_image' => 'Odstrániť ukážkový obrázok',
        'use_featured_image'    => 'Použiť ako ukážkový obrázok',
        'insert_into_item'      => 'Vložiť do datasetu',
        'uploaded_to_this_item' => 'Nahrané k tomuto datasetu',
        'items_list'            => 'Zoznam datasetov',
        'items_list_navigation' => 'Navigácia v zozname datasetov',
        'filter_items_list'     => 'Filtrovať zoznam datasetov',
    ];

    $dataServiceLabels = [
        'name'                  => 'Dátové služby',
        'singular_name'         => 'Dátová služba',
        'menu_name'             => 'Dátové služby',
        'name_admin_bar'        => 'Dátová služba',
        'archives'              => 'Archív dátových služieb',
        'attributes'            => 'Atribúty dátovej služby',
        'parent_item_colon'     => 'Nadradená dátová služba:',
        'all_items'             => 'Všetky dátové služby',
        'add_new_item'          => 'Pridať novú dátovú službu',
        'add_new'               => 'Pridať novú',
        'new_item'              => 'Nová dátová služba',
        'edit_item'             => 'Upraviť dátovú službu',
        'update_item'           => 'Aktualizovať dátovú službu',
        'view_item'             => 'Zobraziť dátovú službu',
        'view_items'            => 'Zobraziť dátové služby',
        'search_items'          => 'Hľadať dátovú službu',
        'not_found'             => 'Nenájdené',
        'not_found_in_trash'    => 'Nenájdené v koši',
        'featured_image'        => 'Ukážkový obrázok',
        'set_featured_image'    => 'Nastaviť ukážkový obrázok',
        'remove_featured_image' => 'Odstrániť ukážkový obrázok',
        'use_featured_image'    => 'Použiť ako ukážkový obrázok',
        'insert_into_item'      => 'Vložiť do dátovej služby',
        'uploaded_to_this_item' => 'Nahrané k tejto dátovej službe',
        'items_list'            => 'Zoznam dátových služieb',
        'items_list_navigation' => 'Navigácia v zozname dátových služieb',
        'filter_items_list'     => 'Filtrovať zoznam dátových služieb',
    ];

    $contactLabels = [
        'name'                  => 'Kontaktné body',
        'singular_name'         => 'Kontaktný bod',
        'menu_name'             => 'Kontaktné body',
        'name_admin_bar'        => 'Kontaktný bod',
        'archives'              => 'Archív kontaktných bodov',
        'attributes'            => 'Atribúty kontaktného bodu',
        'parent_item_colon'     => 'Nadradený kontaktný bod:',
        'all_items'             => 'Všetky kontaktné body',
        'add_new_item'          => 'Pridať nový kontaktný bod',
        'add_new'               => 'Pridať nový',
        'new_item'              => 'Nový kontaktný bod',
        'edit_item'             => 'Upraviť kontaktný bod',
        'update_item'           => 'Aktualizovať kontaktný bod',
        'view_item'             => 'Zobraziť kontaktný bod',
        'view_items'            => 'Zobraziť kontaktné body',
        'search_items'          => 'Hľadať kontaktný bod',
        'not_found'             => 'Nenájdené',
        'not_found_in_trash'    => 'Nenájdené v koši',
        'featured_image'        => 'Ukážkový obrázok',
        'set_featured_image'    => 'Nastaviť ukážkový obrázok',
        'remove_featured_image' => 'Odstrániť ukážkový obrázok',
        'use_featured_image'    => 'Použiť ako ukážkový obrázok',
        'insert_into_item'      => 'Vložiť do kontaktného bodu',
        'uploaded_to_this_item' => 'Nahrané k tomuto kontaktnému bodu',
        'items_list'            => 'Zoznam kontaktných bodov',
        'items_list_navigation' => 'Navigácia v zozname kontaktných bodov',
        'filter_items_list'     => 'Filtrovať zoznam kontaktných bodov',
    ];

    $categoryLabels = [
        'name'                  => 'Kategórie',
        'singular_name'         => 'Kategória',
        'menu_name'             => 'Kategórie',
        'name_admin_bar'        => 'Kategória',
        'archives'              => 'Archív kategórií',
        'attributes'            => 'Atribúty kategórie',
        'parent_item_colon'     => 'Nadradená kategória:',
        'all_items'             => 'Všetky kategórie',
        'add_new_item'          => 'Pridať novú kategóriu',
        'add_new'               => 'Pridať novú',
        'new_item'              => 'Nová kategória',
        'edit_item'             => 'Upraviť kategóriu',
        'update_item'           => 'Aktualizovať kategóriu',
        'view_item'             => 'Zobraziť kategóriu',
        'view_items'            => 'Zobraziť kategórie',
        'search_items'          => 'Hľadať kategóriu',
        'not_found'             => 'Nenájdené',
        'not_found_in_trash'    => 'Nenájdené v koši',
        'featured_image'        => 'Ukážkový obrázok',
        'set_featured_image'    => 'Nastaviť ukážkový obrázok',
        'remove_featured_image' => 'Odstrániť ukážkový obrázok',
        'use_featured_image'    => 'Použiť ako ukážkový obrázok',
        'insert_into_item'      => 'Vložiť do kategórie',
        'uploaded_to_this_item' => 'Nahrané k tejto kategórii',
        'items_list'            => 'Zoznam kategórií',
        'items_list_navigation' => 'Navigácia v zozname kategórií',
        'filter_items_list'     => 'Filtrovať zozname kategórií',
    ];

    add_menu_page(
        'Lokálny katalóg',
        'Lokálny katalóg',
        'edit_posts',
        'wp-lkod-main',
        static function() {},
        'dashicons-book',
        20
    );

    add_submenu_page(
        'wp-lkod-main',
        $datasetLabels['name'],
        $datasetLabels['menu_name'],
        'edit_posts',
        'edit.php?post_type=dcat_dataset'
    );

    add_submenu_page(
        'wp-lkod-main',
        $dataServiceLabels['name'],
        $dataServiceLabels['menu_name'],
        'edit_posts',
        'edit.php?post_type=dcat_data_service'
    );

    add_submenu_page(
        'wp-lkod-main',
        $contactLabels['name'],
        $contactLabels['menu_name'],
        'edit_posts',
        'edit.php?post_type=dcat_contact_point'
    );

    add_submenu_page(
        'wp-lkod-main',
        $categoryLabels['name'],
        $categoryLabels['menu_name'],
        'edit_posts',
        'edit.php?post_type=dcat_category'
    );

    remove_submenu_page('wp-lkod-main', 'wp-lkod-main');

	register_post_type( 'dcat_dataset', array(
        'label'                 => $datasetLabels['singular_name'],
        'description'           => $datasetLabels['singular_name'],
        'labels'                => $datasetLabels,
        'supports'              => array('custom-fields'),
        'taxonomies'            => array(),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => false,
        'menu_position'         => 5,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    ));

    register_post_type( 'dcat_data_service', array(
        'label'                 => $dataServiceLabels['singular_name'],
        'description'           => $dataServiceLabels['singular_name'],
        'labels'                => $dataServiceLabels,
        'supports'              => array('custom-fields'),
        'taxonomies'            => array(),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => false,
        'menu_position'         => 5,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    ));

    register_post_type( 'dcat_contact_point', array(
        'label'                 => $contactLabels['singular_name'],
        'description'           => $contactLabels['singular_name'],
        'labels'                => $contactLabels,
        'supports'              => array('custom-fields'),
        'taxonomies'            => array(),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => false,
        'menu_position'         => 5,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    ));

    register_post_type( 'dcat_category', array(
        'label'                 => $categoryLabels['singular_name'],
        'description'           => $categoryLabels['singular_name'],
        'labels'                => $categoryLabels,
        'supports'              => array('custom-fields'),
        'taxonomies'            => array(),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => false,
        'menu_position'         => 5,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    ));
}
add_action('init', 'wp_lkod_register_post_type_dataset', 0);

add_action('manage_' . Dataset::TYPE . '_posts_columns', static function($columns) {
    return array_merge($columns, [
        'publisher' => 'Poskytovateľ',
        'theme' => 'Téma',
        'keywords' => 'Kľúčové slová',
    ]);
});

add_action('manage_' . Dataset::TYPE . '_posts_custom_column', static function($column, $postId) {
    $settings = Mirri\Lkod\Settings::getDefaultSettings();
    switch ($column) {
        case 'publisher':
            $iri = get_post_meta($postId, 'publisher', true);
            if (!empty($iri)) {
                $publisher = $settings->getPublisherByIri($iri);
                echo esc_html($publisher !== null ? $publisher->getName() : $iri);
            }
            break;
        case 'theme':
            $keys = get_post_meta($postId, 'theme');
            if (!empty($keys)) {
                $codelist = DefaultCodelists::getDatasetThemeCodelist();
                foreach ($keys as $key) {
                    echo '<div>'.esc_html($codelist->getLabel($key) ?? $key).'</div>';
                }
            }
            break;
        case 'keywords':
            foreach (get_post_meta($postId, 'keywords-sk') as $keyword) {
                echo '<div>'.esc_html($keyword).'</div>';
            }
            break;
    }
}, 10, 2);

add_action('init', static function() {
	$settings = new Mirri\Lkod\Settings();
	(new Dataset($settings))->registerPostMeta();
	(new DataService($settings))->registerPostMeta();
	(new ContactPoint($settings))->registerPostMeta();
	(new Category($settings))->registerPostMeta();
});

add_action('add_meta_boxes', static function() {
    $ns = new DefaultFormNamespace('wp-lkod-post', true);

	add_meta_box('wp-lkod-dataset', 'Vlastnosti datasetu', static function(WP_Post $post) use ($ns) {
		$entity = new Dataset(new Mirri\Lkod\Settings());
		$entity->renderForm($post, $ns);

        ?>

        <div style="margin-top: 20px">
            <input type="submit" class="button button-secondary" name="<?php echo esc_attr($ns->prefixName('_command'))?>" value="Pridať ďalšiu distribúciu">
        </div>

        <?php
	}, Dataset::TYPE);

	add_meta_box('wp-lkod-contact', 'Vlastnosti kontaktného bodu', static function(WP_Post $post) use ($ns) {
		$entity = new ContactPoint(new Mirri\Lkod\Settings());
		$entity->renderForm($post, $ns);
        ?>

        <?php

	}, ContactPoint::TYPE);

    add_meta_box('wp-lkod-contact', 'Vlastnosti dátovej služby', static function(WP_Post $post) use ($ns) {
        $entity = new DataService(new Mirri\Lkod\Settings());
        $entity->renderForm($post, $ns);
    }, DataService::TYPE);

    add_meta_box('wp-lkod-category', 'Vlastnosti kategórie', static function(WP_Post $post) use ($ns) {
        $entity = new Category(new Mirri\Lkod\Settings());
        $entity->renderForm($post, $ns);
    }, Category::TYPE);

    remove_meta_box('postcustom', Dataset::TYPE, 'normal');
    remove_meta_box('postcustom', ContactPoint::TYPE, 'normal');
    remove_meta_box('postcustom', DataService::TYPE, 'normal');
    remove_meta_box('postcustom', Category::TYPE, 'normal');
});

function wp_lkod_save_post_contact_type(int $postId): void {
	remove_action('save_post_' . ContactPoint::TYPE, 'wp_lkod_save_post_contact_type');

    $ns = new DefaultFormNamespace('wp-lkod-post', true);

    $entity = new ContactPoint(new Mirri\Lkod\Settings());
    if ($entity->validateNonce($_POST)) {
        $data = $ns->normalizeData($_POST);
        if (!empty($data)) {
            $entity->saveForm($postId, $data);
        }
    }

	add_action('save_post_' . ContactPoint::TYPE, 'wp_lkod_save_post_contact_type');
}
add_action('save_post_' . ContactPoint::TYPE, 'wp_lkod_save_post_contact_type');

function wp_lkod_save_post_dataset(int $postId): void {
	remove_action('save_post_' . Dataset::TYPE, 'wp_lkod_save_post_dataset');

    $ns = new DefaultFormNamespace('wp-lkod-post', true);

	$entity = new Dataset(new Mirri\Lkod\Settings());
    if ($entity->validateNonce($_POST)) {
        $data = $ns->normalizeData($_POST);
        if (!empty($data)) {
            $entity->saveForm($postId, $data);
        }
    }

    add_action('save_post_' . Dataset::TYPE, 'wp_lkod_save_post_dataset');
}
add_action('save_post_' . Dataset::TYPE, 'wp_lkod_save_post_dataset');

function wp_lkod_save_post_data_service(int $postId): void {
    remove_action('save_post_' . DataService::TYPE, 'wp_lkod_save_post_data_service');

    $ns = new DefaultFormNamespace('wp-lkod-post', true);

    $entity = new DataService(new Mirri\Lkod\Settings());
    if ($entity->validateNonce($_POST)) {
        $data = $ns->normalizeData($_POST);
        if (!empty($data)) {
            $entity->saveForm($postId, $data);
        }
    }

    add_action('save_post_' . DataService::TYPE, 'wp_lkod_save_post_data_service');
}
add_action('save_post_' . DataService::TYPE, 'wp_lkod_save_post_data_service');

function wp_lkod_save_post_category(int $postId): void {
    remove_action('save_post_' . Category::TYPE, 'wp_lkod_save_post_category');

    $ns = new DefaultFormNamespace('wp-lkod-post', true);

    $entity = new Category(new Mirri\Lkod\Settings());
    if ($entity->validateNonce($_POST)) {
        $data = $ns->normalizeData($_POST);
        if (!empty($data)) {
            $entity->saveForm($postId, $data);
        }
    }

    add_action('save_post_' . Category::TYPE, 'wp_lkod_save_post_category');
}
add_action('save_post_' . Category::TYPE, 'wp_lkod_save_post_category');

add_action('admin_enqueue_scripts', static function ($hook) {
	if (in_array($hook, ['post.php', 'post-new.php'], true)) {
        $screen = get_current_screen();
        $customPostTypes = [Dataset::TYPE, DataService::TYPE, ContactPoint::TYPE, Category::TYPE];
        if (!in_array($screen->post_type, $customPostTypes, true)) {
            return;
        }
	} elseif ($hook !== 'settings_page_lkod-menu') {
        return;
    }

    wp_enqueue_media();
	wp_register_style('jquery-ui', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css');
	wp_enqueue_style('jquery-ui');
	wp_enqueue_script('jquery-ui-core');
	wp_enqueue_script('jquery-ui-autocomplete');
	wp_enqueue_script('jquery-ui-datepicker');
	wp_localize_jquery_ui_datepicker();

	wp_enqueue_style('wp-lkod-form-css', plugin_dir_url( __FILE__ ) . 'assets/css/form.css', [], filemtime( plugin_dir_path( __FILE__ ) . 'assets/css/form.css' ));
	wp_enqueue_style('wp-lkod-flags', plugin_dir_url( __FILE__ ) . 'assets/css/flag-icons.min.css', [], filemtime( plugin_dir_path( __FILE__ ) . 'assets/css/flag-icons.min.css' ));
});

add_action('wp_ajax_lkod-codelist-autocomplete-https://raw.githubusercontent.com/slovak-egov/centralny-model-udajov/refs/heads/main/cbox/national/nuts2004.ttl', static function () {
	check_ajax_referer('lkod-codelist-autocomplete', 'nonce');

	$query = trim($_GET['query'] ?? '');
	$selected = (new SearchableCodelist(DefaultCodelists::getSpatialCodelist()))->search($query);

	$values = [];
	foreach ($selected as $value => $label) {
		$values[] = [
			'label' => $label,
			'value' => $value
		];
	}

	wp_send_json($values);
});

add_action('admin_init', static function() {
	$entity = new SettingsOptions(new Mirri\Lkod\Settings());
	$entity->registerSettings();

});

add_action('admin_menu', static function() {
    add_submenu_page(
        'wp-lkod-main',
        'RDF výstup',
        'RDF výstup',
        'manage_options',
        'wp-lkod-rdf-output',
        static function() {
            $settings = new Mirri\Lkod\Settings();
            $graph = (new SettingsOptions($settings))->getCatalogGraph();
            $dataset = new Dataset($settings);
            foreach (get_posts([ 'post_type' => Dataset::TYPE, 'numberposts' => -1]) as $post) {
                $dataset->addTriples($post->ID, $graph);
            }
            ?>
            <h1>RDF výstup</h1>

            <div style="margin: 1em 0; background: white; padding: 0 1em; border:1px solid #c3c4c7">
                <p>
                    Adresa prístupového bodu lokálneho katalógu: <a href="<?php echo esc_attr($settings->getCatalogUrl())?>" target="_blank"><?php echo esc_html($settings->getCatalogUrl())?></a>
                </p>

                <?php if (!$settings->isCatalogEnabled()): ?>
                    <p>Generovanie lokálneho katalógu aktuálne nie je povolené. Nastavenie je možné upraviť v <a href="<?php echo admin_url('options-general.php?page=lkod-menu') ?>">nastaveniach</a>.</p>
                <?php endif; ?>
            </div>

            <pre style="background: white; padding: 1em; border:1px solid #c3c4c7; white-space: pre-wrap"><?php echo esc_html($graph->serialise('turtle'))?></pre>

            <?php
        }
    );

    add_options_page('Lokálny katalóg', 'Lokálny katalóg', 'manage_options', 'lkod-menu',         static function() {
        $entity = new SettingsOptions(new Mirri\Lkod\Settings());
        $state = $entity->getRawOptions();
        $ns = new DefaultFormNamespace([]);
        ?>

        <div class="wrap">
            <h1>Nastavenia lokálneho katalógu</h1>

            <div style="margin: 1em 0; background: white; padding: 0 1em; border:1px solid #c3c4c7">
                <!--suppress HtmlUnknownTarget -->
                <form action="options.php" method="post">
                    <?php settings_fields( SettingsOptions::TYPE); ?>
                    <?php $entity->renderFormState($state, $ns); ?>
                    <?php submit_button(); ?>
                </form>
            </div>
        </div>

        <?php
    });
});

add_action('rest_api_init', function () {
    register_rest_route('wp-lkod/v1', '/catalog', [
        'methods'             => 'GET',
        'callback'            => function (WP_REST_Request $request) {
            header('Content-Type: text/turtle');
            nocache_headers();

            $settings = new Mirri\Lkod\Settings();
            if (!$settings->isCatalogEnabled()) {
                status_header(404);
                exit;
            }

            echo (new SettingsOptions($settings))->getCatalogGraph()->serialise('turtle');
            exit;
        },
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('wp-lkod/v1', '/dataset/(?P<id>\d+)', [
        'methods'             => 'GET',
        'callback'            => function (WP_REST_Request $request) {
            $id = (int)$request->get_param('id');
            if ($id <= 0) {
                status_header(404);
                exit;
            }

            $settings = new Mirri\Lkod\Settings();
            if (!$settings->isCatalogEnabled()) {
                status_header(404);
                exit;
            }

            $post = get_post($id);
            if (!$post instanceof WP_Post || $post->post_type !== Dataset::TYPE || $post->post_status !== 'publish') {
                status_header(404);
                exit;
            }

            header('Content-Type: text/turtle');
            nocache_headers();
            echo (new Dataset($settings))->getGraph($id)->serialise('turtle');
            exit;
        },
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('wp-lkod/v1', '/publishers', [
        'methods'             => 'GET',
        'callback'            => function () {
            nocache_headers();

            $settings = new Mirri\Lkod\Settings();
            $publishers = [];
            foreach ($settings->getPublishers() as $publisher) {
                $publishers[] = ['key' => $publisher->getIri(), 'label' => $publisher->getName()];
            }
            return $publishers;
        },
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('wp-lkod/v1', '/custom-metadata', [
            'methods'             => 'GET',
            'callback'            => function () {
                nocache_headers();

                $settings = new Mirri\Lkod\Settings();
                $customMetadata = [];
                foreach ($settings->getCustomMetadata() as $d) {
                    $customMetadata[] = ['key' => $d->getName(), 'label' => $d->getLabel(), 'values' => $d->getValues(), 'entities' => $d->getEntities()];
                }
                return $customMetadata;
            },
            'permission_callback' => '__return_true'
    ]);

    register_rest_route('wp-lkod/v1', '/codelists/(?P<codelist>[^/]+)(?:/(?P<key>.+))?', [
        'methods'             => 'GET',
        'callback'            => function (WP_REST_Request $request) {
            nocache_headers();
            $codelistName = $request->get_param('codelist');
            $codelistKey = $request->get_param('key');

            switch ($codelistName) {
                case 'spatial':
                    $codelist = DefaultCodelists::getSpatialCodelist();
                    break;
                case 'dataset-theme':
                    $codelist = DefaultCodelists::getDatasetThemeCodelist();
                    break;
                case 'dataset-type':
                    $codelist = DefaultCodelists::getDatasetTypeCodelist();
                    break;
                case 'frequency':
                    $codelist = DefaultCodelists::getFrequencyCodelist();
                    break;
                case 'hvd-category':
                    $codelist = DefaultCodelists::getHvdCategoryCodelist();
                    break;
                case 'license':
                    $codelist = DefaultCodelists::getLicenseCodelist();
                    break;
                case 'personal-data':
                    $codelist = DefaultCodelists::getPersonalDataCodelist();
                    break;
                case 'format':
                    $codelist = DefaultCodelists::getFormatCodelist();
                    break;
                case 'media-type':
                    $codelist = DefaultCodelists::getMediaTypeCodelist();
                    break;
            }

            if (!isset($codelist)) {
                status_header(404);
                exit;
            }

            if (empty($codelistKey)) {
                $options = [];
                foreach ($codelist->getOptions() as $key => $label) {
                    $options[] = ['key' => $key, 'label' => $label];
                }
                return $options;
            }

            $codelistLabel = $codelist->getLabel($codelistKey);
            if (empty($codelistLabel)) {
                status_header(404);
                exit;
            }

            return ['key' => $codelistKey, 'label' => $codelistLabel];
        },
        'permission_callback' => '__return_true'
    ]);
});